    Copyright American Assist International 2018.

# Navegando el proyecto Android

La aplicación está construida bajo el Patron de diseño [MVP](MVP.md).
Dentro de la carpeta src, están disponibles las siguientes carpetas:

+ **main**: el codigo de la app. Esta empaquetado por caracteristicas y no por capas. Las unicas clases que estan empaquetadas
por capas son las que contienen las caracteristicas comunes, como BaseActivity. El empaquetado por funciones permite a 
diferentes desarrolladores trabajar fácilmente en diferentes características de una manera dividida. También permite a 
a un nuevo desarrollador entender qué características tiene la aplicación simplemente escaneando la lista de paquetes y
comprender una característica dada al leer el código en un paquete determinado.

+ **debug**: utilizado para recursos de la compilación de depuración.

# Navegando en el código principal

Los paquetes principales son:

+ **connection**: Clases usadas para el manejo de conexiones a la Api. 
+ **utils**: Clases usadas para optimizar procesos, utilidades como funciones y metodos.
+ **cost**: Características de los costos normales. Estos son accesibles cuando un
usuario presiona ver costos desde la vista del mapa.
+ **cranecost**: Características de costos grua. Estos se acceden al momento de que el usuario acepta
una asistencia pendiente y posee costos visibles.
+ **diagnostic** Caracteristicas de diagnostico. Se acceden al momento de confirmar arribo
y presionar el boton de diagnostico.
+ **maneuver** Caracteristicas de maniobras, donde el usuario puede llenar las maniobras cuando
acepta que tiene maniobras la asistencia.
+ **map** Caracteristicas del map. Es la vista principal y aquì el usuario gestiona las acciones sobre una 
asistencia.
+ **register** Caracteristicas de registro de proveedores. Se accede desde la vista de login.
+ **rejectassistance** Caracteristicas del rechazo de asistencias. Se accede desde solicitudes pendientes o
desde el mapa.