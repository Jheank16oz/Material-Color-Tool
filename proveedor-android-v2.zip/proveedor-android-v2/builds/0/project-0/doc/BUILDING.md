    Copyright American Assist International 2018.
    
    
# Como construir Proveedor

Nota: aunque estas instrucciones le permite construir la app del Proveedor, gran parte de
la funcionalidad depende de las API del servidor y no funcionará si no se configura
las variables del servidor.

Este es un proyecto basado en Gradle que funciona mejor con
[Android Studio](http://developer.android.com/sdk/installing/studio.html)

Para construir la app:

1. Instalar el siguiente software:
       - Android SDK:
         http://developer.android.com/sdk/index.html
       - Gradle:
         http://www.gradle.org/downloads
       - Android Studio:
         http://developer.android.com/sdk/installing/studio.html

1. Ejecute el  Android SDK Manager de Android presionando el botón de la barra de herramientas del Administrador de SDK
   en Android Studio o ejecutando el comando 'android' en una ventana de terminal.

1. En Android SDK Manager, asegúrese de que los siguientes paquetes estén instalados
   y se actualicen a la última versión disponible:
       - Tools > Android SDK Platform-tools
       - Tools > Android SDK Tools
       - Tools > Android SDK Build-tools
       - Tools > Android SDK Build-tools
       - Android 8.0 > SDK Platform (API 28)
       - Extras > Android Support Repository
       - Extras > Android Support Library
       - Extras > Google Play services
       - Extras > Google Repository

1. Importar el proyecto en Android Studio:

    1. Presione File > Import Project
    2. Navegar y seleccionar el proyecto previamente descargado
    3. Presione OK

1. Cambiar la ruta de keystore del proyecto (descarguela de https://drive.google.com/drive/u/1/folders/1iosbw51cfMHisOanfgJcn745fwMe7lm7), dirijase a: 
    1. Project Structure > Signing configs
    2. Cambia la url de la llave de cada Build Variant apuntando a cada .keystore
       descargada.
    3. Presione OK.

1. Presione Build > Make Project en Android Studio o ejecute el siguiente
    comando en el directorio root del proyecto:
   ```
    ./gradlew clean assembleDebug
   ```
1. Para instalar en su dispositivo de prueba:

   ```
    ./gradlew installDebug
   ```
1. Consulte el documento ['Navegando en la aplicación de Android'.'](NAVIGATING_CODE.md).

