    Copyright American Assist International 2018.

# Dependencias utilizadas

La aplicación utilza diferentes librerias para optimizar los procesos y 
"No reinventar la rueda", a continuación te mostramos las diferentes librerias 
utilizadas, uso y licencia de implementación:

**libreria** | **Uso** | **licencia**
--- | :---: | :---
[**com.google.android.gms:play-services-maps**](https://mvnrepository.com/artifact/com.google.android.gms/play-services/12.0.0) | para el uso de Mapas de Google | [*Android Software Development Kit License.*](https://developer.android.com/studio/terms)
[**com.google.firebase:firebase-messaging**](https://firebase.google.com/docs/android/setup?hl=es-419)  | para el uso de Notificaciones [PUSH](https://es.wikipedia.org/wiki/Notificaci%C3%B3n_push) | [*Apache 2.0 License.*](https://www.apache.org/licenses/LICENSE-2.0)
[**com.google.android.gms:play-services-location**](https://developers.google.com/android/guides/setup) | Actualizaciones de ubicación y GPS | [*Android Software Development Kit License.*](https://developer.android.com/studio/terms)
[**com.google.code.gson:gson**](https://mvnrepository.com/artifact/com.google.code.gson/gson/2.8.2) | Para formatear información en en .json | [*Apache 2.0 license.*](https://mvnrepository.com/artifact/com.google.code.gson/gson/2.8.2)
[**com.google.android.gms:play-services-places**](https://mvnrepository.com/artifact/com.google.android.gms/play-services/12.0.0) | para el uso la api de Places de Google | [*Android Software Development Kit License.*](https://developer.android.com/studio/terms)
[**com.android.support:multidex**](https://developer.android.com/studio/build/multidex?hl=es-419) | Mantenimiento de tamaño de app | [*Apache 2.0 license.*](https://www.apache.org/licenses/LICENSE-2.0)
[**com.android.support:v4-v7**](https://developer.android.com/topic/libraries/support-library/setup) | Soporte de versiones inferiores de Android | [*Apache 2.0 license.*](https://www.apache.org/licenses/LICENSE-2.0)
[**uk.co.chrisjenx:calligraphy**](https://github.com/chrisjenx/Calligraphy) | Manejo de fuentes de texto |  [*licencia Apache 2.0 license.*](https://www.apache.org/licenses/LICENSE-2.0)
[**commons-io:commons-io**](https://mvnrepository.com/artifact/commons-io/commons-io/2.4)| contiene clases de utilidad |  [*licencia Apache 2.0 license.*](https://www.apache.org/licenses/LICENSE-2.0)
[**com.github.bumptech.glide:glide**](https://mvnrepository.com/artifact/com.github.bumptech.glide/glide/4.3.1)| Cargar imagenes y recursos | [Simplified BSD License](http://www.opensource.org/licenses/bsd-license), [*Apache 2.0 License.*](https://www.apache.org/licenses/LICENSE-2.0)
[**com.squareup.okhttp3:okhttp**](https://github.com/square/okhttp)| Soporte de conexiones [REST](https://es.wikipedia.org/wiki/Wikipedia:Comunicado_4_julio_2018) | [*Apache 2.0 License.*](https://www.apache.org/licenses/LICENSE-2.0)
[**com.loopj.android:android-async-http**](https://github.com/loopj/android-async-http) | Conexiones [REST](https://es.wikipedia.org/wiki/Wikipedia:Comunicado_4_julio_2018) |  [*licencia Apache 2.0 License.*](https://www.apache.org/licenses/LICENSE-2.0)
[**io.socket:socket.io-client**](https://github.com/socketio/socket.io-client-java)  | Mensajes en tiempo Real | [The MIT License (MIT)](http://opensource.org/licenses/mit-license)
[**com.crashlytics.sdk.android:crashlytics**](https://fabric.io/kits/android/crashlytics/install) | Reporte de Errores | [Crashlytics Terms of Service](http://try.crashlytics.com/terms/terms-of-service.pdf)
[**httpcore-4.2.4**](https://mvnrepository.com/artifact/org.apache.httpcomponents/httpcore/4.2.4) | Conexiones [REST](https://es.wikipedia.org/wiki/Wikipedia:Comunicado_4_julio_2018) |  [*licencia Apache 2.0 License.*](https://www.apache.org/licenses/LICENSE-2.0)
[**com.squareup.retrofit2:retrofit**](https://github.com/square/retrofit) | Optimizaciones [REST](https://es.wikipedia.org/wiki/Wikipedia:Comunicado_4_julio_2018) |  [*licencia Apache 2.0 License.*](https://www.apache.org/licenses/LICENSE-2.0)
[**com.jakewharton:butterknife**](https://github.com/JakeWharton/butterknife) | Optimizaciones de código |  [*licencia Apache 2.0 License.*](https://www.apache.org/licenses/LICENSE-2.0)
[**jp.wasabeef:recyclerview-animators**](https://github.com/wasabeef/recyclerview-animators) | Animaciones de listas | [*licencia Apache 2.0 License.*](https://www.apache.org/licenses/LICENSE-2.0)
[**org.jetbrains.kotlin:kotlin-stdlib-jre7**](https://mvnrepository.com/artifact/org.jetbrains.kotlin/kotlin-stdlib-jre7/1.1.2-5) | Soprte de lenguaje [Kotlin](https://kotlinlang.org/) | [*licencia Apache 2.0 License.*](https://www.apache.org/licenses/LICENSE-2.0)
[**org.gavaghan:geodesy**](https://github.com/mgavaghan/geodesy)| Herramientas de controles de camara Google Maps |  [*licencia Apache 2.0 License.*](https://www.apache.org/licenses/LICENSE-2.0)