    Copyright American Assist International 2018.


# ¿Que es MVP?

Model View Presenter es una arquitectura de software que separa las preocupaciones. El presentador actúa como
puente entre el modelo y la vista, cuidando la lógica de presentación.

![MVP diagram](images/mvp-diagram.png "MVP diagram")
        
# ¿Porque MVP?

La arquitectura MVP mejora la capacidad de prueba, la legibilidad y la escalabilidad del código. Aquellas
mejoras se logran separando las preocupaciones: permite una prueba más fácil (tanto de la unidad como de la IU),
clases más pequeñas y hace que sea más fácil cambiar la forma en que se obtienen los datos o la interfaz de usuario.

# Cómo hemos implementado MVP

Las principales características de nuestro framework mvp son:

+ **Abstracción de *DataQuery* y *UserAction* conceptos**: *DataQuery* corresponde a *Solicitudes
de actualización del modelo*, en el diagrama MVP anterior *UserAction* corresponde a *Eventos de acción del usuario*.
la abstracción se realiza utilizando una interfaz para cada uno, [QueryEnum] [QE] y [UserActionEnum] [UAE].
    + Un **UserAction** ocurre en una vista, es escuchado por el presentador y se envía al
      Modelo; el Modelo procesa cualquier cambio de datos relacionado con la acción, luego, a través de una devolución de llamada, notifica
      el Presentador que a su vez notifica la vista.
    + Un *DataQuery* ocurre cuando se carga la vista. El presentador se crea con una lista inicial de
      *DataQuery*s, que se solicitan en el Modelo; el Modelo ejecuta las consultas, luego a través de una
      devolución de llamada, notifica al presentador, que a su vez notifica la vista.

+ **Interfaces para [Model][M], [View][V] y [Presenter][P]**: estos se escriben utilizando tipados y metodos genéricos, por lo cual
es entendible el código, estas se integran en todas las clases para formar una función. Nota: como View es una clase
en Android, para nuestro framework mvp se nombran con sufijos UpdatableView.
