Proveedor Android App
======================

Proveedor es una app para la gestion de solicitudes de asistencias, y esta optimizada 
para asistencias solicitadas desde la app de [Afiliado](https://gitlab.com/icaatech/afiliado-android) y SOOANG American Assist.

Esta es la app de Android y soporta dispositivos que corren versiones 4.1+,
y esta optimizada para pantallas superiores a 4.5 pulgadas en adelante.

<h2>Características</h2>

Con la aplicación, usted puede:

- Registrarse como proveedor
- Ingresar como proveedor
- Hacer Seguimiento de solicitudes pendientes
- Ver Detalles de solicitudes pendientes
- Notificar Emergencias
- Marcar a centro de llamadas
- Tomar y rechazar una asistencia pendiente
- Ver Historial de Servicios con Detallado
- Gestionar asistencia en proceso
- Vista Mapa en Tiempo real con Tiempo, distancia hacia el punto de la asistencia y dirección proxima.
- Cancelar asistencia
- Reprogramar asistencia
- Ver ruta(s) de asistencia en Mapa de Google
- Modo conductor en Mapa
- Activar Tráfico en Mapa
- Realizar Diagnóstico
- Realizar Costos
- Realizar Maniobras
- Termino de Asistencia
- Seguimiento en tiempo real de estados de asistencia en proceso 


<h2>Como trabajar con la fuente</h2>

Esperamos esta documentación le sea útil, a continuación le proporcionamos instrucciones 
para el uso y construcción de la app.

  * [Instrucciones de construcción](doc/BUILDING.md): Instrucciones de como construir y correr la applicación
  * [Navegando en el código de la aplicación de Android](doc/NAVIGATING_CODE.md)
  * [Arquitectura usada](doc/MVP.md)
  * [Librerias](doc/LIB.md)
  

<h2>Copyright</h2>

    American Assist International 2018