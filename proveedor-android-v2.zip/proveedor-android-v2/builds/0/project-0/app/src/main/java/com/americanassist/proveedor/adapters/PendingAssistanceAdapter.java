package com.americanassist.proveedor.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.StaggeredGridLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.americanassist.proveedor.R;
import com.americanassist.proveedor.model.RequestAssistance;

import org.apache.commons.lang3.text.WordUtils;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * <p>Adaptador encargado de gestionar la lista de solicitudes pendientes
 * Extiende de BaseAdapter para el uso del Footer</p>
 */
public class PendingAssistanceAdapter extends BaseAdapter<RequestAssistance> {

    private FooterViewHolder footerViewHolder;
    private PendingAssistanceAdapterListener mPendingAssistanceAdapterListener;

    /**
     * Callback para notificar las acciones sobre un item de
     * asistencia
     */
    public interface PendingAssistanceAdapterListener {
        /**
         * Notifica cuando se confirma una asistencia
         * @param assistance  la asistencia confirmada
         */
        void onConfirmClicked(RequestAssistance assistance);

        /**
         * Notifica un rechazo de asistencia
         * @param assistance la asistencia rechazada
         */
        void onRejectClicked(RequestAssistance assistance);

        /**
         * Notifica la solicitud de ver detall de asistencia
         * @param assistance la asistencia solicitada para ver detalle
         */
        void onMoreInfoClicked(RequestAssistance assistance);
    }

    public PendingAssistanceAdapter(Context context, PendingAssistanceAdapterListener pendingAssistanceAdapterListener) {
        super();
        this.mPendingAssistanceAdapterListener = pendingAssistanceAdapterListener;
    }

    @Override
    public int getItemViewType(int position) {
        return (isLastPosition(position) && isFooterAdded) ? FOOTER : ITEM;
    }


    @Override
    protected RecyclerView.ViewHolder createHeaderViewHolder(ViewGroup parent) {
        return null;
    }

    @Override
    protected RecyclerView.ViewHolder createItemViewHolder(ViewGroup parent) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.pending_assistance_item, parent, false);

        final PendingAssistanceViewHolder holder = new PendingAssistanceViewHolder(v);

        holder.itemView.setOnClickListener(v1 -> {
            int adapterPos = holder.getAdapterPosition();
            if(adapterPos != RecyclerView.NO_POSITION){
                if (onItemClickListener != null) {
                    onItemClickListener.onItemClick(adapterPos, holder.itemView);
                }
            }
        });

        return holder;
    }

    @Override
    protected RecyclerView.ViewHolder createFooterViewHolder(ViewGroup parent) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_footer, parent, false);

        final FooterViewHolder holder = new FooterViewHolder(v);
        holder.reloadButton.setOnClickListener(v1 -> {
            if(onReloadClickListener != null){
                onReloadClickListener.onReloadClick();
            }
        });

        return holder;
    }

    @Override
    protected void bindHeaderViewHolder(RecyclerView.ViewHolder viewHolder) {

    }

    @Override
    protected void bindItemViewHolder(RecyclerView.ViewHolder viewHolder, int position) {
        final PendingAssistanceViewHolder holder = (PendingAssistanceViewHolder) viewHolder;

        final RequestAssistance assistance = getItem(position);
        if (assistance != null) {
            holder.bind(assistance);
        }
    }

    @Override
    protected void bindFooterViewHolder(RecyclerView.ViewHolder viewHolder) {
        footerViewHolder = (FooterViewHolder) viewHolder;

    }

    @Override
    protected void displayLoadMoreFooter() {
        if(footerViewHolder!= null){
            footerViewHolder.errorRelativeLayout.setVisibility(View.GONE);
            footerViewHolder.loadingFrameLayout.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void displayErrorFooter() {
        if(footerViewHolder!= null){
            footerViewHolder.loadingFrameLayout.setVisibility(View.GONE);
            footerViewHolder.errorRelativeLayout.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void addFooter() {
        isFooterAdded = true;
        add(new RequestAssistance());
    }




    class PendingAssistanceViewHolder extends RecyclerView.ViewHolder {
        TextView txtClientName;
        TextView txtButtonAccept;
        TextView txtButtonCancel;
        View itemView;
        View contentInfo;
        RecyclerView infoGridView;


        PendingAssistanceViewHolder(View itemView) {
            super(itemView);
            txtClientName = itemView.findViewById(R.id.client);
            txtButtonAccept = itemView.findViewById(R.id.accept);
            txtButtonCancel = itemView.findViewById(R.id.refuse);
            infoGridView = itemView.findViewById(R.id.info);
            contentInfo = itemView.findViewById(R.id.contentInfo);
            this.itemView = itemView;

        }

        void bind(final RequestAssistance mAssistance) {
            if (mAssistance == null){
                return;
            }
            txtClientName.setText(WordUtils.capitalize(mAssistance.clientName.toLowerCase()));
            txtButtonAccept.setAllCaps(true);

            if (mAssistance.acceptAssistance!=null && mAssistance.acceptAssistance.equals(RequestAssistance.ASSISTANCE_ACCEPT)){
                txtButtonAccept.setText(R.string.aceptar);
            }
            else{
                txtButtonAccept.setText(R.string.siguiente);
            }

            txtButtonAccept.setOnClickListener(v -> mPendingAssistanceAdapterListener.onConfirmClicked(mAssistance));

            txtButtonCancel.setOnClickListener(v -> mPendingAssistanceAdapterListener.onRejectClicked(mAssistance));

            //Si queremos ver detalle del servicio sin necesidad de aceptarlo
            itemView.setOnClickListener(v -> mPendingAssistanceAdapterListener.onMoreInfoClicked(mAssistance));

            StaggeredGridLayoutManager gaggeredGridLayoutManager;
            gaggeredGridLayoutManager = new StaggeredGridLayoutManager( 2,StaggeredGridLayoutManager.VERTICAL);
            infoGridView.setLayoutManager(gaggeredGridLayoutManager);

            infoGridView.setAdapter(new RequestInfoAssistanceAdapter(mAssistance.information));

            contentInfo.setOnClickListener(v -> mPendingAssistanceAdapterListener.onMoreInfoClicked(mAssistance));

        }
    }


    static class FooterViewHolder extends RecyclerView.ViewHolder {
        // region Views
        @BindView(R.id.loading_fl)
        FrameLayout loadingFrameLayout;
        @BindView(R.id.error_rl)
        RelativeLayout errorRelativeLayout;
        @BindView(R.id.loading_iv)
        ProgressBar loading;
        @BindView(R.id.reload_btn)
        Button reloadButton;
        // endregion

        // region Constructors
        FooterViewHolder(View view) {
            super(view);
            ButterKnife.bind(this, view);
        }
    }
}
