package com.americanassist.proveedor;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.Snackbar;
import android.view.ViewGroup;
import android.widget.Toast;

import com.americanassist.proveedor.commons.Controllers.BaseActivity;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.services.ActiveRequestService;

/**
 * Vista Splash de la aplicacion.
 */
public class SplashActivity extends BaseActivity {

    private static final long DELAY = 500;

    private boolean notificationFromNewRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_splash);

        displayEmergencyButton = false;
        notificationFromNewRequest = false;

        if (getIntent().getExtras() != null) {
            for (String key : getIntent().getExtras().keySet()) {
                String value = getIntent().getExtras().getString(key);
                if (value != null && key.equals("type") && value.equals("solicitud")) {
                    notificationFromNewRequest = true;
                }
            }
        }

        requestPermissions();

    }

    /**
     * Funcion encargada de validar los permisos necesarios de la app
     */
    private void requestPermissions() {
        new Handler().postDelayed(() -> {
            //Actualizamos la posicion una unica vez para poder llamar al servicio de posicion y saber si estamos en el punto de llegada
            askForPermission(android.Manifest.permission.ACCESS_FINE_LOCATION, null, new PermissionListener() {
                @Override
                public void onPermissionGranted() {
                    validateUserSession();
                }

                @Override
                public void onPermissionDenied() {
                    Snackbar.make(findViewById(android.R.id.content), R.string.mensaje_permiso_ubicacion_necesarios, Snackbar.LENGTH_LONG).show();
                }
            });

        }, DELAY);
    }

    private void validateUserSession() {
        Provider mProvider = SharedPreferencesManager.getProvider(getBaseContext());
        if (mProvider == null) {
            Intent i = new Intent(SplashActivity.this, LoginActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(i);
        }
        else{
            /*
             * Consultamos que el estado de la api de google, la distancia y el tiempo
             * esten bien configuradas
             */
            configurationApp(mProvider, new ApiManagerHelper.GetConfigurationCallback() {
                @Override
                public void onSuccessConfigurationLoaded() {
                    // Empezamos a enviar coordenadas
                    startService(new Intent(SplashActivity.this, ActiveRequestService.class));
                    Intent i = new Intent(SplashActivity.this, DrawerActivity.class);
                    i.putExtra(DrawerActivity.FROM_NOTIFICATION_REQUEST, notificationFromNewRequest);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(i);
                }

                @Override
                public void onFailureConfigurationLoaded() {
                    Toast.makeText(getBaseContext(), getString(R.string.configuracion_incorrecta), Toast.LENGTH_SHORT).show();
                }
            });
        }
    }
}
