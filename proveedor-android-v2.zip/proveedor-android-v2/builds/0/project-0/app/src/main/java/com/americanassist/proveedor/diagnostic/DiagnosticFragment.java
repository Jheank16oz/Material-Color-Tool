package com.americanassist.proveedor.diagnostic;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.FileProvider;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.americanassist.proveedor.DrawerActivity;
import com.americanassist.proveedor.R;
import com.americanassist.proveedor.adapters.QuestionsAdapter;
import com.americanassist.proveedor.commons.Controllers.BaseActivity;
import com.americanassist.proveedor.dialogs.ErrorDialog;
import com.americanassist.proveedor.managers.Server.ApiManager;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.Assistance;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.model.Question;
import com.americanassist.proveedor.utils.FilePath;
import com.americanassist.proveedor.utils.Functions;
import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlaceAutocomplete;
import com.wdullaer.materialdatetimepicker.date.DatePickerDialog;
import com.wdullaer.materialdatetimepicker.time.RadialPickerLayout;
import com.wdullaer.materialdatetimepicker.time.TimePickerDialog;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_TYPE_CANCEL;
import static com.americanassist.proveedor.utils.Utils.getCompressImage;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * <p>Vista en cargada de gestionar las opciones de Diagnostico dinamicas</p>
 */

public class DiagnosticFragment extends Fragment implements QuestionsAdapter.QuestionsAdapterCallback,DatePickerDialog.OnDateSetListener, TimePickerDialog.OnTimeSetListener,DiagnosticContract.View{

    protected LinearLayoutManager llm;
    private QuestionsAdapter questionsAdapter;
    protected Calendar calendarSelectedDate;
    /** Objetivos para la posicion en el adaptador*/
    int viewPositionImage = -1;
    private int positionDate;
    private int positionDirection;
    private ErrorDialog errorDialog;

    //mvp
    private DiagnosticContract.Presenter mPresenter;
    /** Objetivo para las preguntas que se reciben desde {@link DrawerActivity}*/
    private ArrayList<Question> mQuestions = new ArrayList<>();


    /**
     * Objetivo para el directorio donde se almacenara las fotos
     * capturadas mediante Intent de Camera.
     */
    private String MEDIA_DIRECTORY = "Proveedor/";

    /**
     * Objetivo para almacenar la ruta de la imagen capturada.
     */
    private String mPath;

    /**
     * Request Code para el intent de camara.
     */
    private static int PHOTO_CODE = 5;

    /** Request Code para la seleccion de ubicacion   */
    public static final int REQUEST_SELECT_LOCATION = 12;


    /**
     * Objetivo para almacenar la ruta de la imagen capturada,
     * posterior a ser escaneada con MediaScanner.
     */
    private String selectedFilePath;



    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.diagnostic_fragment, container, false);
        initializeComponents(view);
        return view;
    }

    private void initializeComponents(View view) {


        RecyclerView recyclerQuestions = view.findViewById(R.id.AD_recyclerview_listquestions);
        llm = new LinearLayoutManager(getContext());
        recyclerQuestions.setLayoutManager(llm);
        questionsAdapter = new QuestionsAdapter(getContext(), this);
        recyclerQuestions.setAdapter(questionsAdapter);


        displayQuestions();

        view.findViewById(R.id.send).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (allCorrect()) {
                    sendAnswers();
                }
            }
        });
    }

    @Override
    public void onImageClicked(final int position) {

        viewPositionImage = position;
        openCamera();
    }

    /**
     * Se encarga de iniciar la camara para las opciones
     * de tipo imagen, aqui se crea  el archivo destino para la imagen
     * capturada, ademas de validar los permisos de almacenamiento.
     */
    private void openCamera() {
        if (Functions.checkPermission(this)) {
            return;
        }

        File file = new File(Environment.getExternalStorageDirectory(), MEDIA_DIRECTORY);
        boolean isDirectoryCreated = file.exists();

        if (!isDirectoryCreated)
            isDirectoryCreated = file.mkdirs();

        if (isDirectoryCreated) {
            Long timestamp = System.currentTimeMillis() / 1000;
            String imageName = timestamp.toString() + ".jpg";

            mPath = Environment.getExternalStorageDirectory() + File.separator + MEDIA_DIRECTORY + File.separator + imageName;

            File newFile = new File(mPath);

            Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

            Uri uriFromFile;
            if (android.os.Build.VERSION.SDK_INT > Build.VERSION_CODES.M) {
                uriFromFile = FileProvider.getUriForFile(getContext(),
                        "com.americanassist.proveedor.provider",
                        newFile);
            }else{
                uriFromFile = Uri.fromFile(newFile);
            }
            intent.putExtra(MediaStore.EXTRA_OUTPUT,uriFromFile);


            startActivityForResult(intent, PHOTO_CODE);


        }
    }


    @Override
    public void onDateClicked(int position) {
        calendarSelectedDate = Calendar.getInstance();
        positionDate = position;
        DatePickerDialog dpd = DatePickerDialog.newInstance(this, calendarSelectedDate.get(Calendar.YEAR), calendarSelectedDate.get(Calendar.MONTH), calendarSelectedDate.get(Calendar.DAY_OF_MONTH));
        dpd.show(getActivity().getFragmentManager(), "Datepickerdialog");
    }

    @Override
    public void onDirectionClicked(int position) {
        positionDirection = position;
        try {
            Intent intent =
                    new PlaceAutocomplete.IntentBuilder(PlaceAutocomplete.MODE_FULLSCREEN)
                            .build(getActivity());
            startActivityForResult(intent, REQUEST_SELECT_LOCATION);
        } catch (GooglePlayServicesRepairableException e) {
            e.printStackTrace();
        } catch (GooglePlayServicesNotAvailableException e) {
            e.printStackTrace();
        }
    }

    /**
     * Se encarga de enviar las respuestas de diagnostico con
     * conexion a la api.
     * Gestiona las respuestas de envio de respuestas.
     */
    private void sendAnswers() {
        final Provider mProvider = SharedPreferencesManager.getProvider(getContext());
        Assistance mAssistance = ((DrawerActivity)getActivity()).getAssistance();
        if (mProvider == null || mAssistance == null){
            Toast.makeText(getContext(), R.string.intentalo_mas_tarde, Toast.LENGTH_SHORT).show();
            return;
        }

        ((BaseActivity)getActivity()).showLoadingView();

        new ApiManager(getContext()).sendAnswers(mAssistance.id, mProvider.country, generateJsonForAnswers(), generateArrayOfFiles(), mProvider.idProvider, mProvider.idContact, new ApiManagerHelper.ApiSendAnswersCallback() {
            @Override
            public void onSendAnswersSuccess(int showManeuvers) {
                ((BaseActivity)getActivity()).hideLoadingView();
                // Enviamos al mapa para que se actualize el estado y el defina la vista a la cual
                // continuar.
                ((DrawerActivity)getActivity()).setFragment(DrawerActivity.MAP_FRAGMENT);
            }

            @Override
            public void onSendAnswersError(String error) {
                ((BaseActivity)getActivity()).hideLoadingView();
                // Si ha habido error liberamos el proveedor de la asistencia
                ((DrawerActivity)getActivity()).setAssistance(null);
                errorDialog = new ErrorDialog(getContext(), error);
                errorDialog.show();
                errorDialog.setCancelable(false);
                errorDialog.setCanceledOnTouchOutside(true);
                errorDialog.setOnCancelListener(dialog -> {
                    // Al cerrar dialog cerramos actividad
                    ((DrawerActivity)getActivity()).setFragment(DrawerActivity.MAP_FRAGMENT);
                });
            }
        });
    }

    private boolean allCorrect() {
        ArrayList<Question> questions = questionsAdapter.data;
        for (int i = 0; i < questions.size(); i++) {
            Question question = questions.get(i);
            if (question.isRequired.equalsIgnoreCase("1")) {
                switch (question.type) {
                    case Question.TYPE_TEXT:
                        if (question.text == null || question.text.equals("")) {
                            Toast.makeText(getContext(), "Ingrese "+question.placeholder, Toast.LENGTH_SHORT).show();
                            return false;
                        }
                        break;

                    case Question.TYPE_DIRECTION:
                        if (question.mPlace == null){
                            Toast.makeText(getContext(), "Seleccione "+question.placeholder, Toast.LENGTH_SHORT).show();
                            return false;
                        }
                        break;

                    case Question.TYPE_DATETIME:
                        if (question.calendar == null) {
                            Toast.makeText(getContext(), "Ingrese "+question.question, Toast.LENGTH_SHORT).show();
                            return false;
                        }
                        break;
                    case Question.TYPE_IMAGE:
                        if (question.filePicture == null) {
                            Toast.makeText(getContext(), "Seleccione "+question.question, Toast.LENGTH_SHORT).show();
                            return false;
                        }
                        break;
                    case Question.TYPE_LIST:

                        boolean selected = false;
                        for (int j = 0; j < question.questionOptions.size(); j++) {
                            if (question.questionOptions.get(j).checked) {
                                selected = true;
                            }
                        }
                        if (!selected) {
                            Toast.makeText(getContext(), "Seleccione "+question.question, Toast.LENGTH_SHORT).show();

                            return false;

                        }
                        break;
                }
            }
        }
        return true;
    }

    /**
     * GEnera la lista de respuestas de preguntas de Diagnostico
     * @return LAs lista de respuestas en Formato JSON
     */
    private String generateJsonForAnswers() {
        ArrayList<Question> questions = questionsAdapter.data;
        JSONArray jsonArray = new JSONArray();
        for (int i = 0; i < questions.size(); i++) {
            Question question = questions.get(i);
            JSONObject jsonObject = new JSONObject();
            try {
                jsonObject.put("idpregunta", question.id);
                jsonObject.put("latitud", "");
                jsonObject.put("longitud", "");
                jsonObject.put("tipo", question.type);

                if (question.type.equals(Question.TYPE_LIST)) {
                    for (int j = 0; j < question.questionOptions.size(); j++) {
                        if (question.questionOptions.get(j).checked) {
                            jsonObject.put("respuesta", question.questionOptions.get(j).questionName);
                            jsonObject.put("idopcion", question.questionOptions.get(j).id);
                            jsonObject.put("valor", question.questionOptions.get(j).optionValue);
                        }
                    }
                } else if (question.type.equals(Question.TYPE_TEXT)) {
                    jsonObject.put("respuesta", question.text);
                    jsonObject.put("valor", "1");
                } else if (question.type.equals(Question.TYPE_DATETIME)) {
                    SimpleDateFormat dateFormatHour = new SimpleDateFormat("d 'de' MMMM HH:mm");
                    jsonObject.put("respuesta", dateFormatHour.format(question.calendar.getTime()));
                    jsonObject.put("valor", "1");
                }
                jsonArray.put(jsonObject);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        return jsonArray.toString();
    }
    private ArrayList<File> generateArrayOfFiles() {
        ArrayList<File> files = new ArrayList<>();
        ArrayList<Question> questions = questionsAdapter.data;
        for (int i = 0; i < questions.size(); i++) {
            Question question = questions.get(i);
            if (question.type.equals(Question.TYPE_IMAGE)) {
                files.add(question.filePicture);
            }
        }
        return files;
    }

    @Override
    public void onDateSet(DatePickerDialog view, int year, int monthOfYear, int dayOfMonth) {
        calendarSelectedDate.set(Calendar.YEAR, year);
        calendarSelectedDate.set(Calendar.MONTH, monthOfYear);
        calendarSelectedDate.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        TimePickerDialog tpd = TimePickerDialog.newInstance(
                this,
                calendarSelectedDate.get(Calendar.HOUR_OF_DAY),
                calendarSelectedDate.get(Calendar.MINUTE),
                calendarSelectedDate.get(Calendar.SECOND),
                true);
        tpd.show(getActivity().getFragmentManager(), "Timepickerdialog");
    }

    @Override
    public void onTimeSet(RadialPickerLayout view, int hourOfDay, int minute, int second) {
        calendarSelectedDate.set(Calendar.HOUR_OF_DAY, hourOfDay);
        calendarSelectedDate.set(Calendar.MINUTE, minute);
        calendarSelectedDate.set(Calendar.SECOND, second);
        questionsAdapter.data.get(positionDate).calendar = calendarSelectedDate;
        questionsAdapter.notifyDataSetChanged();
    }

    @Override
    public void setPresenter(DiagnosticContract.Presenter presenter) {
        mPresenter = checkNotNull(presenter);
    }

    @Override
    public void displayState(String state) {
        if (!isAdded()){
            return;
        }
        if (state.equalsIgnoreCase(NOTIFICATION_TYPE_CANCEL)){
            // Quitamos popup
            ((DrawerActivity)getActivity()).displayWaiting(null,false);

            errorDialog = new ErrorDialog(getContext(), "Su asistencia ha sido cancelada por el cliente");
            errorDialog.show();
            errorDialog.setCancelable(false);
            errorDialog.setCanceledOnTouchOutside(true);
            errorDialog.setOnCancelListener(dialog -> {
                // Volvemos al mapa
                //finish();
                ((DrawerActivity)getActivity()).setFragment(DrawerActivity.MAP_FRAGMENT);
            });

        }
    }

    @Override
    public void setQuestions(ArrayList<Question> questions) {
        mQuestions = questions;
    }

    @Override
    public void displayQuestions() {
        if (!isAdded()){
            return;
        }
        questionsAdapter.replaceAll(mQuestions);
        questionsAdapter.notifyDataSetChanged();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK){
            if (requestCode == PHOTO_CODE){
                MediaScannerConnection.scanFile(getContext(),
                        new String[]{mPath}, null,
                        (path, uriX) -> new Thread() {
                            public void run() {
                                getActivity().runOnUiThread(() -> {
                                    selectedFilePath = FilePath.getPath(getContext(), uriX);
                                    if (selectedFilePath != null && !selectedFilePath.equals("")) {
                                        File fileSelected = new File(selectedFilePath);
                                        fileSelected = getCompressImage(selectedFilePath,fileSelected);
                                        //questionsAdapter.data.get(viewPositionImage).filePicture = new File(selectedFilePath);
                                        questionsAdapter.data.get(viewPositionImage).filePicture = fileSelected;

                                        questionsAdapter.notifyDataSetChanged();
                                    }
                                });
                            }
                        }.start());
            }else if (requestCode == REQUEST_SELECT_LOCATION){
                Place place = PlaceAutocomplete.getPlace(getContext(),data);
                questionsAdapter.data.get(positionDirection).mPlace = place;
                questionsAdapter.notifyDataSetChanged();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == Functions.MY_PERMISSIONS_REQUEST_READ_EXTERNAL_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            }
        }

    }
}
