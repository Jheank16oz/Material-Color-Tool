package com.americanassist.proveedor;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.americanassist.proveedor.adapters.PendingAssistanceAdapter;
import com.americanassist.proveedor.R;
import com.americanassist.proveedor.commons.Controllers.BaseActivity;
import com.americanassist.proveedor.cranecost.CraneCostFragment;
import com.americanassist.proveedor.dialogs.ErrorDialog;
import com.americanassist.proveedor.dialogs.TwoOptionsDialog;
import com.americanassist.proveedor.managers.Server.ApiManager;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.Assistance;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.model.RequestAssistance;
import com.americanassist.proveedor.rejectassistance.RejectAssistanceActivity;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

import jp.wasabeef.recyclerview.animators.SlideInUpAnimator;

import static com.americanassist.proveedor.BaseApplication.getInstance;
import static com.americanassist.proveedor.MoreInfoActivity.CURRENT_ASSISTANCE;

/**
 * Vista de Solicites pendientes
 */
public class PendingRequestsActivity extends BaseActivity implements PendingAssistanceAdapter.OnItemClickListener,PendingAssistanceAdapter.OnReloadClickListener, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, PendingAssistanceAdapter.PendingAssistanceAdapterListener {

    private static final int PAGE_SIZE = 5;
    /**
     * Request code para el cancelado de asistencia.
     */
    private static final int CANCEL_ASSISTANCE = 6;

    /**
     * Key para enviar si el sonido de notificacion
     * debe ser mostrado.
     */
    public static final String PLAY_NOTIFICATION = "playNotification";


    private RelativeLayout rlBack;
    protected RecyclerView mAssistanceRecyclerView;

    private Context mContext;
    private PendingAssistanceAdapter mPendingAssistanceAdapter;
    protected LinearLayoutManager mLinearLayoutManager;
    public GoogleApiClient mGoogleApiClient;

    private boolean isLoading = false;
    private boolean isLastPage = false;

    /**
     * Objetivo para almacenar si la vista de Solicitudes pendientes esta en primer plano
     */
    public static boolean isPendingCreated = false;

    @Override
    protected void onStart() {
        super.onStart();
        isPendingCreated = true;
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pending_requests);

        rlBack = findViewById(R.id.APR_relativelayout_back);
        mAssistanceRecyclerView = findViewById(R.id.APR_recyclerview_listitems);
        TextView tatNoAssistance = findViewById(R.id.APR_textview_noassistances);

        mContext = this;
        tatNoAssistance.setVisibility(View.GONE);
        mLinearLayoutManager = new LinearLayoutManager(this);
        mAssistanceRecyclerView.setLayoutManager(mLinearLayoutManager);

        // Google Api
        if (mGoogleApiClient == null) {
            mGoogleApiClient = new GoogleApiClient.Builder(this)
                    .addApi(LocationServices.API)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .build();
        }
        initListeners();

        mGoogleApiClient.connect();
        showLoadingView();

        if (getIntent().getBooleanExtra(PLAY_NOTIFICATION,false)) {
            getIntent().removeExtra(PLAY_NOTIFICATION);
            notification();
        }

    }



    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent.getBooleanExtra(PLAY_NOTIFICATION,false)) {
            notification();
        }else{
            stopNotification();
        }
        refreshList();
    }

    private void refreshList() {
        if (mPendingAssistanceAdapter != null) {
            mPendingAssistanceAdapter.clearAll();
            mPendingAssistanceAdapter.addFooter();

            pagination = 0;
            isLastPage = false;


            loadMoreData();
        }else {
            if (mGoogleApiClient!=null && !mGoogleApiClient.isConnected()) {
                mGoogleApiClient.connect();
            }else{
                mGoogleApiClient = new GoogleApiClient.Builder(this)
                        .addApi(LocationServices.API)
                        .addConnectionCallbacks(this)
                        .addOnConnectionFailedListener(this)
                        .build();

                mGoogleApiClient.connect();
            }
        }
    }


    private void initListeners() {
        rlBack.setOnClickListener(v -> finish());
    }

    private void loadMoreData() {


        askForPermission(android.Manifest.permission.ACCESS_FINE_LOCATION, null, new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                try {
                    Location mLastLocation;
                    mLastLocation = LocationServices.FusedLocationApi.getLastLocation(
                            mGoogleApiClient);
                    if (mLastLocation != null) {
                        Provider mProvider = SharedPreferencesManager.getProvider(getBaseContext());
                        if (mProvider == null){
                            return;
                        }

                        // PendingAssistanceAdapter.showLoading();
                        new ApiManager(mContext).getAvailableAssistances(mProvider.country, mProvider.idProvider, mProvider.idContact, mLastLocation.getLatitude(), mLastLocation.getLongitude(), pagination, new ApiManagerHelper.ApiGetAvailableAssistancesCallback() {
                            @Override
                            public void onGetAvailableAssistancesSuccess(ArrayList<RequestAssistance> assistances, int pagination) {
                                mPendingAssistanceAdapter.removeFooter();

                                if (assistances != null) {
                                    if(assistances.size()>0)
                                        mPendingAssistanceAdapter.addAll(assistances);

                                    if (assistances.size() >= PAGE_SIZE) {
                                        mPendingAssistanceAdapter.addFooter();
                                    } else {
                                        isLastPage = true;
                                        Toast.makeText(mContext, R.string.no_mas_asistencias_disponibles, Toast.LENGTH_SHORT).show();
                                    }
                                }

                                isLoading = false;
                                PendingRequestsActivity.this.pagination = pagination;


                            }

                            @Override
                            public void onGetAvailableAssistancesError(String error) {
                                // PendingAssistanceAdapter.hideLoading();
                                mPendingAssistanceAdapter.updateFooter(PendingAssistanceAdapter.FooterType.ERROR);
                                isLoading = false;
                                isLastPage = true;
                            }

                            @Override
                            public void onGetAvailableAssistancesFull() {
                                mPendingAssistanceAdapter.removeFooter();
                                Toast.makeText(getBaseContext(), R.string.no_mas_asistencias_disponibles,Toast.LENGTH_SHORT).show();
                                isLastPage = true;
                            }
                        });

                    } else {
                        Snackbar.make(((ViewGroup) findViewById(android.R.id.content)).getChildAt(0), "Necesitamos conocer tu ubicacion", Snackbar.LENGTH_LONG).show();
                    }
                } catch (SecurityException e) {
                    e.printStackTrace();
                    Snackbar.make(((ViewGroup) findViewById(android.R.id.content)).getChildAt(0), "Necesitamos conocer tu ubicacion", Snackbar.LENGTH_LONG).show();
                }
            }

            @Override
            public void onPermissionDenied() {
                Snackbar.make(((ViewGroup) findViewById(android.R.id.content)).getChildAt(0), "Necesitamos conocer tu ubicacion", Snackbar.LENGTH_LONG).show();
            }
        });
    }

    @Override
    public void onDestroy() {
        // destruimos el sonido encaso de que se este reproduciendo en segundo plano
        stopNotification();
        // reiniciamos la variable de asistencia creada
        isPendingCreated = false;
        mGoogleApiClient.disconnect();
        super.onDestroy();
    }

    private  int pagination = 0;
    @Override
    public void onConnected(@Nullable Bundle bundle) {
        hideLoadingView();
        mAssistanceRecyclerView.setItemAnimator(new SlideInUpAnimator());
        mPendingAssistanceAdapter = new PendingAssistanceAdapter(this,this);
        mPendingAssistanceAdapter.setOnItemClickListener(this);
        mPendingAssistanceAdapter.setOnReloadClickListener(this);
        mAssistanceRecyclerView.setAdapter(mPendingAssistanceAdapter);


        //Paginacion
        mAssistanceRecyclerView.addOnScrollListener(recyclerViewOnScrollListener);

        mPendingAssistanceAdapter.addFooter();
        loadMoreData();
    }


    private RecyclerView.OnScrollListener recyclerViewOnScrollListener = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
        }

        @Override
        public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            int visibleItemCount = mLinearLayoutManager.getChildCount();
            int firstVisibleItemPosition = mLinearLayoutManager.findFirstVisibleItemPosition();
            int lastVisibleItemPosition = mLinearLayoutManager.findLastVisibleItemPosition();

            if (!isLoading && !isLastPage) {
                if ((firstVisibleItemPosition + visibleItemCount) > pagination) {
                    if (firstVisibleItemPosition>0) {
                        isLoading = true;
                        loadMoreData();
                    }
                }
            }

        }
    };

    @Override
    public void onConnectionSuspended(int i) {
        hideLoadingView();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        hideLoadingView();
    }

    @Override
    public void onConfirmClicked(final RequestAssistance assistance) {
        TwoOptionsDialog twoOptionsDialog = new TwoOptionsDialog(mContext,getString(R.string.confirma_asistencia_titulo), getString(R.string.confirma_asistencia_content) +" "+ assistance.serviceName + "?", getString(R.string.cancelar), getString(R.string.confirmar), new TwoOptionsDialog.TwoOptionsDialogListener() {
            @Override
            public void onCancelClicked() {

            }

            @Override
            public void onAcceptClicked() {
                askForPermission(android.Manifest.permission.ACCESS_FINE_LOCATION, null, new PermissionListener() {
                    @Override
                    public void onPermissionGranted() {
                        try {
                            showLoadingView();

                            LatLng mCurrentLocation = getInstance().getCurrentLocation();
                            // Si current location es nulo: lo solicitamos
                            if (mCurrentLocation == null) {
                                Location mLastLocation = LocationServices.FusedLocationApi.getLastLocation(
                                        mGoogleApiClient);
                                if (mLastLocation != null) {
                                    getInstance().setCurrentLocation(new LatLng(mLastLocation.getLatitude(),mLastLocation.getLongitude()));
                                }
                            }
                            Provider mProvider = SharedPreferencesManager.getProvider(getBaseContext());
                            if (mProvider!=null){
                                acceptAssistance(mProvider,assistance);
                            }



                        } catch (SecurityException e) {
                            e.printStackTrace();
                            Snackbar.make(((ViewGroup) findViewById(android.R.id.content)).getChildAt(0), "Necesitamos conocer tu ubicacion", Snackbar.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onPermissionDenied() {
                        Snackbar.make(((ViewGroup) findViewById(android.R.id.content)).getChildAt(0), "Necesitamos conocer tu ubicacion", Snackbar.LENGTH_LONG).show();
                    }
                });
            }
        });
        twoOptionsDialog.show();
    }

    private void acceptAssistance(@NonNull Provider mProvider, final Assistance assistance) {
        LatLng mCurrentLocation = getInstance().getCurrentLocation();
        new ApiManager(mContext).acceptAssistance(
                mProvider.country,
                assistance.id, mProvider.idProvider,
                mProvider.idContact,
                mCurrentLocation.latitude,
                mCurrentLocation.longitude,assistance.serviceId,
                assistance.acceptAssistance, new ApiManagerHelper.ApiAcceptAssistanceCallback() {

                    @Override
                    public void onAcceptAssistanceSuccess(boolean showCosts, String costs, String route1, String route2, String distance) {
                        hideLoadingView();
                        assistance.route1 = route1;
                        assistance.route2 = route2;

                        // Si hay que mostrar costos: estamos en una asistencia de grua: vamos a los costos
                        if (showCosts) {

                                Intent i = new Intent();
                                i.putExtra(CraneCostFragment.ASSISTANCE_ID, assistance.id);
                                i.putExtra(CraneCostFragment.ASSISTANCE_ROUTE1, assistance.route1);
                                i.putExtra(CraneCostFragment.ASSISTANCE_ROUTE2, assistance.route2);
                                i.putExtra(CraneCostFragment.COSTS, costs);
                                i.putExtra(CraneCostFragment.DISTANCE, distance);


                                setResult(Activity.RESULT_OK, i);

                                finish();


                        }
                        // Si no hay que mostrar costos: estamos en una asistencia normal, volvemos al mapa
                        else {
                            Intent i = new Intent();
                            i.putExtra(DrawerActivity.REFRESH_STATE,true);
                            setResult(Activity.RESULT_OK,i);
                            finish();
                        }
                    }

                    @Override
                    public void onAcceptAssistanceError(String error) {
                        hideLoadingView();
                        ErrorDialog errorDialog = new ErrorDialog(mContext, error, true);
                        errorDialog.show();
                    }
                });
    }

    @Override
    public void onRejectClicked(final RequestAssistance assistance) {
        Intent i = new Intent(this,RejectAssistanceActivity.class);
        i.putExtra(RejectAssistanceActivity.ASSISTANCE_ID, assistance.id);
        i.putExtra(RejectAssistanceActivity.REJECT_TYPE, RejectAssistanceActivity.REQUEST_ASSISTANCE);
        startActivityForResult(i,CANCEL_ASSISTANCE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CANCEL_ASSISTANCE){
            if (resultCode == RESULT_OK){
                Snackbar.make(findViewById(android.R.id.content), R.string.asistencia_rechazada_mensaje_correcto,Snackbar.LENGTH_SHORT).show();
                refreshList();
            }
        }
    }

    @Override
    public void onMoreInfoClicked(RequestAssistance assistance) {
        Intent detailIntent = new Intent(PendingRequestsActivity.this, MoreInfoActivity.class);
        detailIntent.putExtra(CURRENT_ASSISTANCE,assistance);
        startActivity(detailIntent);
    }

    @Override
    public void onItemClick(int position, View view) {

    }

    @Override
    public void onReloadClick() {
        mPendingAssistanceAdapter.updateFooter(PendingAssistanceAdapter.FooterType.LOAD_MORE);
        loadMoreData();
    }

}
