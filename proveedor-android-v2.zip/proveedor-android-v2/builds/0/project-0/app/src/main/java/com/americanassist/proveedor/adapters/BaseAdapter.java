package com.americanassist.proveedor.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * Se define como plantilla para los adaptadores que extiende de
 * RecyclerView.Adapter, Contiene funciones y metodos para los controles
 * de paginador y animaciones.
 */

public abstract class BaseAdapter<T> extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    // region Constants
    protected static final int HEADER = 0;
    protected static final int ITEM = 1;
    protected static final int FOOTER = 2;
    // endregion

    // region Member Variables
    protected List<T> items;
    protected OnItemClickListener onItemClickListener;
    protected OnReloadClickListener onReloadClickListener;
    protected boolean isFooterAdded = false;
    // endregion

    // region Interfaces
    public interface OnItemClickListener {
        void onItemClick(int position, View view);
    }

    /**
     * Callback para notificar que se refresco la
     * lista
     */
    public interface OnReloadClickListener {
        void onReloadClick();
    }
    // endregion

    // region Constructors
    public BaseAdapter() {
        items = new ArrayList<>();
    }
    // endregion

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder viewHolder = null;

        switch (viewType) {
            case HEADER:
                viewHolder = createHeaderViewHolder(parent);
                break;
            case ITEM:
                viewHolder = createItemViewHolder(parent);
                break;
            case FOOTER:
                viewHolder = createFooterViewHolder(parent);
                break;
            default:
                break;
        }

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int position) {
        switch (getItemViewType(position)) {
            case HEADER:
                bindHeaderViewHolder(viewHolder);
                break;
            case ITEM:
                bindItemViewHolder(viewHolder, position);
                break;
            case FOOTER:
                bindFooterViewHolder(viewHolder);
            default:
                break;
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    // region Abstract Methods
    protected abstract RecyclerView.ViewHolder createHeaderViewHolder(ViewGroup parent);

    protected abstract RecyclerView.ViewHolder createItemViewHolder(ViewGroup parent);

    protected abstract RecyclerView.ViewHolder createFooterViewHolder(ViewGroup parent);

    protected abstract void bindHeaderViewHolder(RecyclerView.ViewHolder viewHolder);

    protected abstract void bindItemViewHolder(RecyclerView.ViewHolder viewHolder, int position);

    protected abstract void bindFooterViewHolder(RecyclerView.ViewHolder viewHolder);

    protected abstract void displayLoadMoreFooter();

    protected abstract void displayErrorFooter();

    public abstract void addFooter();
    // endregion

    // region Helper Methods
    public T getItem(int position) {
        return items.get(position);
    }

    public void add(T item) {
        items.add(item);
        notifyItemInserted(items.size() - 1);
    }

    /**
     * Metodo encargado de gestionar las
     * listas de items que se desean agregae
     */
    public void addAll(List<T> items) {
        for (T item : items) {
            add(item);
        }
    }

    /**
     * Encargado de remover un item
     * del Collection
     */
    private void remove(T item) {
        int position = items.indexOf(item);
        if (position > -1) {
            items.remove(position);
            notifyItemRemoved(position);
        }
    }

    /**
     * Limpia los items y notifica los
     * cambios al adaptador
     */
    public void clearAll(){
        items.clear();
        notifyDataSetChanged();
    }

    public void clear() {
        isFooterAdded = false;
        while (getItemCount() > 0) {
            remove(getItem(0));
        }
    }

    public boolean isEmpty() {
        return getItemCount() == 0;
    }

    /**
     * Valida mediante una posicion  si es la ultima
     * posicion
     * @param position para validar
     * @return si es la ultima posicion
     */
    public boolean isLastPosition(int position) {
        return (position == items.size()-1);
    }

    /**
     * Elimina el Footer de la lista
     */
    public void removeFooter() {
        isFooterAdded = false;

        int position = items.size() - 1;
        if (position > -1) {
            T item = getItem(position);

            if (item != null) {
                items.remove(position);
                notifyItemRemoved(position);
            }
        }
    }

    /**
     * Actualiza el Footer a partir de un tipo
     * @param footerType tipo de footer
     */
    public void updateFooter(FooterType footerType){
        switch (footerType) {
            case LOAD_MORE:
                displayLoadMoreFooter();
                break;
            case ERROR:
                displayErrorFooter();
                break;
            default:
                break;
        }
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void setOnReloadClickListener(OnReloadClickListener onReloadClickListener) {
        this.onReloadClickListener = onReloadClickListener;
    }
    // endregion

    // region Inner Classes

    /**
     * Typos de Footer para actualizar la vista
     */
    public enum FooterType {
        LOAD_MORE,
        ERROR
    }
    // endregion
}