package com.americanassist.proveedor.services;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;

import com.americanassist.proveedor.BuildConfig;
import com.americanassist.proveedor.DrawerActivity;
import com.americanassist.proveedor.managers.Server.ApiManager;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.utils.ConfigUtils;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.model.LatLng;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;

import io.socket.client.Manager;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

import static android.content.ContentValues.TAG;
import static com.americanassist.proveedor.BaseApplication.getInstance;

/**
 * <p>Servicio encargado de la gestion de envio de coordenadas y
 * Notificaciones en tiempo real.
 * Contine una comunicacion fija con DrawerActivity para el envio de coordenadas
 * y notificaciones por Socket.</p>
 */
public class ActiveRequestService extends Service implements GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener, SocketEvents.NotificationListener, TimeAndDistanceSocketEvents.InfoAssistanceListener {

    private GoogleApiClient mGoogleApiClient;
    private LocationRequest mLocationRequest;
    private ApiManager apiManager;
    private Socket socket;

    /**
     * Key para envio de notificaciones a la actividad {@link DrawerActivity}
     */
    public static final String NEW_NOTIFICATION = "notification";

    /**
     * Key para envio de distancia a la actividad {@link DrawerActivity}
     */
    public static final String NEW_DISTANCE = "distance";

    /**
     * Key para envio de tiempo a la actividad {@link DrawerActivity
     */
    public static final String NEW_TIME = "time";

    /**
     * Key para envio de tiempo a la actividad {@link DrawerActivity}
     */
    public static final String NEW_DIRECTION= "direction";


    /**
     * Key para envio de mensajes de notificaciones a la actividad {@link DrawerActivity}
     */
    public static final String NOTIFICATION_MESSAGE = "notificationMessage";

    /**
     * Comando para establecer que hubo una actualizacion mediante la
     * ubicacon del servicio.
     */
    public static final String LOCATION_STATUS_UPDATE = "locationStatusUpdated";

    /**
     * Comando para indicar que hay una confirmacion de arribo por
     * parte del cliente.
     */
    public static final String LOCATION_STATUS_ARRIVE = "locationStatusArribo";

    /**
     *  Comando para indicar que el estado de diagnostico de una
     *  asistencia.
     */
    public static final String LOCATION_STATUS_DIAGNOSTIC = "locationStatusDiagnostico";

    /** Comando que indica el estado final de un asistencia. */
    public static final String LOCATION_STATUS_FINAL = "locationStatusTermino";


    /** Key para compartir la ultima latitud obtenida */
    public static final String LOCATION_LATITUDE = "latitude";

    /** Key para compartir la ultima longitud obtenida */
    public static final String LOCATION_LONGITUDE = "longitude";

    /** Key para compartir la ultima longitud obtenida */
    public static final String LOCATION_BEARING = "bearing";

    /** Key para compartir el ultimo estado obtenido */
    public static final String LOCATION_STATUS_ASSISTANCE = "stateAssistance";

    /** Key para compartir un estado vacio de ubicacion */
    public static final String LOCATION_STATE_EMPTY = "";

    /** Realiza un seguimiento de todos los clientes registrados actuales. */
    ArrayList<Messenger> mClients = new ArrayList<>();

    /** Mantiene el ultimo valor establecido  por el cliente*/
    Bundle mValue = new Bundle();

    /**
     * objetivo creado para que los clientes envien mensajes a IncomingHandler.
     */
    final Messenger mMessenger = new Messenger(new IncomingHandler());

    /**
     * Comando al servicio para para registrar un cliente, recibiendo devoluciones de llamada
     * del servicio. El campo replyTo del mensaje debe ser un Messenger de
     * el cliente donde se deben enviar devoluciones de llamada.
     */
    public static final int MSG_REGISTER_CLIENT = 1;

    /**
     * Comando al servicio para cancelar el registro de un cliente, o dejar de recibir devoluciones de llamada
     * del servicio. El campo replyTo del mensaje debe ser un Messenger de
     * el cliente como previamente dado con MSG_REGISTER_CLIENT.
     */
    public static final int MSG_UNREGISTER_CLIENT = 2;

    /**
     * Comando al servicio para establecer un nuevo valor. Esto puede ser enviado al
     * servicio para suministrar un nuevo valor, y sera enviado por el servicio a
     * cualquier cliente registrado con el nuevo valor.
     */
    public static final int MSG_SET_VALUE = 3;


    /**
     * Comando al servicio para indicarle que es necesario que envie una
     * actualizacion de ubicacion al servidor y que limpie la informacion de
     * la asistencia ya que ha sido cancelada.
     */
    public static final int MSG_NEED_CLEAN_ASSISTANCE = 4;

    /**
     * Comando al servicio para indicarle que es necesario que envie una
     * actualizacion de ubicacion al servidor
     */
    public static final int MSG_UPDATE_LOCATION = 5;

    /**
     * Comando al servicio para establecer un nuevo valor. Esto puede ser enviado al
     * servicio para suministrar un nuevo valor, y sera enviado por el servicio a
     * cualquier cliente registrado con el nuevo valor.
     */
    public static final int MSG_SET_NOTIFICATION = 6;

    /**
     * Comando a la lista de solicitudes para informarle que hay una asistencia
     * nueva.
     */
    public static final int MSG_ADD_ASSISTANCE = 7;

    /**
     * Comando a la vista del mapa para informar que hay un cambio de tiempo y
     * distancia informado por parte del servidor.
     */
    public static final int MSG_UPDATE_INFO_ASSISTANCE = 8;


    /**
     * Comando a la lista de solicitudes para informarle que hay una asistencia
     * cancelada.
     */
    public static final int MSG_CANCEL_ASSISTANCE = 9;

    /** objetivo declarado para guardar el ultimo estado del usuario */
    private static String assistanceState = LOCATION_STATE_EMPTY;

    private LatLng mLastLng;

    @Override
    public IBinder onBind(Intent intent) {
        return mMessenger.getBinder();
    }

    Provider currentProvider;

    @Override
    public void onCreate() {
        super.onCreate();

        try {
            Manager manager = new Manager(new URI("https://www.seguimientooperativo.site/socket.io/"));
            socket = manager.socket("/");
            socket.on(Socket.EVENT_CONNECT, new Emitter.Listener() {

                @Override
                public void call(Object... args) {
                    Log.e("ActiveRequestService", "Me conecte");
                }

            }).on("event", new Emitter.Listener() {

                @Override
                public void call(Object... args) {
                    Log.e("ActiveRequestService", "Algo recibo: " + Arrays.toString(args));
                }

            }).on(Socket.EVENT_DISCONNECT, new Emitter.Listener() {

                @Override
                public void call(Object... args) {
                    Log.e("ActiveRequestService", "Me destruyo");
                }

            });
            socket.connect();

            currentProvider = SharedPreferencesManager.getProvider(getApplicationContext());
            if (currentProvider == null) {
                return;
            }

            socket.on(String.format(BuildConfig.REGEX_SOCKET_COORDS,
                    currentProvider.country, currentProvider.idProvider, currentProvider.idContact),
                    new SocketEvents(this));

            String a = String.format(BuildConfig.REGEX_SOCKET_DISTANCE_MATRIX,
                    currentProvider.country, currentProvider.idProvider, currentProvider.idContact);

            Log.e("connect",a);
            socket.on(a, new TimeAndDistanceSocketEvents(this));


        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        /* Objetivo para almacenar el contexto*/
        Context context = getApplicationContext();
        apiManager = new ApiManager(context);

        if (checkPermission(context)) {
            if (checkPlayServices()) {


                /*
                 * Cantidad de metros establecidos para la actualizacon de ubicacion
                 * de LocationRequest.
                 */
                long smallestDisplacement = ConfigUtils.getDistanceConfiguration(getBaseContext());

                mLocationRequest = new LocationRequest().create();
                mLocationRequest.setFastestInterval(0);// importante asignarle el intervalo
                mLocationRequest.setSmallestDisplacement(smallestDisplacement);
                mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

                mGoogleApiClient = new GoogleApiClient.Builder(context)
                        .addApi(LocationServices.API)
                        .addConnectionCallbacks(this)
                        .addOnConnectionFailedListener(this)
                        .build();
                mGoogleApiClient.connect();
            }
        }
        return Service.START_STICKY;
    }

    @Override
    public void onDestroy() {
        if(mGoogleApiClient != null){
            LocationServices.FusedLocationApi.removeLocationUpdates(mGoogleApiClient,this);
            mGoogleApiClient.disconnect();
        }

        if (socket.connected()) {
            socket.disconnect();
        }
        super.onDestroy();
    }

    public boolean checkPermission(Context context) {
        int MyVersion = Build.VERSION.SDK_INT;
        return MyVersion <= Build.VERSION_CODES.LOLLIPOP_MR1 || ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean checkPlayServices() {
        GoogleApiAvailability googleAPI = GoogleApiAvailability.getInstance();
        int result = googleAPI.isGooglePlayServicesAvailable(this);
        return result == ConnectionResult.SUCCESS;
    }

    private void startLocationUpdates() {
        if (mGoogleApiClient.isConnected()) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            LocationServices.FusedLocationApi.requestLocationUpdates(mGoogleApiClient, mLocationRequest, this);
        }
    }



    @Override
    public void onLocationChanged(final Location location) {
        getInstance().setCurrentLocation(new LatLng(location.getLatitude(),location.getLongitude()));
        updateLocation(new LatLng(location.getLatitude(),location.getLongitude()));
    }


    private void updateLocation(final LatLng location) {
        mLastLng = location;
        sendToServerUpdate(location);
    }

    private void sendToServerUpdate(final LatLng location) {
        if (currentProvider == null ||  apiManager == null) {
            return;
        }

        //Enviamos nuestra posicion por el API
        apiManager.sendLocation(currentProvider.idProvider, currentProvider.idContact,
                location.latitude,
                location.longitude, currentProvider.country, new ApiManagerHelper.ApiSendLocationCallback() {
                    @Override
                    public void onSendLocationSuccess(boolean showArrive, boolean diagnostic, boolean termino, boolean hasAssistance, String coordinatesState) {

                        if (!hasAssistance) {
                            //limpiamos el estado del proveedor
                            assistanceState = LOCATION_STATE_EMPTY;
                        }

                        // Mostrar boton confirmar arribo
                        if (showArrive) {
                            assistanceState = LOCATION_STATUS_ARRIVE;
                            sendHandlerCurrentLocation();
                        }
                        // Mostrar boton diagnostico
                        else if (diagnostic) {
                            assistanceState = LOCATION_STATUS_DIAGNOSTIC;
                            sendHandlerCurrentLocation();
                        }
                        // Mostrar boton termino
                        else if (termino){
                            assistanceState = LOCATION_STATUS_FINAL;
                            sendHandlerCurrentLocation();

                        }else{
                            // vaciamos el estado de la asistencia y enviamos
                            // la actualizacion de ubicacion de igual forma
                            // dado el caso que no estemos en nigun estado de
                            // los casos anteriores.
                            assistanceState = LOCATION_STATE_EMPTY;
                            sendHandlerCurrentLocation();


                        }

                    }

                    @Override
                    public void onSendLocationError(String error) {
                        Log.e("send location error",error);
                    }
                });

    }

    public void sendHandlerCurrentLocation() {
        try {
            if (mValue!=null) {
                mMessenger.send(Message.obtain(null, MSG_SET_VALUE, mValue));
            }

        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        startLocationUpdates();
    }

    @Override
    public void onConnectionSuspended(int i) {
        Log.i(TAG, "Connected to onConnectionSuspended");
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
    }

    @Override
    public void onNotification(String state, String message) {
        try {
            Bundle bundle = new Bundle();
            bundle.putString(NEW_NOTIFICATION,state);
            bundle.putString(NOTIFICATION_MESSAGE,message);
            mMessenger.send(Message.obtain(null, MSG_SET_NOTIFICATION, bundle));
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        sendCurrentLocationToServer();
    }

    /**
     * Notificamos al servicio para indicarle que es necesario que envie la
     * ubicacion actual al servidor, esto debido a que el estado del proveedor
     * ha cambiado.
     */
    public void sendCurrentLocationToServer(){
        LatLng mCurrentLocation = getInstance().getCurrentLocation();
        Double latitude = mCurrentLocation!=null?mCurrentLocation.latitude:0.0;
        Double longitude = mCurrentLocation!=null?mCurrentLocation.longitude:0.0;
        updateLocation(new LatLng(latitude,longitude));
    }

    @Override
    public void onNewRequest() {
        try {
            mMessenger.send(Message.obtain(null, MSG_ADD_ASSISTANCE));
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onCancelAssistance() {
        try {
            mMessenger.send(Message.obtain(null, MSG_CANCEL_ASSISTANCE));
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onInfoAssistanceUpdate(String time, String distance, String direction) {
        try {
            Bundle bundle = new Bundle();
            bundle.putString(NEW_TIME,time);
            bundle.putString(NEW_DISTANCE,distance);
            bundle.putString(NEW_DIRECTION,direction);
            mMessenger.send(Message.obtain(null, MSG_UPDATE_INFO_ASSISTANCE, bundle));
        } catch (RemoteException e) {
            e.printStackTrace();
        }

    }

    @SuppressLint("HandlerLeak")
    class IncomingHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            LatLng mCurrentLocation = getInstance().getCurrentLocation();
            float bearing = getInstance().getBearing();

            double latitude = mCurrentLocation!=null?mCurrentLocation.latitude:mLastLng!=null?mLastLng.latitude:0.0;
            double longitude = mCurrentLocation!=null?mCurrentLocation.longitude:mLastLng!=null?mLastLng.longitude:0.0;

            switch (msg.what) {
                case MSG_REGISTER_CLIENT:
                    mClients.add(msg.replyTo);
                    break;
                case MSG_UNREGISTER_CLIENT:
                    mClients.remove(msg.replyTo);
                    break;

                case MSG_NEED_CLEAN_ASSISTANCE:
                    assistanceState = LOCATION_STATE_EMPTY;
                    // Actualizamos la ubicacion, para que pueda estar
                    // libre nuevamente
                    updateLocation(new LatLng(latitude,longitude));
                    break;

                case MSG_UPDATE_LOCATION:
                    // Actualizamos la ubicacion
                    updateLocation(new LatLng(latitude,longitude));
                    break;

                case MSG_SET_VALUE:
                    mValue = (Bundle) msg.obj;
                    for (int i = 0; i < mClients.size(); i++) {
                        try {

                            mValue.putString("locations",mCurrentLocation!=null?mCurrentLocation.toString():"Vacio");
                            mValue.putString(LOCATION_STATUS_ASSISTANCE,assistanceState);
                            mValue.putDouble(LOCATION_LATITUDE,latitude);
                            mValue.putDouble(LOCATION_LONGITUDE,longitude);
                            mValue.putFloat(LOCATION_BEARING,bearing);
                            mValue.putBoolean(LOCATION_STATUS_UPDATE,true);
                            mClients.get(i).send(Message.obtain(null,MSG_SET_VALUE,mValue));

                        } catch (RemoteException e) {
                            // El cliente esta muerto. Eliminarlo de la lista;
                            // estamos revisando la lista de atras hacia adelante
                            // entonces esto es seguro de hacer dentro del ciclo.
                            mClients.remove(i);
                            e.printStackTrace();
                        }
                    }

                    break;
                case MSG_SET_NOTIFICATION:
                    // evento llamado cuando se manda una notificacion por
                    // socket
                    for (int i = 0; i < mClients.size(); i++) {
                        try {
                            mClients.get(i).send(Message.obtain(null,MSG_SET_NOTIFICATION,msg.obj));

                        } catch (RemoteException e) {
                            // El cliente esta muerto. Eliminarlo de la lista;
                            // estamos revisando la lista de atras hacia adelante
                            // entonces esto es seguro de hacer dentro del ciclo.
                            mClients.remove(i);

                        }
                    }
                    break;

                case MSG_ADD_ASSISTANCE:
                    // evento llamado cuando llega una nueva asistencia
                    for (int i = 0; i < mClients.size(); i++) {
                        try {
                            mClients.get(i).send(Message.obtain(null,MSG_ADD_ASSISTANCE));

                        } catch (RemoteException e) {
                            // El cliente esta muerto. Eliminarlo de la lista;
                            // estamos revisando la lista de atras hacia adelante
                            // entonces esto es seguro de hacer dentro del ciclo.
                            mClients.remove(i);
                        }
                    }
                    break;

                case MSG_CANCEL_ASSISTANCE:
                    // evento llamado cuando llega una nueva asistencia
                    for (int i = 0; i < mClients.size(); i++) {
                        try {
                            mClients.get(i).send(Message.obtain(null,MSG_CANCEL_ASSISTANCE));

                        } catch (RemoteException e) {
                            // El cliente esta muerto. Eliminarlo de la lista;
                            // estamos revisando la lista de atras hacia adelante
                            // entonces esto es seguro de hacer dentro del ciclo.
                            mClients.remove(i);
                        }
                    }
                    break;

                case MSG_UPDATE_INFO_ASSISTANCE:
                    // evento llamado cuando se manda una notificacion  de cambio de tiempo y distancia
                    for (int i = 0; i < mClients.size(); i++) {
                        try {
                            mClients.get(i).send(Message.obtain(null, MSG_UPDATE_INFO_ASSISTANCE,msg.obj));

                        } catch (RemoteException e) {
                            // El cliente esta muerto. Eliminarlo de la lista;
                            // estamos revisando la lista de atras hacia adelante
                            // entonces esto es seguro de hacer dentro del ciclo.
                            mClients.remove(i);

                        }
                    }
                    break;
                default:
                    super.handleMessage(msg);
            }
        }
    }




}
