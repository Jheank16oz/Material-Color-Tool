package com.americanassist.proveedor.utils

import android.content.Context
import android.util.Log
import com.americanassist.proveedor.managers.Server.ApiManagerHelper
import org.json.JSONException
import org.json.JSONObject

/**
 *
 * Esta Clase es la encargada de gestionar la configuracion de la app
 * y guardar las opciones en preferencias.
 */
class ConfigManager(private val context:Context, private val mConfigurationCallback: ApiManagerHelper.GetConfigurationCallback){

    fun configureAppFromJsonResponse(response: JSONObject?){
        if(response==null){
            mConfigurationCallback.onFailureConfigurationLoaded()
            return
        }

        if (!response.has("api_key")) {
            mConfigurationCallback.onFailureConfigurationLoaded()
        } else {
            Log.e("res key",response.toString())
            try {
                // guardamos las configuraciones
                ConfigUtils.setActiveDistanceMatrixApiKey(context, response.getJSONArray("api_key").getJSONObject(0).getString("api_key"))
                ConfigUtils.setDisplayAssistanceHistory(context, response.optInt("historial_servicios", 1))

            } catch (e: JSONException) {
                e.printStackTrace()
            }

            if (response.optInt("distancia_envio_coordenadas") != 0 && response.optInt("envio_tiempo_coordenadas") != 0) {
                ConfigUtils.setTimeAndDistanceLocation(context, response.optInt("distancia_envio_coordenadas"))
                mConfigurationCallback.onSuccessConfigurationLoaded()
            } else {
                mConfigurationCallback.onFailureConfigurationLoaded()
            }
        }
    }

}