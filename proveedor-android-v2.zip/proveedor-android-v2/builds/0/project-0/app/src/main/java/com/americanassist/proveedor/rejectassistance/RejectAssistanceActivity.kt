package com.americanassist.proveedor.rejectassistance

import android.app.Activity
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity
import android.view.MenuItem
import android.view.View
import android.widget.RadioButton
import com.americanassist.proveedor.R
import com.americanassist.proveedor.dialogs.TwoOptionsDialog
import com.americanassist.proveedor.model.JustificationRejection
import kotlinx.android.synthetic.main.activity_reject_assistance.*
import kotlinx.android.synthetic.main.progress.*
import kotlinx.android.synthetic.main.refresh_layout.*

/**
 *
 * <p>Esta clase es la encargada del rechazo de las asistencias para
 * lo cual posee actualmente dos tipos de 'REQUEST' {PROCESS_ASSISTANCE,REQUEST_ASSISTANCE},
 * dependiendo del tipo de asistencia se cancelara una asistencia en proceso o
 * se rechazara una asistencia.
 *
 * La actividad se encarga de ejecutar el POST de cancelado o rechazo dependiendo del
 * 'REQUEST', al final devolvera un resultado por medio de un intent
 * {RejectAssistanceActivity #sendResult}</p>
 */

class RejectAssistanceActivity : AppCompatActivity(), RejectContract.View{


    override fun setPresenter(presenter: RejectContract.Presenter?) =//ignored
            Unit

    companion object {
        /**
         * Comando a RejectAssistanceActivity para indicar el tipo de cancelado
         */
        @JvmField var REJECT_TYPE = "tipo_cancelado"

        /**
         * Tipo de cancelado para indicar que la asistencia a cancelar es una
         * en proceso
         */
        @JvmField var PROCESS_ASSISTANCE = "cancel_assistance"

        /**
         * Tipo de cancelado para indicar que la asistencia a cancelar es una
         * de solicitud.
         */
        @JvmField var REQUEST_ASSISTANCE = "request_assistance"

        @JvmField var OTHER_CASE = "POTR"

        /**
         * Key para id de asistencia
         */
        @JvmField var ASSISTANCE_ID = "assistance_id"
    }

    // Objetivo para almacenar el tipo de asistencia que se desea cancelar
    private var rejectType:String = PROCESS_ASSISTANCE
    private lateinit var rejectPresenter: RejectPresenter
    var assistanceId:String? = null


    // Objetivo para todos los RadioButtons agregados
    private val optionsRadioButton:ArrayList<RadioButton> = ArrayList()
    // Objetivo para guardar las opciones consultadas
    private val mJustificationRejections: ArrayList<JustificationRejection> = ArrayList()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reject_assistance)

        intent.extras?.let {
            rejectType = it.getString(REJECT_TYPE)
            assistanceId = it.getString(ASSISTANCE_ID)
        }

        // asignamos el tipo de cancelado e el titulo de la actividad
        title = (if (rejectType == PROCESS_ASSISTANCE)  getString(R.string.cancelar_asistencia_titulo) else getString(R.string.rechazar_asistencia_titulo))

        //inicializamos el presentador
        rejectPresenter = RejectPresenter(this,this)
        rejectPresenter.getOptions()

        // Cambiamos el icono de retroceso en el actionBar
        supportActionBar?.setHomeAsUpIndicator(R.drawable.ic_close_white_24dp)
        supportActionBar?.setHomeButtonEnabled(true)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        initializeWidgets()
    }

    private fun initializeWidgets() {
        // Contenido de vista de refresco cuando hay un error de conexion
        refreshMessage.text = getString(R.string.mensaje_error_carga_opciones_cancelar_asistencia)
        refresh.setOnClickListener{
            // solicitamos las opciones
            rejectPresenter.getOptions()
        }
    }

    /**
     * Callback para aceptar el rechazo de asistencia
     */
    fun accept(v:View) {
        if(optionsRadioButton.isEmpty()){
            Snackbar.make(findViewById(android.R.id.content),getString(R.string.mensaje_no_se_encontraron_opciones_de_cancelado),Snackbar.LENGTH_LONG)
                    .setAction(getString(R.string.refrescar),{
                        rejectPresenter.getOptions()
                    }).show()
            return
        }
        // obtenemos la Justificacion con el id de la asistencia que
        // equivale al mismo id del boton asignado
        val justificationRejection = mJustificationRejections[options.checkedRadioButtonId]

        var causeResponse = justificationRejection.descriptionJustification

        // validamos en caso de que se haya seleccionado la opcion 'otros'
        // que el campo este diligenciado.
        if (justificationRejection.typeJustification == OTHER_CASE){
            with(descriptionCause){
                if (this.text.isEmpty()){
                    this.requestFocus()
                    this.error = context.getString(R.string.ingrese_el_motivo_rechazo_asistencia)
                    return
                }else{
                    causeResponse = this.text.toString()
                }
            }
        }

        displayConfirmMessage(object:TwoOptionsDialog.TwoOptionsDialogListener{
            override fun onCancelClicked() {}

            override fun onAcceptClicked() {
                rejectPresenter.cancelAssistance(assistanceId,rejectType,causeResponse)
            }
        })


    }

    /**
     * Funcion encargada de mostrar el dialogo de confirmacion dependiento
     * del tipo de cancelado
     */
    private fun displayConfirmMessage(listener: TwoOptionsDialog.TwoOptionsDialogListener) {
        val rejectWord = if (rejectType == REQUEST_ASSISTANCE) getString(R.string.rechazar) else getString(R.string.cancelar)
        val message = TwoOptionsDialog(this,
                String.format(getString(R.string.regex_titulo_cancelado), rejectWord) ,
                String.format(getString(R.string.regex_contenido_cancelado),rejectWord.toLowerCase()),
                getString(R.string.cancelar),getString(R.string.aceptar),listener)

        message.show()
    }

    override fun displayMessage(message: String?) {
        Snackbar.make(findViewById(android.R.id.content),message?:getString(R.string.error_desconocido),Snackbar.LENGTH_SHORT).show()
    }

    override fun setLoading(display: Boolean) {
        progress.visibility = if (display) View.VISIBLE else View.GONE
    }

    /**
     * Metodo encargado de listar las opciones que el usuario puede
     * seleccionar para cancelar o rechazar la asistencia
     */
    override fun displayOptions(justificationRejections: ArrayList<JustificationRejection>?) {
        optionsRadioButton.clear()
        options.removeAllViews()
        mJustificationRejections.clear()

        if (justificationRejections != null) {
            mJustificationRejections.addAll(justificationRejections)
        }
        // Agregamos las opciones al contrario para que la opcion
        // otro este de ultima.
        mJustificationRejections.reverse()
        mJustificationRejections.forEachIndexed{ index, justificationRejection->
            with(options){
                // se crea la opcion como un RadioButton
                val radioButton = layoutInflater.inflate(resources.getLayout(R.layout.option_reject_assistance), null,false) as RadioButton
                with(radioButton){
                    id = index // asignamos el idice como id
                    text = justificationRejection.descriptionJustification.capitalize()
                }

                radioButton.setOnCheckedChangeListener{ _, isChecked->
                    // validamos si la opcion  seleccionada es otros para mostrar el
                    // campo de descripcion
                    if(isChecked){
                        cause.visibility = if (justificationRejection.typeJustification == OTHER_CASE)
                            View.VISIBLE else View.GONE
                    }

                }
                optionsRadioButton.add(radioButton)
                addView(radioButton)
            }
        }

        // seleccionamos un radiobutton por defecto en este caso el de id 0
        // que equivale al primer radiobutton
        options.check(0).takeIf {  optionsRadioButton.size > 0}

    }


    /**
     * Funcion para convertir el primer caracter en Mayuscula
     * y el restante en minuscula apartir de un String
     */
    private fun String.capitalize():String{
        val a = this.toLowerCase()
        return a.substring(0, 1).toUpperCase() + a.substring(1)
    }

    /**
     * Sobrescribimos el boton de rectroceso para
     * finalizar la actividad actual
     */
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        @Suppress("DEPRECATED_IDENTITY_EQUALS")
        if (item.itemId === android.R.id.home)
        {
            finish()
        }

        return super.onOptionsItemSelected(item)
    }

    /**
     * Metodo encargado de desplegar una vista de refresco dependiendo
     * del parametro @param display, esto con el fin de proporcionarle
     * al usuario la opcion de volver a consultar las opciones si la
     * consulta falla.
     */
    override fun displayRefresh(display: Boolean) {
        refreshContent.visibility = if (display) View.VISIBLE else View.GONE
    }

    override fun sendResult() {
        setResult(Activity.RESULT_OK)
        finish()
    }

}
