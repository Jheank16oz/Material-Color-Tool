package com.americanassist.proveedor;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.americanassist.proveedor.R;
import com.americanassist.proveedor.commons.Controllers.BaseActivity;
import com.americanassist.proveedor.cost.CostFragment;
import com.americanassist.proveedor.cost.CostPresenter;
import com.americanassist.proveedor.cranecost.CraneCostFragment;
import com.americanassist.proveedor.cranecost.CraneCostPresenter;
import com.americanassist.proveedor.diagnostic.DiagnosticFragment;
import com.americanassist.proveedor.diagnostic.DiagnosticPresenter;
import com.americanassist.proveedor.dialogs.ErrorDialog;
import com.americanassist.proveedor.dialogs.TwoOptionsDialog;
import com.americanassist.proveedor.dialogs.WaitingDialog;
import com.americanassist.proveedor.managers.Server.ApiManager;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.maneuver.ManeuverFragment;
import com.americanassist.proveedor.maneuver.ManeuverPresenter;
import com.americanassist.proveedor.map.MapAssistanceFragment;
import com.americanassist.proveedor.map.MapAssistancePresenter;
import com.americanassist.proveedor.model.Assistance;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.model.Question;
import com.americanassist.proveedor.servicehistory.ServiceHistoryActivity;
import com.americanassist.proveedor.services.ActiveRequestService;
import com.americanassist.proveedor.services.SocketEvents;
import com.americanassist.proveedor.solution.SolutionFragment;
import com.americanassist.proveedor.solution.SolutionPresenter;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

import static com.americanassist.proveedor.BaseApplication.getInstance;
import static com.americanassist.proveedor.PendingRequestsActivity.PLAY_NOTIFICATION;
import static com.americanassist.proveedor.PendingRequestsActivity.isPendingCreated;

/**
 * Actividad principal de la app aqui se administra las vistas
 * del estado de la asistencia, comunica a Diagnostico, Costos, Maniobras y
 * Termino; Tambien administra el envio de Notificaciones recibidas
 * de ActiveRequestService y asi notificar a los presentadores
 * correspondientes.
 */
public class DrawerActivity extends BaseActivity implements LateralMenuFragment.LateralMenuFragmentCallback{

    /**
     * Comando al onActivityResult para que actualice el estado del
     * usuario.
     */
    public static final String REFRESH_STATE = "reload";



    public static final int DIAGNOSTIC_FRAGMENT = 1;
    public static final int MAP_FRAGMENT = 2;
    public static final int COSTS_FRAGMENT = 3;
    public static final int CRANE_COSTS_FRAGMENT = 4;
    public static final int MANEUVER_FRAGMENT = 5;
    public static final int SOLUTION_FRAGMENT = 6;
    public static final int REQUEST_ASSISTANCE = 15;

    public static final String FROM_NOTIFICATION_REQUEST = "fromNotificationRequest";
    public DrawerLayout drawerLayout;

    public LateralMenuFragment lateralMenuFragment;
    private Context mContext;

    /** presentadores de cada uno de los fragmentos */
    private MapAssistancePresenter mMapPresenter;
    private DiagnosticPresenter mDiagnosticPresenter;
    private CostPresenter mCostPresenter;
    private CraneCostPresenter mCraneCostPresenter;
    private ManeuverPresenter mManeuverPresenter;
    private SolutionPresenter mSolutionPresenter;

    /** fragments posibles para la vista */
    private MapAssistanceFragment mMapAssistanceFragment;
    private DiagnosticFragment mDiagnosticFragment ;
    private CostFragment mCostFragment;
    private CraneCostFragment mCraneCostFragment;
    private ManeuverFragment mManeuverFragment;
    private SolutionFragment mSolutionFragment;
    private FragmentManager mFragmentManager;
    private String mCurrentFragmentClassName;
    private WaitingDialog mWaitingDialog;

    /** Messenger para la comunicacion del servicio. */
    Messenger mService = null;
    /** Indicador que guarda si hemos llamado bind en el servicio. */
    boolean mIsBound;
    /** TextView par mostrar el ejemplo. */
    TextView mCallbackText;

    private Assistance mAssistance;

    /**
     *  Lista de preguntas dedicada para almacenar las preguntas
     *  de diagnostico que se consulten.
     */
    private ArrayList<Question> diagnosticQuestionsList;
    private Toolbar mToolbar;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        displayEmergencyButton = false;
        drawerLayout = findViewById(R.id.AM_drawer);
        mToolbar = findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);


        mCallbackText = findViewById(R.id.callback);

        doBindService();

        mContext = this;

        if (getIntent() != null && getIntent().hasExtra(FROM_NOTIFICATION_REQUEST)) {
            boolean fromNotificationRequest = getIntent().getBooleanExtra(FROM_NOTIFICATION_REQUEST, false);
            if (fromNotificationRequest) {
                Intent i = new Intent(DrawerActivity.this, PendingRequestsActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivityForResult(i, REQUEST_ASSISTANCE);
            }
        }

        // Menu lateral
        lateralMenuFragment = new LateralMenuFragment();
        lateralMenuFragment.callback = this;

        android.app.FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.add(R.id.AM_framelayout_lateralmenu, lateralMenuFragment);
        transaction.commit();

        mWaitingDialog = new WaitingDialog(mContext, "", true,
                v -> sendAlert(),
                v -> updateAssistanceState());

        mWaitingDialog.setCancelable(false);


        mMapAssistanceFragment = new MapAssistanceFragment();
        mDiagnosticFragment = new DiagnosticFragment();
        mCostFragment = new CostFragment();
        mCraneCostFragment = new CraneCostFragment();
        mManeuverFragment = new ManeuverFragment();
        mSolutionFragment = new SolutionFragment();

        mFragmentManager = getSupportFragmentManager();
        mCurrentFragmentClassName = mMapAssistanceFragment.getClass().getName();
        mFragmentManager.beginTransaction().replace(R.id.content_fragment, mMapAssistanceFragment)
                .commit();

        // creamos los presentadores
        mMapPresenter = new MapAssistancePresenter(mMapAssistanceFragment);
        mDiagnosticPresenter = new DiagnosticPresenter(mDiagnosticFragment);
        mCostPresenter = new CostPresenter(mCostFragment);
        mCraneCostPresenter = new CraneCostPresenter(mCraneCostFragment);
        mManeuverPresenter = new ManeuverPresenter(mManeuverFragment);
        mSolutionPresenter = new SolutionPresenter(mSolutionFragment);

    }

    /**
     * Valida el resultado de una actividad en caso
     * de que se necesite mostrar los costos de Grua
     * @param data resultado de Activity
     */
    private void validateDisplayCraneCost(Intent data) {
        if (data.hasExtra(CraneCostFragment.COSTS)){
            setFragment(CRANE_COSTS_FRAGMENT);
            mCraneCostFragment.setCosts(data.getStringExtra(CraneCostFragment.DISTANCE),
                    data.getStringExtra(CraneCostFragment.COSTS),
                    data.getStringExtra(CraneCostFragment.ASSISTANCE_ID),
                    data.getStringExtra(CraneCostFragment.ASSISTANCE_ROUTE1),
                    data.getStringExtra(CraneCostFragment.ASSISTANCE_ROUTE2));
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_ASSISTANCE) {
                if (data.getBooleanExtra(REFRESH_STATE, false)) {
                    mMapPresenter.refreshStatus();
                } else {

                    validateDisplayCraneCost(data);
                }
            }
        }

    }

    /**
     * Valida las notificaciones generales que afectan a la vista.
     * @param state estado o tipo de notificacion.
     */
    private void validateReceiverState(String state) {

        if (state.equalsIgnoreCase(SocketEvents.NotificationListener.NOTIFICATION_TYPE_EXPIRED_SESSION)) {
            processLogout();
        }else if (state.equalsIgnoreCase(SocketEvents.NotificationListener.NOTIFICATION_TYPE_UPDATE)){
            updateAssistanceState();
        }
    }

    @Override
    public void onViewCreated() {
        if (mAssistance != null) {
            lateralMenuFragment.blockPendingRequestsAndCloseSession();
        } else {
            lateralMenuFragment.unblockPendingRequestsAndCloseSession();
        }
    }

    @Override
    public void onBackPressed() {
        // se valida si se esta en una vista diferente al mapa y costo grua
        // para que al presionar atras retorne al mapa nuevamente
        if (!mCurrentFragmentClassName.equalsIgnoreCase(mMapAssistanceFragment.getClass().getName())
                && !mCurrentFragmentClassName.equalsIgnoreCase(CraneCostFragment.class.getName())) {

            setFragment(MAP_FRAGMENT);
        } else{
            super.onBackPressed();
        }
    }

    /**
     * lo llamamos  cuando se desea realizar el lanzamiento de
     * solicitudes pendientes {@link PendingRequestsActivity}
     * esto para que se envie con un requestCode y obtener
     * el resultado al usuario interactuar con la visata
     * ejemplo: Una aceptacion de asistencia
     */
    @Override
    public void onPendingRequestsClicked() {
        toggleMenu();
        startPendingRequestsActivity();
    }

    public void startPendingRequestsActivity(){
        Intent i = new Intent(DrawerActivity.this, PendingRequestsActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivityForResult(i, REQUEST_ASSISTANCE);
    }

    @Override
    public void onServiceHistoryClicked()
    {
        toggleMenu();
        Intent i = new Intent(DrawerActivity.this, ServiceHistoryActivity.class);
        startActivity(i);
    }

    @Override
    public void onContactClicked() {
        toggleMenu();
        makeCall();
    }

    @Override
    public void onMapClicked(){
        toggleMenu();
        showFragment(mMapAssistanceFragment);
    }

    @Override
    public void onLogoutClicked() {
        toggleMenu();
        new TwoOptionsDialog(mContext,getString(R.string.cerrar_sesion_pregunta) , getString(R.string.contenido_cerrar_sesion), getString(R.string.cancelar), getString(R.string.aceptar), new TwoOptionsDialog.TwoOptionsDialogListener() {
            @Override
            public void onCancelClicked() {
            }

            @Override
            public void onAcceptClicked() {
                processLogout();

            }
        }).show();
    }

    public void processLogout(){
        Provider mProvider = SharedPreferencesManager.getProvider(getBaseContext());
        if (mProvider != null) {
            logout(mProvider);
        }
    }

    /**
     * Se encarga de ejecutar el deslogueo REST y de detener
     * los servicios en proceso.
     * @param mProvider configuraciones obtenidas en login
     */
    private void logout(@NonNull Provider mProvider) {
        showLoadingView();
        new ApiManager(mContext).logout(mProvider.token, mProvider.country, new ApiManagerHelper.ApiLogoutCallback() {
            @Override
            public void onLogoutSuccess() {
                hideLoadingView();
                //Eliminamos el proveedor
                SharedPreferencesManager.removeProvider(getBaseContext());
                if (mAssistance != null) {
                    mAssistance = null;
                }
                //Paramos el servicio de localizacion
                stopService(new Intent(DrawerActivity.this, ActiveRequestService.class));
                //Volvemos a login
                Intent i = new Intent(DrawerActivity.this, LoginActivity.class);
                startActivity(i);
                finish();
            }

            @Override
            public void onLogoutError(String error) {
                hideLoadingView();
                new ErrorDialog(mContext, error).show();
            }
        });
    }

    /**
     * Accion de llamada
     */
    private void makeCall() {
        showLoadingView();
        Provider mProvider = SharedPreferencesManager.getProvider(this);
        if (mProvider == null){
            return;
        }
        new ApiManager(mContext).getTelephone(mProvider.country, new ApiManagerHelper.ApiGetTelephoneCallback() {
            @Override
            public void onGetTelephoneSuccess(final String telephone) {
                hideLoadingView();
                new AlertDialog.Builder(mContext)
                        .setMessage("Llamar al numero " + telephone)
                        .setPositiveButton("Aceptar", (dialogInterface, i) -> askForPermission(Manifest.permission.CALL_PHONE, null, new PermissionListener() {
                            @Override
                            public void onPermissionGranted() {
                                try {
                                    Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + telephone));
                                    startActivity(intent);
                                } catch (SecurityException e) {
                                    e.printStackTrace();
                                    Snackbar.make(((ViewGroup) findViewById(android.R.id.content)).getChildAt(0), "Necesitas dar permiso para poder realizar una llamada", Snackbar.LENGTH_LONG).show();
                                }
                            }

                            @Override
                            public void onPermissionDenied() {
                                Snackbar.make(findViewById(android.R.id.content), R.string.permiso_de_llamada_necesario,Snackbar.LENGTH_LONG).show();
                            }
                        }))
                        .setNegativeButton("Rechazar", (dialogInterface, i) -> dialogInterface.dismiss())
                        .create()
                        .show();
            }

            @Override
            public void onGetTelephoneError(String error) {
                hideLoadingView();
                new ErrorDialog(mContext, error).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_drawer, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                toggleMenu();
                break;
            case R.id.emergency:
                displayEmergencyDialog();
                break;
            case R.id.call:
                makeCall();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        doUnbindService();
    }

    public void toggleMenu() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(Gravity.START);
        } else {
            drawerLayout.openDrawer(Gravity.START);
            //validar si el fragment ha sido agregado isAdded()
            mMapPresenter.toggleMenuPressed();
        }
    }

    public void setTitleBar(String titleBar) {
        mToolbar.setTitle(titleBar);
    }

    public void setFragment(int fragment) {
        switch (fragment){
            case DIAGNOSTIC_FRAGMENT:
                setTitleBar(getString(R.string.diagnostico));
                mDiagnosticFragment.setQuestions(getDiagnosticQuestionsList());
                showFragment(mDiagnosticFragment);
                break;
            case MAP_FRAGMENT:
                setTitleBar(getString(R.string.mapa));
                showFragment(mMapAssistanceFragment);
                break;
            case COSTS_FRAGMENT:
                setTitleBar(getString(R.string.costos));
                showFragment(mCostFragment);
                break;
            case CRANE_COSTS_FRAGMENT:
                setTitleBar(getString(R.string.costos_grua));
                showFragment(mCraneCostFragment);
                break;
            case MANEUVER_FRAGMENT:
                setTitleBar(getString(R.string.maniobras));
                showFragment(mManeuverFragment);
                break;
            case SOLUTION_FRAGMENT:
                setTitleBar(getString(R.string.solucion));
                showFragment(mSolutionFragment);
                break;

        }
    }

    /**
     * Muestra el {@link WaitingDialog} este dialogo es de espera.
     * Puede que no se muestre si el dialogo no ha sido creado
     * o no lleque una descripcion {@param description}.
     */
    public void displayWaiting(@Nullable final String description, final boolean visible){

        if (mWaitingDialog == null)
            return;

        if (description == null && visible)
            return;

        runOnUiThread(() -> {
            if (visible){
                mWaitingDialog.setDescription(description);
                mWaitingDialog.show();

            }else if (mWaitingDialog.isShowing()){
                mWaitingDialog.dismiss();
            }
        });
    }

    public void showFragment(Fragment fragment) {
        mCurrentFragmentClassName = fragment.getClass().getName();
        mFragmentManager.beginTransaction().replace(R.id.content_fragment, fragment, fragment.getClass().getName())
                .commitAllowingStateLoss();
    }

    /**
     * Handler para recibir mensages del servicio {@link ActiveRequestService}.
     */
    @SuppressLint("HandlerLeak")
    class IncomingHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case ActiveRequestService.MSG_SET_VALUE:

                    Bundle mUpdateLocation = (Bundle) msg.obj;
                    mCallbackText.setText(String.format("Received from service:\n %s", mUpdateLocation.getString("locations")));
                    // se envian las actualizaciones de ubicacion al presentador del
                    // mapa, unicamente a este presentador ya que solo este hace uso de
                    // de las actualizaciones de distance,tiempo y ubicacion(LatLng)
                    mMapPresenter.updateLocationState(mUpdateLocation);

                    // Actualizamos las coordenadas de BaseApplication mediante las ubicaciones
                    // que se reciben desde el servicio, Se hace desde esta parte debido a que
                    // el servicio es remoto y maneja un Contexto diferente por lo cual no actualiza
                    // las variables de este contexto.
                    getInstance().setCurrentLocation(new LatLng(mUpdateLocation.getDouble(ActiveRequestService.LOCATION_LATITUDE,0),
                            mUpdateLocation.getDouble(ActiveRequestService.LOCATION_LONGITUDE,0)));

                    break;
                case ActiveRequestService.MSG_SET_NOTIFICATION:
                    Bundle mBundle = (Bundle) msg.obj;
                    String notificationType = mBundle.getString(ActiveRequestService.NEW_NOTIFICATION);
                    String message = mBundle.getString(ActiveRequestService.NOTIFICATION_MESSAGE);

                    if (notificationType == null){
                        return;
                    }
                    // le enviamos a todos los presentadores de
                    // fragments los cambios recibidos de las Notificaciones FCM.
                    mMapPresenter.updateAssistanceState(notificationType, message);
                    mDiagnosticPresenter.updateAssistanceState(notificationType);
                    mCostPresenter.updateAssistanceState(notificationType);
                    mManeuverPresenter.updateAssistanceState(notificationType);
                    mSolutionPresenter.updateAssistanceState(notificationType);
                    mCraneCostPresenter.updateAssistanceState(notificationType);

                    validateReceiverState(notificationType);
                    break;

                case ActiveRequestService.MSG_ADD_ASSISTANCE:
                    Intent i = new Intent(DrawerActivity.this, PendingRequestsActivity.class);
                    i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    i.putExtra(PLAY_NOTIFICATION,true);
                    startActivityForResult(i, REQUEST_ASSISTANCE);
                    break;
                case ActiveRequestService.MSG_CANCEL_ASSISTANCE:
                    // validamos si la actividad esta en primer plano para
                    // enviar una peticion de actualizacion por cancelado
                    if (isPendingCreated) {
                        Intent cancelIntent = new Intent(DrawerActivity.this, PendingRequestsActivity.class);
                        cancelIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                        cancelIntent.putExtra(PLAY_NOTIFICATION, false);
                        startActivity(cancelIntent);
                    }
                    break;

                case ActiveRequestService.MSG_UPDATE_INFO_ASSISTANCE:
                    Bundle mBundleTaD = (Bundle) msg.obj;
                    String time = mBundleTaD.getString(ActiveRequestService.NEW_TIME);
                    String distance = mBundleTaD.getString(ActiveRequestService.NEW_DISTANCE);
                    String direction = mBundleTaD.getString(ActiveRequestService.NEW_DIRECTION);

                    if (time == null || distance == null || direction == null){
                        return;
                    }
                    // le enviamos al presentador del mapa la actualizacion de tiempo y distancia
                    mMapPresenter.updateInfoAssistance(time, distance, direction);
                    break;

                default:
                    super.handleMessage(msg);
            }
        }
    }

    /**
     * Objetivo para que los clientes envien mensajes a IncomingHandler.
     */
    final Messenger mMessenger = new Messenger(new IncomingHandler());

    /**
     * Clase para interactuar con la interfaz principal del servicio..
     */
    private ServiceConnection mConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className,
                                       IBinder service) {
            // Esto es llamado cuando la conexion  con e servicio se
            // es establecida, dando un objeto del servicio que utilizamos para
            // interactuar con el servicio. Nos estamos comunicando con nuestro
            // servicio a traves de una interface IDL
            mService = new Messenger(service);
            mCallbackText.setText(getString(R.string.adjunto));

            // Queremos monitorear el servicio por el tiempo que estemos
            // conectado a el.
            try {
                Message msg = Message.obtain(null,
                        ActiveRequestService.MSG_REGISTER_CLIENT);
                msg.replyTo = mMessenger;
                mService.send(msg);

                Bundle mBundle = new Bundle();
                msg = Message.obtain(null,ActiveRequestService.MSG_SET_VALUE);
                msg.obj = mBundle;
                mService.send(msg);

            } catch (RemoteException e) {
                // En este caso, el servicio se ha bloqueado antes de que pudieramos.
                // en el mpmento no es necesario un posible intento de
                // reconexion
            }

            // como parte de ejemplo mostramos un Toast cuando se conecta.
            //Toast.makeText(DrawerActivity.this, R.string.remote_service_connected,Toast.LENGTH_SHORT).show();
        }

        public void onServiceDisconnected(ComponentName className) {
            // Esto se llama cuando la conexion con el servicio ha sido
            // inesperadamente desconectada, es decir, su proceso se bloqueo.
            mService = null;
            mCallbackText.setText(getString(R.string.desconectado));
            Log.e("service disconnected",className.toString());
            // como parte de ejemplo mostramos un Toast cuando se desconecta.
            Toast.makeText(DrawerActivity.this, R.string.remote_service_disconnected, Toast.LENGTH_SHORT).show();
        }
    };


    /**
     * Inicializa el servicio
     */
    void doBindService() {
        // Estableccemos una conexion con el servicio.
        bindService(new Intent(DrawerActivity.this,
                ActiveRequestService.class), mConnection, Context.BIND_AUTO_CREATE);
        mIsBound = true;
        mCallbackText.setText(getString(R.string.union));
    }

    void doUnbindService() {
        if (mIsBound) {
            // si recibimos el servicio,y este esta registrado,
            // es el momendo de anular el registro
            if (mService != null) {
                try {
                    Message msg = Message.obtain(null,
                            ActiveRequestService.MSG_UNREGISTER_CLIENT);
                    msg.replyTo = mMessenger;
                    mService.send(msg);
                } catch (RemoteException e) {
                    // No hay nada en especial que hacer si el
                    // servicio arroja una excepcion
                }
            }

            // desplegar nuestra conexion.
            unbindService(mConnection);
            mIsBound = false;
            mCallbackText.setText(getString(R.string.desvinculacion));
        }
    }

    public Assistance getAssistance() {
        return mAssistance;
    }

    public void setAssistance(Assistance assistance) {
        mAssistance = assistance;
        // le informamos al servicio que  la asistencia
        // ha sido cambiada con el fin de que no envie informacion erronea.
        requestUpdateLocationsService();
    }


    public void updateAssistanceState(){
        Provider mProvider = SharedPreferencesManager.getProvider(this);

        if (mProvider != null) {
            showLoadingView();
            new ApiManager(this).getProviderState(mProvider.idProvider, mProvider.idContact, mProvider.country, new ApiManagerHelper.ApiGetProviderStateCallback() {
                @Override
                public void onGetProviderStateSuccess(Assistance assistance) {
                    mAssistance = assistance;
                    mMapPresenter.updateAssistanceState(assistance);
                    hideLoadingView();
                    requestUpdateLocationsService();

                }

                @Override
                public void onGetProviderStateError(String error, boolean isDesconected) {


                    //En caso de que llegue el estado del proveedor desconectado se enviara al login
                    if (isDesconected){
                        Toast.makeText(DrawerActivity.this, error, Toast.LENGTH_SHORT).show();
                        processLogout();
                    }

                    hideLoadingView();
                }
            });
        }
    }

    /**
     * Solicitamos al servicio una actualizacion de ubicacion {@link ActiveRequestService},
     */
    private void requestUpdateLocationsService() {
        Message msg = Message.obtain(null,
                ActiveRequestService.MSG_UPDATE_LOCATION);

        msg.obj = null;
        try {
            mService.send(msg);
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {
            Log.e("Serivicio remoto", "desconectado.");
        }
    }

    /**
     * Enviamos la cancelacion de asisencia
     * al servicio para que envie una ultima actualizacion
     * de ubicacion al servidor, esto es necesario
     * ya que si no se envia, no recibiremos
     * notificaciones de asistencias nuevas por parte
     * del servidor.
     */
    public void cancelAssistance() {
        Message msg = Message.obtain(null, ActiveRequestService.MSG_NEED_CLEAN_ASSISTANCE);
        msg.obj = null;
        try {
            mService.send(msg);
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {
            Log.e("Serivicio remoto", "desconectado.");
        }
    }

    public ArrayList<Question> getDiagnosticQuestionsList() {
        return diagnosticQuestionsList;
    }

    public void setDiagnosticQuestionsList(ArrayList<Question> diagnosticQuestionsList) {
        this.diagnosticQuestionsList = diagnosticQuestionsList;
    }


}
