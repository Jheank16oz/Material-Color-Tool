package com.americanassist.proveedor.connection;

import android.content.Context;
import android.widget.Toast;

import com.americanassist.proveedor.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * CallBackCustom .
 *
 * <p> En esta clase se personaliza un callback para manejar
 * todos los casos de error.
 * </p>
 *
 */
public class CallBackCustom<T> implements Callback<T> {

    private Context mContext;

    protected CallBackCustom(Context context) {
        mContext = context;
    }

    /**
     * Formato de datos para la respuesta. [default: json]
     * @param call instancia tipo de cuerpo de respuesta
     * @param response cuerpo de la respuestaenviada desde el webservice
     */
    @Override
    public void onResponse(Call<T> call, Response<T> response) {

        /*
            Siempre que en otro lugar del proyecto se sobreesbriba este metodo
            y se llame al super, entonces entrara a validarse esta condicional
            en la cual se certifica que la respuesta esta incorrecta, de ser asi,
            solo se ejecutara esta condicional y lo que halla en el resto del
            metodo sobreescrito no se ejecutara
         */
        if(!response.isSuccessful()){
            try {
                JSONObject errorBody = new JSONObject(response.errorBody().string());
                String message = errorBody.has("mensaje")?errorBody.getString("mensaje"):mContext.getString(R.string.error_desconocido);
                Toast.makeText(mContext, message, Toast.LENGTH_SHORT).show();
            }catch (JSONException e){
                e.printStackTrace();
                Toast.makeText(mContext, mContext.getString(R.string.error_desconocido), Toast.LENGTH_SHORT).show();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onFailure(Call<T> call, Throwable t) {
        t.printStackTrace();
        Toast.makeText(mContext, t.getMessage(), Toast.LENGTH_SHORT).show();
    }
}
