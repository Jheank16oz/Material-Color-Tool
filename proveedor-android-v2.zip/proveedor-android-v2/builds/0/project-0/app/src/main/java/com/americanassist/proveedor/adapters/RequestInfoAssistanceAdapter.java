package com.americanassist.proveedor.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.americanassist.proveedor.R;
import com.americanassist.proveedor.model.RequestInformationAssistanceItem;

import org.apache.commons.lang3.text.WordUtils;

import java.util.List;

/**
 *
 * Adaptador para la lsita de indormacion de un item de asistencias
 * pendientes
 */
public class RequestInfoAssistanceAdapter  extends RecyclerView.Adapter<RequestInfoAssistanceViewHolder> {

    private List<RequestInformationAssistanceItem> itemList;

    RequestInfoAssistanceAdapter(List<RequestInformationAssistanceItem> itemList) {
        this.itemList = itemList;
    }

    @Override
    public RequestInfoAssistanceViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.request_information_item, null);
        RequestInfoAssistanceViewHolder rcv = new RequestInfoAssistanceViewHolder(layoutView);
        return rcv;
    }

    @Override
    public void onBindViewHolder(RequestInfoAssistanceViewHolder holder, int position) {
        String tittleText = itemList.get(position).tittle;
        String contentText = itemList.get(position).content;

        holder.tittle.setText(tittleText!=null?WordUtils.capitalize(tittleText.toLowerCase()):"");
        holder.content.setText(contentText!=null?WordUtils.capitalize(contentText.toLowerCase()):"");
    }

    @Override
    public int getItemCount() {
        return this.itemList.size();
    }
}