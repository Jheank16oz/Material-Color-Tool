package com.americanassist.proveedor.managers.Server;

import com.americanassist.proveedor.model.AditionalInfo;
import com.americanassist.proveedor.model.Assistance;
import com.americanassist.proveedor.model.Cost;
import com.americanassist.proveedor.model.Country;
import com.americanassist.proveedor.model.Detail;
import com.americanassist.proveedor.model.JustificationRejection;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.model.Question;
import com.americanassist.proveedor.model.RequestAssistance;
import com.americanassist.proveedor.model.Service;
import com.americanassist.proveedor.model.Session;

import java.util.ArrayList;
import java.util.List;

public class ApiManagerHelper {

    public interface ApiGetAvailableServicesCallback
    {
        void onGetAvailableServicesSuccess(ArrayList<Service> services);
        void onGetAvailableServicesError(String error);
    }

    public interface PostTaskCallback {
        void onSuccess(String result);
        void onError(String result);
    }

    public interface GetTaskCallback {
        void onSuccess(String result);
        void onError(String result);
    }

    public interface SessionCallback{
        void duplicatedSession(Session session);
        void login(Provider provider);
        void onFailure();
    }

    public interface ExpiredSessionCallback{
        void onSuccessExpiredSession(Provider Provider);
    }

    public interface CountriesCallback{
        void onSuccess(List<Country> countries);
        void onFailure();
    }

    public interface ProviderRegisterCallback {
        void onSuccess(String message);

        void onFailure();
    }
        
    public interface PanicAlertCallback{
        void onSuccessPanicAlert(Detail detail);
    }

    public interface ApiLogoutCallback {
        void onLogoutSuccess();
        void onLogoutError(String error);
    }

    public interface ApiGetTelephoneCallback {
        void onGetTelephoneSuccess(String telephone);
        void onGetTelephoneError(String error);
    }

    public interface ApiGetAvailableAssistancesCallback {
        void onGetAvailableAssistancesSuccess(ArrayList<RequestAssistance> assistances, int pagination);
        void onGetAvailableAssistancesError(String error);
        void onGetAvailableAssistancesFull();
    }

    public interface ApiAcceptAssistanceCallback {
        void onAcceptAssistanceSuccess(boolean showCosts, String costs, String route1, String route2, String distance);
        void onAcceptAssistanceError(String error);
    }

    public interface ApiRejectAssistanceCallback {
        void onRejectAssistanceSuccess();
        void onRejectAssistanceError(String error);
    }

    public interface ApiReprogramAssistanceCallback {
        void onReprogramAssistanceSuccess();
        void onReprogramAssistanceError(String error);
    }

    public interface ApiCancelAssistanceCallback {
        void onCancelAssistanceSuccess();
        void onCancelAssistanceError(String error);
    }

    public interface ApiGetProviderStateCallback {
        void onGetProviderStateSuccess(Assistance assistance);
        void onGetProviderStateError(String error, boolean isDesconected);
    }

    public interface ApiConfirmArriboCallback {
        void onConfirmArriboSuccess();
        void onConfirmArriboError(String error);
    }

    public interface ApiGetQuestionsCallback {
        void onGetQuestionsSuccess(int showCosts, int showManeuvers, ArrayList<Question> questions);
        void onGetQuestionsError(String error);
    }

    public interface ApiGetQuestionSolutionsCallback {
        void onGetQuestionsSuccess(ArrayList<Question> questions);
        void onGetQuestionsError(String error);
    }

    public interface ApiSendLocationCallback {
        void onSendLocationSuccess(boolean showArribo, boolean diagnostico, boolean termino_servicio, boolean hasAssistance, String coordinatesState );
        void onSendLocationError(String error);
    }

    public interface ApiSendAnswersCallback {
        void onSendAnswersSuccess(int showManeuvers);
        void onSendAnswersError(String error);
    }

    public interface ApiSendAnswersSolutionCallback {
        void onSendAnswersSuccess(String message);
        void onSendAnswersError(String error);
    }

    public interface ApiGetAditionalInfoCallback {
        void onGetAditionalInfoSuccess(ArrayList<AditionalInfo> aditionalInfos);
        void onGetAditionalInfoError(String error);
    }

    public interface ApiGetListCostsCallback {
        void onGetListCostsSuccess(ArrayList<Cost> costs);
        void onGetListCostsError(String error);
    }

    public interface ApiSendCostCallback {
        void onSendCostsSuccess(int block);
        void onSendCostsError(String error);
    }

    public interface ApiConfirmManeuversCallback {
        void onConfirmManeuversSuccess(ArrayList<Cost> costs);
        void onConfirmManeuversError(String error);
    }

    public interface ApiSendManeuversCallback {
        void onSendManeuversSuccess(int block);
        void onSendManeuversError(String error);
    }

    /**
     * Para ver justificaciones del rechazo de un servicio
     */
    public interface ApiGetJustificationRejectionServiceCallback
    {
        void onGetGetJustificationRejectionServiceSuccess(ArrayList<JustificationRejection> justificationRejections);
        void onGetGetJustificationRejectionServiceError(String error);
    }


    public interface GetConfigurationCallback{
        void onSuccessConfigurationLoaded();
        void onFailureConfigurationLoaded();
    }
}
