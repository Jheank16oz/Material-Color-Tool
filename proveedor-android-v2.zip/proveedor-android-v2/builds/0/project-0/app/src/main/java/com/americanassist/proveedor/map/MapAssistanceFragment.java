package com.americanassist.proveedor.map;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.view.menu.MenuPopupHelper;
import android.support.v7.widget.CardView;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.SwitchCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.americanassist.proveedor.DrawerActivity;
import com.americanassist.proveedor.MoreInfoActivity;
import com.americanassist.proveedor.R;
import com.americanassist.proveedor.commons.Controllers.BaseActivity;
import com.americanassist.proveedor.dialogs.ErrorDialog;
import com.americanassist.proveedor.dialogs.ReprogramAssistanceDialog;
import com.americanassist.proveedor.dialogs.TwoOptionsDialog;
import com.americanassist.proveedor.managers.Server.ApiManager;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.Assistance;
import com.americanassist.proveedor.model.Cost;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.model.Question;
import com.americanassist.proveedor.rejectassistance.RejectAssistanceActivity;
import com.americanassist.proveedor.services.ActiveRequestService;
import com.americanassist.proveedor.utils.Utils;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.JointType;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.maps.model.RoundCap;
import com.google.android.gms.tasks.Task;

import org.gavaghan.geodesy.Ellipsoid;
import org.gavaghan.geodesy.GeodeticCalculator;
import org.gavaghan.geodesy.GlobalCoordinates;

import java.util.ArrayList;
import java.util.List;

import static android.app.Activity.RESULT_OK;
import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_ACCEPT_COSTS;
import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_ACCEPT_COSTS_TOWING;
import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_ACCEPT_MANEUVER;
import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_TYPE_ASSIG_PROV_SOAANG;
import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_TYPE_CANCEL;
import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_TYPE_PREPARE_ACEPT;
import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_TYPE_PREPARE_COST;
import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_TYPE_PREPARE_DIAGNOSTIC;
import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_TYPE_PREPARE_LAST_SOLUTION;
import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_TYPE_PREPARE_MANEUVER;
import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_TYPE_PREPARE_TERMINATE;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Vista principal de asistencia en proces, comunica las acciones de la
 * asistencia como ejemplo: ir a maniobras,Costos  y termino.
 *
 * Posee las posibles acciones sobre una asistencia asignada a un usuario.
 */
public class MapAssistanceFragment extends Fragment implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, MapAssistanceContract.View, PopupMenu.OnMenuItemClickListener, NavigationView.OnNavigationItemSelectedListener {

    /**
     * Request code para el cancelado de asistencia.
     */
    private static final int CANCEL_ASSISTANCE = 6;

    private GoogleMap mMap;
    public SupportMapFragment mMapFragment;
    private TextView mDistanceTextView;
    private TextView mDurationTextView;
    private TextView mDirectionTextView;
    private TextView mArrivalConfirm;
    private TextView mStateTextView;



    private CardView mTopBar;
    private ViewGroup mBottomBar;

    /* Objetos que influyen en las actualizaciones del mapa */
    public GoogleApiClient mGoogleApiClient;
    private Marker mDestinationMarker;
    // ultimas actualizaciones de ubicacion recibidas
    private LatLng mLastLocation;
    private float mBearing;


    private MapAssistanceContract.Presenter mPresenter;

    /**
     * Comando a la vista del Mapa, para indicar que se esta esperando
     * que el cliente confirme que el  proveedor ha llegado.
     */
    public static final String STATE_WAITING_DIAGNOSTIC = "espera_diagnostico";

    /**
     * Comando a la vista del Mapa, para indicar que se esta esperando
     * que el cliente acepte los costos.
     */
    public static final String STATE_ACEPTED_COSTS = "aceptacion_costos";

    /**
     * Comando a la vista del mapa, para indicar que se esta, en estado de
     * diagnostico.
     */
    public static final String STATE_DIAGNOSTIC = "diagnostico";

    /**
     * Comando a la vista del mapa, para indicar que se esta, en estado de
     * ir a costos.
     */
    public static final String STATE_COSTS = "items_costos";

    /**
     * Comando a la vista del mapa, para indicar que se esta, en estado de
     * ir a la solucion.
     */
    public static final String STATE_SOLUTION = "termino_servicio";

    /**
     * Comando a la vista del mapa, para indicar que se esta, en estado de
     * ir a maniobras.
     */
    public static final String STATE_MANEUVERS = "maniobras";

    /**
     * Comando a la vista del mapa, para indicar que se acepto que habian maniobras
     * pero aun no se han indicado.
     */
    public static final String STATE_SHOW_MANEUVERS = "lista_items_maniobras";

    /**
     * Comando a la vista del mapa, para indicar que se esta esperando
     * que el proveedor llegue al punto de termino.
     * En este caso se habilita para las asistencias de tipo
     * GRUA, debido a que hay un segundo paradero, por ende se cambia
     * a este estado cuando ya se llego al punto de recogida y se llenaron
     * las etapas de maniobras y diagnostico.
     */
    public static final String STATE_WAITING_SOLUTION = "antes_termino_servicio";


    /**
     * Comando para la vista del mapa, para indicar que el usuario
     * tiene una asistencia en proceso.
     */
    public static final String STATE_WITH_ASSISTANCE = "ocupado";


    private FusedLocationProviderClient mFusedLocationProviderClient;
    private Location mDeviceLocation;
    private FloatingActionButton mFab;
    private BottomSheetBehavior<View> bottomDrawerBehavior;
    private ImageView mOptionsMap;
    private View mLocationButton;


    private boolean isGestureEnabled;
    private boolean isRouteEnabled;
    private boolean isDriverModeEnabled;


    //start options map
    private SwitchCompat mTrafficSwitch;
    private SwitchCompat mDriverModeSwitch;
    NavigationView mNavigationView;
    private View mCloseNavigation;
    //end options map



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.map_assistance_fragment, container, false);
        initializeComponents(view);
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mPresenter != null) {
            mPresenter.start();
        }
    }

    /**
     * Se encarga de inicializar los componentes
     * y separa su inicializacion de la declaracion
     * @param view para initializar los componentes
     */
    private void initializeComponents(View view) {

        // Mapa
        mMapFragment = SupportMapFragment.newInstance();
        assert getActivity() != null;
        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.map, mMapFragment, "map");
        fragmentTransaction.commit();


        mDistanceTextView = view.findViewById(R.id.AM_textview_distance);
        mDirectionTextView = view.findViewById(R.id.direction);
        mDurationTextView = view.findViewById(R.id.AM_textview_time);
        mArrivalConfirm = view.findViewById(R.id.AM_textview_confirmarribo);
        mStateTextView = view.findViewById(R.id.AM_textview_gotodiagnostic);
        mLocationButton = view.findViewById(R.id.center);
        mOptionsMap = view.findViewById(R.id.optionsMap);
        mTopBar = view.findViewById(R.id.topBar);
        mBottomBar = view.findViewById(R.id.bottomBar);
        mFab = view.findViewById(R.id.fab);
        mFab.setOnClickListener(this::showMenu);
        // Construct a FusedLocationProviderClient.
        mFusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(getActivity());


        initializeGoogleApiClient();


        mNavigationView= view.findViewById(R.id.navigation_view);
        mNavigationView.setNavigationItemSelectedListener(this);

        mTrafficSwitch = (SwitchCompat) mNavigationView.getMenu().findItem(R.id.traffic).getActionView();
        mDriverModeSwitch = (SwitchCompat) mNavigationView.getMenu().findItem(R.id.driver).getActionView();
        mCloseNavigation = mNavigationView.getMenu().findItem(R.id.close).getActionView();

        setUpBottomDrawer(view);

        initListeners();
    }


    protected void setUpBottomDrawer(View view) {
        View bottomDrawer = view.findViewById(R.id.bottom_drawer);
        bottomDrawerBehavior = BottomSheetBehavior.from(bottomDrawer);
        bottomDrawerBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);


        mOptionsMap.setOnClickListener(view1 ->
                bottomDrawerBehavior.setState(BottomSheetBehavior.STATE_HALF_EXPANDED));

        mCloseNavigation.setOnClickListener(view1 ->
                bottomDrawerBehavior.setState(BottomSheetBehavior.STATE_HIDDEN));
    }


    /**
     * Se encarga de inicializar Google api client
     * y agregar las configuraciones necesarias
     */
    private void initializeGoogleApiClient() {
        if (mGoogleApiClient == null) {
            assert getContext() != null;
            mGoogleApiClient = new GoogleApiClient.Builder(getContext())
                    .addApi(LocationServices.API)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .build();
        }
        mGoogleApiClient.connect();
    }


    @Override
    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;
        isGestureEnabled = false;
        if (mMap != null) {
            mMap.setMinZoomPreference(6.0f);
            mMap.setMaxZoomPreference(20.0f);
            mMap.getUiSettings().setCompassEnabled(false);
            mMap.getUiSettings().setZoomControlsEnabled(false);
            mMap.getUiSettings().setMyLocationButtonEnabled(false);

            mMap.setOnCameraMoveStartedListener(i -> {
                // El usuario ha hecho una gesto en el mapa
                // Por ejemplo: pan, tilt, pellizcar para ampliar o girar.
                if (i == GoogleMap.OnCameraMoveStartedListener.REASON_GESTURE) {
                    isGestureEnabled = true;
                }
            });
        }

        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            assert getContext() != null;
            if (ContextCompat.checkSelfPermission(getContext(),
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {
                mMap.setMyLocationEnabled(true);
            }
        } else {
            if (mMap != null) {
                mMap.setMyLocationEnabled(true);
            }
        }

        assert getActivity() != null;
        Assistance mAssistance = ((DrawerActivity) getActivity()).getAssistance();

        displayPolylines(mAssistance);
        ((DrawerActivity) getActivity()).updateAssistanceState();
    }

    /**
     * Obtiene la informacion de ubicacion y envia una actualizacion de
     * vista del mapa y camara.
     */
    private void getDeviceLocation() {
        try {
            if (getActivity()==null){
                return;
            }
            Task<Location> locationResult = mFusedLocationProviderClient.getLastLocation();
            locationResult.addOnCompleteListener(getActivity(), task -> {
                if (task.isSuccessful()) {
                    // Set the map's camera position to the current location of the device.
                    mDeviceLocation = task.getResult();
                    updateCamera();
                }else{
                    Log.d("error", "Current location is null. Using defaults.");
                    Log.e("error", "Exception: %s", task.getException());
                }
            });

        } catch(SecurityException e)  {
            Log.e("Exception: %s", e.getMessage());
        }
    }


    @Override
    public void onDestroy() {
        mGoogleApiClient.disconnect();
        super.onDestroy();
    }


    private void initListeners() {

        mLocationButton.setOnClickListener(v -> {
            isRouteEnabled = false;
            isGestureEnabled = false;
            getDeviceLocation();
            bottomDrawerBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
        });

        mTrafficSwitch.setOnCheckedChangeListener((compoundButton, b) -> {
            if (mMap!=null){
                    mMap.setTrafficEnabled(b);
            }
        });

        mDriverModeSwitch.setOnCheckedChangeListener((compoundButton, b) -> {
            isRouteEnabled = false;
            isGestureEnabled = false;
            isDriverModeEnabled = b;
            getDeviceLocation();
            bottomDrawerBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
        });



        mStateTextView.setOnClickListener(v -> {
            assert getActivity() != null;
            ((BaseActivity) getActivity()).showLoadingView();
            final Provider provider = SharedPreferencesManager.getProvider(getContext());
            if (provider == null) {
                return;
            }
            // Una vez hecho el login comprobamos el estado del proveedor (asistencia pendiente...)
            new ApiManager(getContext()).getProviderState(provider.idProvider, provider.idContact, provider.country, new ApiManagerHelper.ApiGetProviderStateCallback() {
                @Override
                public void onGetProviderStateSuccess(Assistance assistance) {
                    ((BaseActivity) getActivity()).hideLoadingView();
                    ((DrawerActivity) getActivity()).setAssistance(assistance);

                    if (assistance != null) {
                        //Dependiendo del estado, vamos a una u otra pantalla
                        switch (assistance.estado) {
                            case STATE_DIAGNOSTIC:
                                ((BaseActivity) getActivity()).showLoadingView();
                                Provider mProvider = SharedPreferencesManager.getProvider(getContext());
                                if (mProvider == null) {
                                    break;
                                }
                                Assistance mAssistance = ((DrawerActivity) getActivity()).getAssistance();
                                if (mAssistance == null) {
                                    Toast.makeText(getContext(), R.string.intentalo_mas_tarde, Toast.LENGTH_SHORT).show();
                                    return;
                                }
                                new ApiManager(getContext()).getQuestions(mAssistance.id, mProvider.country, new ApiManagerHelper.ApiGetQuestionsCallback() {
                                    @Override
                                    public void onGetQuestionsSuccess(int showCosts, int showManeuvers, ArrayList<Question> questions) {
                                        ((BaseActivity) getActivity()).hideLoadingView();
                                        // Si el server nos ha indicado que mostremos directamente los costos
                                        if (showCosts == 1) {
                                            ((DrawerActivity) getActivity()).setFragment(DrawerActivity.COSTS_FRAGMENT);
                                        }
                                        // Si es ir a maniobras vamos directamente a ellas
                                        else if (showManeuvers == 1) {
                                            ((DrawerActivity) getActivity()).setFragment(DrawerActivity.MANEUVER_FRAGMENT);
                                        }
                                        // Si no, mostramos la pantalla de diagnostico primero
                                        else {
                                            ((DrawerActivity) getActivity()).setDiagnosticQuestionsList(questions);
                                            ((DrawerActivity) getActivity()).setFragment(DrawerActivity.DIAGNOSTIC_FRAGMENT);
                                        }
                                    }

                                    @Override
                                    public void onGetQuestionsError(String error) {
                                        ((BaseActivity) getActivity()).hideLoadingView();
                                    }
                                });

                                break;
                            // Boton costos (asistencias normales)
                            case STATE_COSTS:
                                ((DrawerActivity) getActivity()).setFragment(DrawerActivity.COSTS_FRAGMENT);

                                break;
                            // Boton solucion termino
                            case STATE_SOLUTION:
                                ((DrawerActivity) getActivity()).setFragment(DrawerActivity.SOLUTION_FRAGMENT);

                                break;
                            // Boton maniobras
                            case STATE_MANEUVERS:
                                TwoOptionsDialog twoOptionsDialog = new TwoOptionsDialog(getContext(), getString(R.string.se_requieren_maniobras_titulo), getString(R.string.se_requieren_maniobras_contenido), getString(R.string.no), getString(R.string.si), new TwoOptionsDialog.TwoOptionsDialogListener() {
                                    @Override
                                    public void onAcceptClicked() {
                                        ((BaseActivity) getActivity()).showLoadingView();
                                        Assistance mAssistance = ((DrawerActivity) getActivity()).getAssistance();
                                        if (mAssistance == null) {
                                            Toast.makeText(getContext(), R.string.intentalo_mas_tarde, Toast.LENGTH_SHORT).show();
                                            return;
                                        }
                                        new ApiManager(getContext()).confirmAndGetManeuvers(provider.country, mAssistance.id, provider.idProvider, provider.idContact, 1, new ApiManagerHelper.ApiConfirmManeuversCallback() {
                                            @Override
                                            public void onConfirmManeuversSuccess(ArrayList<Cost> costs) {
                                                ((BaseActivity) getActivity()).hideLoadingView();
                                                // Hemos dicho que si requiere maniobras: vamos a pantalla de maniobras
                                                ((DrawerActivity) getActivity()).setFragment(DrawerActivity.MANEUVER_FRAGMENT);

                                            }

                                            @Override
                                            public void onConfirmManeuversError(String error) {
                                                ((BaseActivity) getActivity()).hideLoadingView();
                                                new ErrorDialog(getContext(), error).show();
                                            }
                                        });
                                    }

                                    @Override
                                    public void onCancelClicked() {
                                        ((BaseActivity) getActivity()).showLoadingView();
                                        Assistance mAssistance = ((DrawerActivity) getActivity()).getAssistance();
                                        if (mAssistance == null) {
                                            Toast.makeText(getContext(), R.string.intentalo_mas_tarde, Toast.LENGTH_SHORT).show();
                                            return;
                                        }
                                        new ApiManager(getContext()).confirmAndGetManeuvers(provider.country, mAssistance.id, provider.idProvider, provider.idContact, 0, new ApiManagerHelper.ApiConfirmManeuversCallback() {
                                            @Override
                                            public void onConfirmManeuversSuccess(ArrayList<Cost> costs) {
                                                ((BaseActivity) getActivity()).hideLoadingView();
                                                // Hemos dicho que no requiere maniobras: mapa libre
                                                mArrivalConfirm.setVisibility(View.GONE);
                                                mStateTextView.setVisibility(View.GONE);
                                                setBarActionsVisible(true);
                                            }

                                            @Override
                                            public void onConfirmManeuversError(String error) {
                                                ((BaseActivity) getActivity()).hideLoadingView();
                                                new ErrorDialog(getContext(), error).show();
                                            }
                                        });
                                    }
                                });
                                twoOptionsDialog.show();
                                break;
                        }
                    }
                }

                @Override
                public void onGetProviderStateError(String error, boolean isDesconected) {
                    // En caso de que el usuario tenga el estado de desconectado, se debe enviar al login

                    if (isDesconected) {
                        Toast.makeText(getActivity(), error, Toast.LENGTH_SHORT).show();
                        if (getActivity() != null) {
                            ((DrawerActivity) getActivity()).processLogout();
                        }
                    }

                    if (getActivity() != null) {
                        ((BaseActivity) getActivity()).hideLoadingView();
                    }
                }
            });
        });



        mArrivalConfirm.setOnClickListener(v -> {
            assert getActivity() != null;
            ((BaseActivity) getActivity()).showLoadingView();

            Provider mProvider = SharedPreferencesManager.getProvider(getContext());
            if (mProvider == null) {
                return;
            }
            Assistance mAssistance = ((DrawerActivity) getActivity()).getAssistance();
            if (mAssistance == null) {
                Toast.makeText(getContext(), R.string.intentalo_mas_tarde, Toast.LENGTH_SHORT).show();
                return;
            }
            new ApiManager(getContext()).confirmArribo(mAssistance.id, mProvider.idProvider, mProvider.idContact, mProvider.country, new ApiManagerHelper.ApiConfirmArriboCallback() {
                @Override
                public void onConfirmArriboSuccess() {
                    ((BaseActivity) getActivity()).hideLoadingView();
                    // Quedamos a la espera de que el cliente confirme que el proveedor ha llegado
                    ((DrawerActivity) getActivity()).displayWaiting(getString(R.string.esperando_confirmacion_del_cliente), true);

                }

                @Override
                public void onConfirmArriboError(String error) {
                    ((BaseActivity) getActivity()).hideLoadingView();
                    new ErrorDialog(getContext(), error).show();
                    ((DrawerActivity) getActivity()).updateAssistanceState();
                    refreshScreen();
                }
            });
        });


    }


    /**
     * Gestiona el modo de vista de la camara del Mapa
     * entre ellos: Modo Conductor y rutas.
     */
    private void updateCamera() {
        if (!isAdded()){
            return;
        }
        if (mDeviceLocation!=null){
            mLastLocation = new LatLng(mDeviceLocation.getLatitude(),mDeviceLocation.getLongitude());
            mBearing = mDeviceLocation.getBearing();
        }
        if (mLastLocation == null || mMap == null || isGestureEnabled) {
            return;
        }



        assert getActivity()!=null;
        Assistance mAssistance = ((DrawerActivity)getActivity()).getAssistance();
        boolean haveAssistance = mAssistance!=null && !mAssistance.estado.equalsIgnoreCase(STATE_ACEPTED_COSTS);



        if (isRouteEnabled && haveAssistance){
            isGestureEnabled = true;
            //move map camera
            LatLngBounds.Builder builder = new LatLngBounds.Builder();

            if (mAssistance.endLocation!=null){
                builder.include(mAssistance.endLocation);

            }
            List<LatLng> poly1 = mAssistance.getPolylineRoute1();
            List<LatLng> poly2 = mAssistance.getPolylineRoute2();

            if (poly1!=null){
                for (LatLng l:poly1) {
                    builder.include(l);
                }
            }

            if (poly2!=null){
                for (LatLng l:poly2) {
                    builder.include(l);
                }
            }
            // Agregamos la ubicacion del taller si es de tipo grua
            if (mAssistance.isCraneAssistance()){
                builder.include(mAssistance.workshopLatLng);// validar Worshop Latlng Nan>Nan
            }
            if (mLastLocation!=null) {
                builder.include(new LatLng(mLastLocation.latitude, mLastLocation.longitude));
            }

            try {
                LatLngBounds bounds = builder.build();

                int width = getResources().getDisplayMetrics().widthPixels;
                int height = getResources().getDisplayMetrics().heightPixels;
                int padding = (int) (height * 0.16);

                // se mueve la camara del mapa a un radio en el que las ubicaciones
                // de punto final, actual y/o Grua se muestren.
                mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, width, height, padding));
            }catch (IllegalArgumentException e){
                e.printStackTrace();
            }

        }else if (isDriverModeEnabled) {
            // la aguja hacia el norte eta desactivada por o cual se debe
            // apuntar al punto de Bearing
            isGestureEnabled = false;

            GlobalCoordinates start = new GlobalCoordinates(mLastLocation.latitude, mLastLocation.longitude);
            GeodeticCalculator geoCalc = new GeodeticCalculator();
            GlobalCoordinates target = geoCalc.calculateEndingGlobalCoordinates(
                    Ellipsoid.WGS84, start, mBearing, 30f);
            LatLng mapTarget = new LatLng(target.getLatitude(), target.getLongitude());

            CameraPosition cap = new CameraPosition(mapTarget,
                    20, 80, mBearing);


            mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cap));
        }else{
            isGestureEnabled = false;
            // la aguja hacia el norte esta activada por lo cual apuntamos
            // la camara hacia el norte
            CameraPosition cap = new CameraPosition(mLastLocation,
                    17, 0, 0);

            mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cap));
        }



    }

    /**
     * Envia a google Maps la solicitud de desplegar una ruta dada
     */
    private void goToNavigation() {
        if(!isAdded()){
            return;
        }
        assert getActivity()!=null;
        Assistance mAssistance = ((DrawerActivity)getActivity()).getAssistance();
        if (mAssistance != null) {
            LatLng destinationLatLng = mAssistance.endLocation;
            Uri gmmIntentUri = Uri.parse("google.navigation:q=" + destinationLatLng.latitude + "," + destinationLatLng.longitude);
            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
            mapIntent.setPackage("com.google.android.apps.maps");
            startActivity(mapIntent);
        }
    }

    /**
     * Refresca las rutas, marcadores y opciones del
     * mapa.
     *
     * DEspliega el estado de la asistencia apartir de la informacion consultada.
     */
    private void refreshScreen() {
        if(!isAdded()){
            return;
        }
        assert getActivity()!=null;
        Assistance assistance = ((DrawerActivity)getActivity()).getAssistance();
        if (assistance != null) {

            ((DrawerActivity)getActivity()).setTitleBar(getString(R.string.en_ruta));

            setBarActionsVisible(true);
            mFab.setVisibility(View.VISIBLE);
            updateInfoAssistance(assistance.lastTime,assistance.lastDistance, assistance.direction);

            // mOptionsFloatingActionMenu.setVisibility(View.VISIBLE);

            //Si el mapa ya existe, aniadimos el marcador de destino
            if (mMap != null && assistance.endLocation!=null) {
                MarkerOptions markerOptions = new MarkerOptions();
                markerOptions.position(assistance.endLocation);
                markerOptions.icon(Utils.bitmapDescriptorFromVectorBlue(getContext(), R.drawable.ic_person_white_24dp)).title(getString(R.string.afiliado));
                mDestinationMarker = mMap.addMarker(markerOptions);
                // Si hay ruta 2: pintamos el segundo punto destino
                // se pinta solamente esta ruta debido a que la ruta 1 se pinta en
                // updateAssistanceState
                if (assistance.route2 != null && !assistance.route2.equals("")) {
                    MarkerOptions markerOptions2 = new MarkerOptions();
                    LatLng latLng2 = assistance.workshopLatLng;
                    if (latLng2 != null) {
                        markerOptions2.position(latLng2);
                        markerOptions2.icon(Utils.bitmapDescriptorFromVectorGray(getContext(), R.drawable.ic_build_white_24dp)).title(getString(R.string.taller));
                        mMap.addMarker(markerOptions2);
                    }

                }

            }


            // Estamos a la espera de que el cliente confirme que el proveedor ha llegado
            switch (assistance.estado) {
                case STATE_WAITING_DIAGNOSTIC:
                    ((DrawerActivity) getActivity()).displayWaiting(getString(R.string.esperando_confirmacion_del_cliente), true);
                    break;

                // Esperando que el cliente acepte la excedencia por costos
                case STATE_ACEPTED_COSTS:
                    ((DrawerActivity) getActivity()).displayWaiting(getString(R.string.esperando_aceptacion_de_costos), true);
                    break;

                // Mostrar boton diagnostico
                case STATE_DIAGNOSTIC:
                    ((DrawerActivity) getActivity()).displayWaiting(null, false);

                    mArrivalConfirm.setVisibility(View.GONE);
                    mStateTextView.setText(getString(R.string.ir_al_diagnostico));
                    mStateTextView.setVisibility(View.VISIBLE);
                    setBarActionsVisible(false);

                    break;
                case STATE_COSTS:
                    mStateTextView.setText(getString(R.string.ir_a_costos));
                    mStateTextView.setVisibility(View.VISIBLE);
                    mArrivalConfirm.setVisibility(View.GONE);
                    setBarActionsVisible(false);


                    break;

                // Mostrar boton termino
                case STATE_SOLUTION:
                    mArrivalConfirm.setVisibility(View.GONE);
                    mStateTextView.setText(getString(R.string.ir_a_solucion));
                    mStateTextView.setVisibility(View.VISIBLE);
                    setBarActionsVisible(false);

                    break;

                // Mostrar boton maniobras
                case STATE_MANEUVERS:
                    mArrivalConfirm.setVisibility(View.GONE);
                    mStateTextView.setVisibility(View.VISIBLE);
                    mStateTextView.setText(getString(R.string.ir_a_maniobras));
                    setBarActionsVisible(false);

                    break;

                // Habiamos dicho que si hacian falta maniobras pero no las llegamos a enviar: vamos a pantalla de maniobras
                case STATE_SHOW_MANEUVERS:
                    ((DrawerActivity) getActivity()).setFragment(DrawerActivity.MANEUVER_FRAGMENT);

                    break;

                // Esperando que lleguen al punto termino (asistencias grua)
                case STATE_WAITING_SOLUTION:
                    ((DrawerActivity) getActivity()).displayWaiting(null, false);
                    mArrivalConfirm.setVisibility(View.GONE);
                    mStateTextView.setVisibility(View.GONE);
                    setBarActionsVisible(true);

                    break;
                default:
                    // Si es libre u ocupado dejamos el mapa sin nada
                    mArrivalConfirm.setVisibility(View.GONE);
                    mStateTextView.setVisibility(View.GONE);

                    break;
            }


        } else {

            ((DrawerActivity)getActivity()).setTitleBar(getString(R.string.mapa));
            ((DrawerActivity)getActivity()).displayWaiting(null, false);

            setBarActionsVisible(false);
            mArrivalConfirm.setVisibility(View.GONE);
            mStateTextView.setVisibility(View.GONE);
            mFab.setVisibility(View.GONE);

            //Borramos el marcador de destino
            if (mDestinationMarker != null) {
                mDestinationMarker.remove();
                mDestinationMarker = null;
            }
            if (mMap != null) {
                mMap.clear();
            }
        }

        if (((DrawerActivity)getActivity()).lateralMenuFragment!=null) {
            if (assistance != null) {
                ((DrawerActivity) getActivity()).lateralMenuFragment.blockPendingRequestsAndCloseSession();
            } else {
                ((DrawerActivity) getActivity()).lateralMenuFragment.unblockPendingRequestsAndCloseSession();
            }
        }

    }

    @Override
    public void updateAssistanceState(Assistance assistance) {
        if (!isAdded()){
            return;
        }

        displayPolylines(assistance);
        refreshScreen();
        getDeviceLocation();
    }


    /**
     * Crea las polilineas apartir de una asistencia dadd
     * @param assistance asistencia para la validacion de despliegue de polilineas
     */
    public void displayPolylines(@Nullable Assistance assistance){
        if (assistance == null && mMap!=null){
            return;
        }

        List<LatLng> polylinePoints = assistance.getPolylineRoute1();
        List<LatLng> polylinePoints2 = assistance.getPolylineRoute2();

        if (polylinePoints2!=null) {
            mMap.addPolyline(getPolyline(polylinePoints2,2,15));
            mMap.addPolyline(getPolyline(polylinePoints2,3,12));
        }

        if (polylinePoints != null) {
            mMap.addPolyline(getPolyline(polylinePoints,0,15));
            mMap.addPolyline(getPolyline(polylinePoints,1,10));

        }

    }

    /**
     * Genera la polilinea con configuraciones
     * @param points puntos de polilinea
     * @param position posicion del color de polilinea
     * @param width grosor de la polilinea
     * @return Polilinea generada
     */
    public PolylineOptions getPolyline(List<LatLng> points, int position, int width){

        return new PolylineOptions()
                .addAll(points)
                .width(width)
                .jointType(JointType.ROUND)
                .color(getResources().getColor(position == 0 ? R.color.blue_800: position == 1?
                        R.color.blue_500 : position == 2? R.color.gray_300 : R.color.gray_400))
                .endCap(new RoundCap())
                .startCap(new RoundCap())
                .geodesic(true)
                .jointType(JointType.BEVEL);
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        mMapFragment.getMapAsync(this);
    }

    @Override
    public void onConnectionSuspended(int i) {
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) { }

    @Override
    public void setLocationChances(LatLng latLng, float bearing){
        mBearing = bearing;
        mLastLocation = latLng;

    }

    @Override
    public void updateInfoAssistance(String time, String distance, String direction) {
        if (time == null || distance == null || direction == null){
            return;
        }

        if (!time.isEmpty()){
            mDurationTextView.setText(time);
        }

        if (!distance.isEmpty()){
            mDistanceTextView.setText(distance);
        }

        if (!direction.isEmpty()){
            mDirectionTextView.setText(direction);
        }

    }

    @Override
    public void displayLocationChanced() {
        getDeviceLocation();
    }

    @Override
    public void refreshStatus() {
        if (isAdded()){
            assert getActivity()!=null;
            ((DrawerActivity)getActivity()).updateAssistanceState();
        }
    }



    @Override
    public void setPresenter(MapAssistanceContract.Presenter presenter) {
        mPresenter = checkNotNull(presenter);
    }

    /**
     * Funcion encargada de mostrar el estado del proveedor
     * @param state estado del proveedor o asistencia
     * @param message mensaje de Notificacion
     */
    @Override
    public void displayState(String state, String message) {
        if (!isAdded()){
            return;
        }


        switch (state){
            case ActiveRequestService.LOCATION_STATUS_ARRIVE:
                mArrivalConfirm.setVisibility(View.VISIBLE);
                mStateTextView.setVisibility(View.GONE);
                setBarActionsVisible(false);

                break;
            case ActiveRequestService.LOCATION_STATUS_DIAGNOSTIC:
                mArrivalConfirm.setVisibility(View.GONE);
                mStateTextView.setText(R.string.ir_al_diagnostico);
                mStateTextView.setVisibility(View.VISIBLE);
                setBarActionsVisible(false);


                break;
            case ActiveRequestService.LOCATION_STATUS_FINAL:
                mArrivalConfirm.setVisibility(View.GONE);
                mStateTextView.setText(getString(R.string.ir_a_solucion));
                mStateTextView.setVisibility(View.VISIBLE);
                setBarActionsVisible(false);

                break;
            case ActiveRequestService.LOCATION_STATE_EMPTY:
                // Sin estado, este caso  sucede cuando ya se tiene una asistencia en
                // proceso pero El estado recibido, paso a ser vacio.
                // ejemplo: El proveedor se alejo del lugar de arribo de la asistencia.
                // por lo cual volvemos a mostrar la barra de tiempo y distancia y
                // ocutamos el boton de arribo.
                assert getActivity()!=null;
                Assistance mAssistance = ((DrawerActivity)getActivity()).getAssistance();
                if (mAssistance!=null) {
                    if (mAssistance.estado.equalsIgnoreCase(STATE_WITH_ASSISTANCE)) {
                        if (mAssistance.estado.equalsIgnoreCase(STATE_WAITING_SOLUTION)) {
                            mStateTextView.setVisibility(View.GONE);
                            mArrivalConfirm.setVisibility(View.GONE);
                            setBarActionsVisible(true);

                        }
                    }
                }

                break;

            case NOTIFICATION_TYPE_CANCEL:
                assert getActivity()!=null;
                ((DrawerActivity)getActivity()).setAssistance(null);
                ((DrawerActivity)getActivity()).cancelAssistance();
                ((DrawerActivity)getActivity()).displayWaiting(null,false);

                new ErrorDialog(getContext(), getString(R.string.asistencia_cancelada_por_cliente)).show();
                ((DrawerActivity)getActivity()).updateAssistanceState();
                break;
            case NOTIFICATION_ACCEPT_COSTS:
                // Quitamos popup
                assert getActivity()!=null;
                ((DrawerActivity)getActivity()).displayWaiting(null,false);
                ((DrawerActivity)getActivity()).updateAssistanceState();

                ((BaseActivity)getActivity()).showSnackbar(message);
                break;
            case NOTIFICATION_ACCEPT_COSTS_TOWING:
                // Quitamos popup
                assert getActivity()!=null;
                ((DrawerActivity)getActivity()).displayWaiting(null,false);
                ((DrawerActivity)getActivity()).updateAssistanceState();

                ((BaseActivity)getActivity()).showSnackbar(message);

                break;
            case NOTIFICATION_ACCEPT_MANEUVER:
                // Quitamos popup
                assert getActivity()!=null;
                ((DrawerActivity)getActivity()).displayWaiting(null,false);
                ((DrawerActivity)getActivity()).updateAssistanceState();

                // Limpiamos botones
                mArrivalConfirm.setVisibility(View.GONE);
                mStateTextView.setVisibility(View.GONE);

                ((BaseActivity)getActivity()).showSnackbar(message);
                break;
            case NOTIFICATION_TYPE_ASSIG_PROV_SOAANG:
                assert getActivity()!=null;
                ((DrawerActivity)getActivity()).updateAssistanceState();

                break;

            case NOTIFICATION_TYPE_PREPARE_DIAGNOSTIC:
                assert getActivity()!=null;
                ((DrawerActivity)getActivity()).displayWaiting(null,false);
                mArrivalConfirm.setVisibility(View.GONE);
                mStateTextView.setText(R.string.ir_al_diagnostico);
                mStateTextView.setVisibility(View.VISIBLE);
                setBarActionsVisible(false);


                break;

            case NOTIFICATION_TYPE_PREPARE_MANEUVER:
                // Quitamos popup
                assert getActivity()!=null;
                ((DrawerActivity)getActivity()).displayWaiting(null,false);

                // Mostramos boton maniobras
                mArrivalConfirm.setVisibility(View.GONE);
                mStateTextView.setVisibility(View.VISIBLE);
                mStateTextView.setText(R.string.ir_a_maniobras);
                setBarActionsVisible(false);


                break;

            case NOTIFICATION_TYPE_PREPARE_COST:
                // Cerramos el dialogo
                assert getActivity()!=null;
                ((DrawerActivity)getActivity()).displayWaiting(null,false);
                mArrivalConfirm.setVisibility(View.GONE);
                mStateTextView.setText(R.string.ir_a_costos);
                mStateTextView.setVisibility(View.VISIBLE);
                setBarActionsVisible(false);


                break;

            case NOTIFICATION_TYPE_PREPARE_TERMINATE:
                // Cerramos el dialogo
                assert getActivity()!=null;
                ((DrawerActivity)getActivity()).displayWaiting(null,false);
                mArrivalConfirm.setVisibility(View.GONE);
                mStateTextView.setText(getString(R.string.ir_a_solucion));
                mStateTextView.setVisibility(View.VISIBLE);
                setBarActionsVisible(false);

                break;

            case NOTIFICATION_TYPE_PREPARE_LAST_SOLUTION:
                mArrivalConfirm.setVisibility(View.GONE);
                mStateTextView.setVisibility(View.GONE);
                // Cerramos el dialogo
                assert getActivity()!=null;
                ((DrawerActivity)getActivity()).displayWaiting(null,false);
                setBarActionsVisible(true);


                break;

            case NOTIFICATION_TYPE_PREPARE_ACEPT:
                assert getActivity()!=null;
                ((DrawerActivity)getActivity()).displayWaiting(getString(R.string.esperando_aceptacion_de_costos),true);
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CANCEL_ASSISTANCE){
            if (resultCode == RESULT_OK){
                assert getActivity()!=null;
                Toast.makeText(getContext(), R.string.asistencia_cancelada_correctamente_mensaje, Toast.LENGTH_SHORT).show();
                ((DrawerActivity)getActivity()).setAssistance(null);
                refreshScreen();
            }
        }
    }

    public void setBarActionsVisible(boolean visible){
        int visibility = visible?View.VISIBLE:View.GONE;
        mTopBar.setVisibility(visibility);
        mBottomBar.setVisibility(visibility);
    }

    @Override
    public void toggleMenuPressed() {
        if (!isAdded()){
            return;
        }
    }

    /**
     * Muestra las opciones del menu de asistencias al presionar el
     * boton Flotante
     * @param v boton flotante
     */
    public void showMenu(View v) {
        if (getContext() == null) {
            return;
        }

        PopupMenu menu = new PopupMenu(getContext(), v);
        menu.inflate(R.menu.options_assistance);
        menu.setOnMenuItemClickListener(this);

        MenuPopupHelper menuHelper = new MenuPopupHelper(getContext(), (MenuBuilder) menu.getMenu(), v);
        menuHelper.setForceShowIcon(true);
        menuHelper.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {

        switch (menuItem.getItemId()){
            case R.id.reprogram:
                reprogramAssistance();

                break;
            case R.id.cancel:
                cancelAssistance();

                break;
            case R.id.detail:
                Intent i = new Intent(getContext(), MoreInfoActivity.class);
                assert getActivity() != null;
                i.putExtra(MoreInfoActivity.CURRENT_ASSISTANCE, ((DrawerActivity) getActivity()).getAssistance());
                startActivity(i);

                break;
            case R.id.route:
                goToNavigation();

                break;
        }
        return false;
    }

    /**
     * Ejecuta el dialogo de reprogramacion de
     * asistencia.
     */
    private void reprogramAssistance() {

        assert getActivity() != null;
        Assistance mAssistance = ((DrawerActivity) getActivity()).getAssistance();
        if (mAssistance == null) {
            Toast.makeText(getContext(), R.string.intentalo_mas_tarde, Toast.LENGTH_SHORT).show();
            return;
        }

        new ReprogramAssistanceDialog(getActivity(),
                mAssistance.id,
                () -> {
                    ((BaseActivity) getActivity()).showSnackbar(getString(R.string.asistencia_reprogramada_correctamente));
                    ((DrawerActivity) getActivity()).updateAssistanceState();
                }).show();
    }

    /**
     * Comunica la vista de Cancelacion de asistencia
     */
    private void cancelAssistance() {
        assert getActivity() != null;
        Assistance mAssistance = ((DrawerActivity) getActivity()).getAssistance();
        if (mAssistance == null) {
            Toast.makeText(getContext(), R.string.intentalo_mas_tarde, Toast.LENGTH_SHORT).show();
            return;
        }

        Intent i = new Intent(getContext(), RejectAssistanceActivity.class);
        i.putExtra(RejectAssistanceActivity.ASSISTANCE_ID, mAssistance.id);
        i.putExtra(RejectAssistanceActivity.REJECT_TYPE, RejectAssistanceActivity.PROCESS_ASSISTANCE);
        startActivityForResult(i, CANCEL_ASSISTANCE);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

        switch (menuItem.getItemId()){
            case R.id.close:
                bottomDrawerBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
                break;
            case R.id.routes:
                isRouteEnabled = true;
                isGestureEnabled = false;
                bottomDrawerBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
                getDeviceLocation();
                break;

        }
        return false;
    }




}
