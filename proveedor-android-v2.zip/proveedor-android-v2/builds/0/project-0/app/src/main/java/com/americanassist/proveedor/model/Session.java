package com.americanassist.proveedor.model;

/**
 * Definicion del modelo Session .
 *
 * <p> Esta es la clase de modelos de datos para serializar el JSON
 * transmitido por el webservice inicio_sesion_proveedor.
 * </p>
 *
 */

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Session{
    @SerializedName("error")
    @Expose
    public Boolean error;
    @SerializedName("mensaje")
    @Expose
    public String mensaje;
    @SerializedName("token_unico")
    @Expose
    public String tokenUnico;
    @SerializedName("country")
    @Expose
    public String country;
    @SerializedName("idservicio")
    @Expose
    public String idservicio;
    @SerializedName("numero_core_prov")
    @Expose
    public String numeroCoreProv;
    @SerializedName("idproveedor")
    @Expose
    public String idproveedor;
    @SerializedName("idcontacto")
    @Expose
    public String idcontacto;
    @SerializedName("duplicado_sesion")
    @Expose
    public String duplicadoSesion;

    @SerializedName("nombre_contacto")
    @Expose
    public String contactName;

    @SerializedName("nombre_proveedor")
    @Expose
    public String providerName;

    /**
     * Funcion que permite llenar el modelo Provider a partir de los datos alojados en Session
     * @return el proveedor con todos sus datos
     */
    public Provider getAsProvider(){

        return new Provider(idproveedor, tokenUnico, country,numeroCoreProv,idcontacto,contactName,providerName);
    }

    @Override
    public String toString() {
        return "Session{" +
                "error=" + error +
                ", mensaje='" + mensaje + '\'' +
                ", tokenUnico='" + tokenUnico + '\'' +
                ", country='" + country + '\'' +
                ", idservicio='" + idservicio + '\'' +
                ", numeroCoreProv='" + numeroCoreProv + '\'' +
                ", idproveedor='" + idproveedor + '\'' +
                ", idcontacto='" + idcontacto + '\'' +
                ", duplicadoSesion='" + duplicadoSesion + '\'' +
                '}';
    }
}
