package com.americanassist.proveedor.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import org.apache.commons.lang3.text.WordUtils;


public class Provider {
    @SerializedName("idproveedor")
    @Expose
    public String idProvider;

    @SerializedName("token_unico")
    @Expose
    public String token;

    @SerializedName("country")
    @Expose
    public String country;

    @SerializedName("numero_core_prov")
    @Expose
    public String coreProvNumber;

    @SerializedName("idcontacto")
    @Expose
    public String idContact;

    @SerializedName("nombre_contacto")
    @Expose
    public String contactName;

    @SerializedName("nombre_proveedor")
    @Expose
    public String providerName;

    public Provider(String idProvider, String token, String country, String coreProvNumber, String idContact,
                    String contactName, String providerName) {
        this.idProvider = idProvider;
        this.token = token;
        this.country = country;
        this.coreProvNumber = coreProvNumber;
        this.idContact = idContact;
        this.contactName = contactName;
        this.providerName = providerName;
    }

    public String getCapitalizeProviderName() {
        return WordUtils.capitalize(providerName.toLowerCase());
    }

    public String getCapitalizeContactName() {
        return WordUtils.capitalize(contactName.toLowerCase());
    }

    public Provider() {}


    @Override
    public String toString() {
        return "Provider{" +
                "idProvider='" + idProvider + '\'' +
                ", token='" + token + '\'' +
                ", country='" + country + '\'' +
                ", coreProvNumber='" + coreProvNumber + '\'' +
                ", idContact='" + idContact + '\'' +
                '}';
    }
}

