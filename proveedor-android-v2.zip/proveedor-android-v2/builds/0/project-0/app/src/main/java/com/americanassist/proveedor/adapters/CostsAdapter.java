package com.americanassist.proveedor.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import com.americanassist.proveedor.model.Cost;
import com.americanassist.proveedor.R;

import org.apache.commons.lang3.text.WordUtils;

import java.util.ArrayList;

/**
 * <p>Adaptador para las listas de costos Normales de una Asistencia</p>
 */
public class CostsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_COST = 1;

    public ArrayList<Cost> mData = new ArrayList<>();
    private LayoutInflater mLayoutInflater;
    CostsAdapterCallback costsAdapterCallback;
    private boolean onBind;

    /**
     * Callback para notificar cuando se edita un campo
     */
    public interface CostsAdapterCallback {
        void onEditChanged();
    }

    public CostsAdapter(Context ctx, CostsAdapterCallback costsAdapterCallback) {
        mLayoutInflater = LayoutInflater.from(ctx);
        this.costsAdapterCallback = costsAdapterCallback;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case TYPE_COST:
                View v = mLayoutInflater.inflate(R.layout.card_cost, parent, false);
                return new CostsAdapter.CostVH(v);
            default:
                return null;
        }
    }

    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        switch (holder.getItemViewType()) {
            case TYPE_COST:
                final Cost cost = mData.get(position);
                ((CostVH) holder).txtTitle.setText(WordUtils.capitalize(cost.description.toLowerCase()));
                ((CostVH) holder).editAmount.setText(String.valueOf(cost.amount));
                ((CostVH) holder).editAmount.setEnabled(cost.editable);

                ((CostVH) holder).editAmount.addTextChangedListener(new TextWatcher() {

                    public void afterTextChanged(Editable s) {
                        String amount = ((CostVH) holder).editAmount.getText().toString();
                        if (amount.equals("")){
                            cost.amount = 0.0;
                        }
                        else{
                            cost.amount = Double.parseDouble(amount);
                        }
                        costsAdapterCallback.onEditChanged();
                    }

                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                    }
                });

                ((CostVH) holder).switchSelected.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

                    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                        if(!onBind) {
                            cost.checked = isChecked;
                            costsAdapterCallback.onEditChanged();
                        }

                    }
                });
                onBind = true;
                if (cost.checked){
                    ((CostVH) holder).switchSelected.setChecked(true);
                }
                else{
                    ((CostVH) holder).switchSelected.setChecked(false);
                }
                onBind = false;
                break;


        }
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    @Override
    public int getItemViewType(int position) {

        return TYPE_COST;

    }

    public void addCosts(ArrayList<Cost> costs) {

        mData.addAll(costs);
        notifyDataSetChanged();
    }

    public void clean() {
        mData.clear();
        notifyDataSetChanged();
    }

    class CostVH extends RecyclerView.ViewHolder {
        TextView txtTitle;
        EditText editAmount;
        Switch switchSelected;

        public CostVH(View itemView) {
            super(itemView);
            editAmount = itemView.findViewById(R.id.CC_edittext_amount);
            txtTitle = itemView.findViewById(R.id.CC_textview_title);
            switchSelected = itemView.findViewById(R.id.CC_switch_selected);
        }
    }


}
