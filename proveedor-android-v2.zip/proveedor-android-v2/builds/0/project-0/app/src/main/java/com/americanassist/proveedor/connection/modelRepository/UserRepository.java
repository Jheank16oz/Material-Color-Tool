package com.americanassist.proveedor.connection.modelRepository;

import android.content.Context;

import com.americanassist.proveedor.BuildConfig;
import com.americanassist.proveedor.connection.CallBackCustom;
import com.americanassist.proveedor.connection.Webservice;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.model.CountryResult;
import com.americanassist.proveedor.model.Detail;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.model.Session;
import com.google.firebase.iid.FirebaseInstanceId;

import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * UserRepository .
 *
 * <p> Esta es la clase tipo repositorio en la que se realiza la conexion al webservice
 * inicio_sesion_proveedor, y luego se obtiene la respuesta por medio de retrofit.
 * </p>
 *
 */

public class UserRepository {

    private Context mContext;
    private Webservice mWebService;

    public UserRepository(Context context){
        mContext = context;
        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl(BuildConfig.URL_SERVER)
                .addConverterFactory(GsonConverterFactory.create());
        Retrofit mRestAdapter = builder.build();
        mWebService = mRestAdapter.create(Webservice.class);
    }

    /**
     * Metodo que interactua con la conexion al webservice para recibir respuesta del
     * webservice del login
     * @param user nombre de usuario utilizado para iniciar sesion en la vista del login
     * @param latitude latitud actual en la que se encuentra el tecnico
     * @param longitude longitud actual en la que se encuentra el tecnico
     * @param password contrasenia utilizada para iniciar sesion en la vista del login
     * @param loginCallback comunicador que facilita el manejo de proceson segun sea la r
     *                               espuesta del webservice
     */
    public void login(String user,
                      double latitude,
                      double longitude,
                      String password,
                      final ApiManagerHelper.SessionCallback loginCallback){

        mWebService.getUserSession(user,
                String.valueOf(latitude),
                String.valueOf(longitude),
                "android",
                password,
                FirebaseInstanceId.getInstance().getToken())
                .enqueue(new CallBackCustom<Session>(mContext){

                    @Override
                    public void onResponse(Call<Session> call, Response<Session> response) {
                        super.onResponse(call, response);

                        if (response.isSuccessful()){

                            Session mSession = response.body();

                            if (mSession.duplicadoSesion.equalsIgnoreCase("1")) {
                                loginCallback.duplicatedSession(mSession);
                            }else{
                                loginCallback.login(mSession.getAsProvider());
                            }
                        }else{
                            loginCallback.onFailure();
                        }
                    }

                });

    }

    /**
     * Metodo que interactua con la conexion al webservice para recibir respuesta de las
     * sesiones caducadas
     * @param providerId este es el identificador de la empresa a la cual pertenece el tecnico
     * @param contactId identificacion del tecnico como tal
     * @param country pais actual, en el que se encuentra el tecnico
     * @param expiredSessionCallback comunicador que facilita el manejo de proceso segun sea la respuesta del WS
     */
    public void expiredSessions(String providerId,
                                String contactId,
                                String country,
                                String latitude,
                                String longitude,
                                final ApiManagerHelper.ExpiredSessionCallback expiredSessionCallback){

        mWebService.getExpiredSession(providerId, contactId, country,"1","android", FirebaseInstanceId.getInstance().getToken(), latitude, longitude)
                .enqueue(new CallBackCustom<Provider>(mContext){
                    @Override
                    public void onResponse(Call<Provider> call, Response<Provider> response) {
                        super.onResponse(call, response);

                        if (response.isSuccessful()){
                            Provider mProvider = response.body();
                            expiredSessionCallback.onSuccessExpiredSession(mProvider);
                        }
                    }
                });
    }

    /**
     * Metodo que interactua con la conexion al webservice para emitir una senial de emergencia
     *
     * @param idproveedor este es el identificador de la empresa a la cual pertenece el tecnico
     * @param idcontacto identificacion del tecnico como tal
     * @param country pais actual, en el que se encuentra el tecnico
     * @param latitude latitud de la ubicacion actual
     * @param longitude longitus de la ubicacion actual
     * @param panicAlertCallback comunicador que facilita el manejo de proceso segun sea la respuesta del WS evento_panico_proveedor
     */
    public void panicAlert(final String idproveedor,
                           final String idcontacto,
                           final String country,
                           final double latitude,
                           final double longitude,
                           final ApiManagerHelper.PanicAlertCallback panicAlertCallback){

        mWebService.sendPanicAlert(idproveedor, idcontacto, country, String.valueOf(latitude), String.valueOf(longitude))
                .enqueue(new CallBackCustom<Detail>(mContext){

                    @Override
                    public void onResponse(Call<Detail> call, Response<Detail> response) {
                        super.onResponse(call, response);

                        if (response.isSuccessful()){
                            Detail detail = response.body();
                            panicAlertCallback.onSuccessPanicAlert(detail);
                        }
                    }
                });
    }


    /**
     * Metodo encargado de obtener la lista de paises de la app
     */
    public void getCountries(final ApiManagerHelper.CountriesCallback countriesCallback){
        mWebService.getCountries().enqueue(new CallBackCustom<CountryResult>(mContext){
            @Override
            public void onResponse(Call<CountryResult> call, Response<CountryResult> response) {
                super.onResponse(call, response);

                if (response.isSuccessful()){
                    countriesCallback.onSuccess(response.body().countries);
                }
            }

            @Override
            public void onFailure(Call<CountryResult> call, Throwable t) {
                super.onFailure(call, t);
                countriesCallback.onFailure();
            }


        });

    }

    /**
     * Metodo encargado de enviar una solicitud re registro de proveedor.
     * @param username nombre de usuario del proveedor
     * @param description descripcion por parte del proveedor a registrarse
     * @param country pais donde se solicita el registro
     * @param email correo electronico del proveedor
     * @param phone telefono del ptoveedor
     * @param service servicio encargado del proveedor
     */
    public void sendRequestRegisterProvider(String username, String description, String country,
                                            String email, String phone, String service,String city, final ApiManagerHelper.ProviderRegisterCallback providerRegisterCallback){

        mWebService.sendRequestRegister(username,description,country,email,phone,service, city)
                .enqueue(new CallBackCustom<Detail>(mContext){
                    @Override
                    public void onResponse(Call<Detail> call, Response<Detail> response) {
                        super.onResponse(call, response);
                        if (response.isSuccessful()) {
                            providerRegisterCallback.onSuccess(response.body().message);
                        }
                    }

                    @Override
                    public void onFailure(Call<Detail> call, Throwable t) {
                        super.onFailure(call, t);
                        providerRegisterCallback.onFailure();
                    }
                });
    }
}
