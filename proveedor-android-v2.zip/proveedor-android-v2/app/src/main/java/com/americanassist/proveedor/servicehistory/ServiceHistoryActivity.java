package com.americanassist.proveedor.servicehistory;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.americanassist.proveedor.MoreInfoActivity;
import com.americanassist.proveedor.R;
import com.americanassist.proveedor.commons.Components.EndlessRecyclerViewScrollListener;
import com.americanassist.proveedor.commons.Controllers.BaseActivity;
import com.americanassist.proveedor.managers.Server.ApiManager;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.model.Service;
import com.americanassist.proveedor.servicehistory.adapter.ServiceHistoryAdapter;
import com.americanassist.proveedor.utils.Functions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationServices;

import java.util.ArrayList;


/**
 * Vista para la gestion del historial de servicios del proveedor
 */
public class ServiceHistoryActivity
        extends BaseActivity
        implements ServiceHistoryAdapter.OnItemClickListener,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener

{
    private RelativeLayout rlBack;
    protected RecyclerView recyclerViewList;
    private TextView txtNoServices;
    private Context mContext;
    private ServiceHistoryAdapter serviceHistoryAdapter;
    protected EndlessRecyclerViewScrollListener scrollListener;
    protected LinearLayoutManager llm;
    public GoogleApiClient mGoogleApiClient;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_service_history);

        rlBack = findViewById(R.id.APR_relativelayout_back_history);
        recyclerViewList = findViewById(R.id.APR_recyclerview_listitems_history);
        txtNoServices = findViewById(R.id.APR_textview_nohistory);

        mContext = this;
        txtNoServices.setVisibility(View.GONE);
        llm = new LinearLayoutManager(this);
        recyclerViewList.setLayoutManager(llm);

        // Google Api
        if (mGoogleApiClient == null)
        {
            mGoogleApiClient = new GoogleApiClient.Builder(this)
                    .addApi(LocationServices.API)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .build();
        }

        initListeners();

        mGoogleApiClient.connect();

        showLoadingView();
    }

    @Override
    public void onDestroy()
    {
        mGoogleApiClient.disconnect();
        super.onDestroy();
    }

    @Override
    public void onConnected(@Nullable Bundle bundle)
    {
        hideLoadingView();
        serviceHistoryAdapter = new ServiceHistoryAdapter(this);
        recyclerViewList.setAdapter(serviceHistoryAdapter);
        serviceHistoryAdapter.setOnClickListener(ServiceHistoryActivity.this);

        scrollListener = new EndlessRecyclerViewScrollListener(llm)
        {
            @Override
            public void onLoadMore(int page, int totalItemsCount, RecyclerView view)
            {
                loadMoreData(page);
            }

            @Override
            public void onScrolled(RecyclerView view, int dx, int dy)
            {
                super.onScrolled(view, dx, dy);
            }
        };
        recyclerViewList.addOnScrollListener(scrollListener);
    }


    @Override
    public void onConnectionSuspended(int i)
    {
        hideLoadingView();
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult)
    {
        hideLoadingView();
    }

    @Override
    public void onItemClick(int position, final Service assistance)
    {
        Intent detailService = new Intent(ServiceHistoryActivity.this, MoreInfoActivity.class);
        detailService.putExtra(MoreInfoActivity.CURRENT_ASSISTANCE, assistance);
        startActivity(detailService);
    }

    /**
     * Metodo que se ejecutara al momento de querer retroceder
     * de vista
     */
    private void initListeners()
    {
        rlBack.setOnClickListener(v -> {
            /*
             * Finaliza el activity actual
             */
            finish();
        });
    }

    /**
     * Metodo para cargar la informacion
     * del historial de usuario
     * @param page paginador indice
     */
    private void loadMoreData(final int page)
    {
        if (Functions.checkInternetConnection(mContext)) {
            return;
        }

        /*
         * Confirma que los permisos de localizacion esten disponibles
         */
        askForPermission(android.Manifest.permission.ACCESS_FINE_LOCATION, null, new PermissionListener()
        {
            @Override
            public void onPermissionGranted()
            {
                try
                {
                    /*
                     * Verificamos la ultima ubicacion
                     */
                    Location mLastLocation;
                    mLastLocation = LocationServices.FusedLocationApi.getLastLocation(mGoogleApiClient);

                    if(mLastLocation != null)
                    {
                        Provider mProvider = SharedPreferencesManager.getProvider(getBaseContext());
                        if (mProvider == null) {
                            return;
                        }

                        serviceHistoryAdapter.showLoading();

                        /*
                         * Consultamos al metodo que llama al webservice para consultar los servicios
                         * en la trazabilidad
                         */
                        new ApiManager(mContext).getAvailableServices(
                                mProvider.country,
                                mProvider.idProvider,
                                mProvider.idContact,
                                mLastLocation.getLatitude(),
                                mLastLocation.getLongitude(),
                                (page-1) * 5,
                                new ApiManagerHelper.ApiGetAvailableServicesCallback()
                                {

                                    @Override
                                    public void onGetAvailableServicesSuccess(ArrayList<Service> assistances)
                                    {
                                        serviceHistoryAdapter.hideLoading();

                                        /*
                                         * Agregamos lo alojado en la respuesta del web service
                                         * al adaptador, que nos permitira visualizarlo
                                         */
                                        serviceHistoryAdapter.addHistoryServices(assistances);

                                        /*
                                         * Validamos que existan datos en la trazabilidad del historial de servicios
                                         */
                                        if (serviceHistoryAdapter.mData.size() > 0)
                                        {
                                            txtNoServices.setVisibility(View.GONE);
                                        }
                                        else
                                        {
                                            txtNoServices.setVisibility(View.VISIBLE);
                                        }
                                    }

                                    @Override
                                    public void onGetAvailableServicesError(String error)
                                    {
                                        serviceHistoryAdapter.hideLoading();
                                    }
                                });
                    }
                    else
                    {
                        Snackbar.make(((ViewGroup) findViewById(android.R.id.content)).getChildAt(0), "Necesitamos conocer tu ubicacion", Snackbar.LENGTH_LONG).show();
                    }
                }
                catch (SecurityException e)
                {
                    e.printStackTrace();
                    Snackbar.make(((ViewGroup) findViewById(android.R.id.content)).getChildAt(0), "Necesitamos conocer tu ubicacion", Snackbar.LENGTH_LONG).show();
                }

            }
            @Override
            public void onPermissionDenied()
            {
                Snackbar.make(((ViewGroup) findViewById(android.R.id.content)).getChildAt(0), "Necesitamos conocer tu ubicacion", Snackbar.LENGTH_LONG).show();
            }
        });
    }
}
