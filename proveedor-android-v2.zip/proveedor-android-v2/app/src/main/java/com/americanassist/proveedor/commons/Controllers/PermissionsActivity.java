package com.americanassist.proveedor.commons.Controllers;

import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.PermissionChecker;
import android.support.v7.app.AppCompatActivity;

import static android.R.attr.targetSdkVersion;

/**
 * Se encarga de gestionar los permisos de la app y hereda de AppcompatActivity
 * para dar soprte a versiones de android inferiores
 */
public abstract class PermissionsActivity extends AppCompatActivity {

    private final int PERMISSION = 1;

    private PermissionListener permissionListener;

    /**
     * Callback de permisos
     */
    public interface PermissionListener {
        /**
         * Notifica cuando se acepta un permiso
         */
        void onPermissionGranted();

        /**
         * Notifica cuando se rechazan permisos
         */
        void onPermissionDenied();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }


    public void askForPermission(final String permission, String message, PermissionListener permissionListener){
        this.permissionListener = permissionListener;

        int hasPermission = -10;

        if (targetSdkVersion >= Build.VERSION_CODES.M) {
            // targetSdkVersion >= Android M, we can use Context#checkSelfPermission
            hasPermission = ContextCompat.checkSelfPermission(this, permission);
        } else {
            // targetSdkVersion < Android M, we have to use PermissionChecker
            hasPermission = PermissionChecker.checkSelfPermission(this, permission);
        }

        if (hasPermission != PackageManager.PERMISSION_GRANTED) {
            if (!ActivityCompat.shouldShowRequestPermissionRationale(this, permission)) {
                if (message != null){
                    showMessageOKCancel(message,
                            (dialog, which) -> ActivityCompat.requestPermissions(PermissionsActivity.this, new String[]{permission},
                                    PERMISSION));
                }
                else{
                    ActivityCompat.requestPermissions(PermissionsActivity.this, new String[]{permission},
                            PERMISSION);
                }
                return;
            }
            ActivityCompat.requestPermissions(this, new String[]{permission},
                    PERMISSION);
            return;
        } else {
            permissionListener.onPermissionGranted();
        }
    }

    /**
     * Se encarga de mostrar un mensaje racional cuando ya se ha rechazado los permisos
     * una vez.
     * @param message mensaje solicitado
     * @param okListener callback de aceptar
     */
    private void showMessageOKCancel(String message, DialogInterface.OnClickListener okListener) {
        new android.app.AlertDialog.Builder(this)
                .setMessage(message)
                .setPositiveButton("Aceptar", okListener)
                .create()
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

            switch (requestCode) {
                case PERMISSION:
                    if (grantResults != null && grantResults.length > 0) {
                        if(permissionListener!=null) {

                            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                                permissionListener.onPermissionGranted();
                            } else {
                                permissionListener.onPermissionDenied();
                            }
                            break;
                        }
                    }

                default:
                    super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        }
    }
}
