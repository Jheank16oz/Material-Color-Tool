package com.americanassist.proveedor.adapters;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

import com.americanassist.proveedor.R;

/**
 *
 * Holder para el manejo e inicializacion de la vista de un
 * item de Informacion de asistencia.
 */


public class RequestInfoAssistanceViewHolder extends RecyclerView.ViewHolder {

    public TextView tittle;
    public TextView content;

    RequestInfoAssistanceViewHolder(View itemView) {
        super(itemView);
        tittle = itemView.findViewById(R.id.tittle);
        content = itemView.findViewById(R.id.content);
    }


}
