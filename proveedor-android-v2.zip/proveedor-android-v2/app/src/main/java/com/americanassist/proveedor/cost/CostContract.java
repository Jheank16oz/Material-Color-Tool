package com.americanassist.proveedor.cost;

import com.americanassist.proveedor.BasePresenter;
import com.americanassist.proveedor.BaseView;

/**
 *
 * <p>Contrato para las caracteristicas de costos en presentador
 * y vista.</p>
 */

public interface CostContract {
    interface View extends BaseView<CostContract.Presenter> {
        void displayState(String state);

    }

    interface Presenter extends BasePresenter {
        void updateAssistanceState(String state);
    }

}
