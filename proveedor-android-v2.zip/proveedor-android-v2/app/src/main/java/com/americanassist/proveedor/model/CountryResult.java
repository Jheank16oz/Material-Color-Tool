package com.americanassist.proveedor.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;



public class CountryResult implements Parcelable {
    @SerializedName("error")
    @Expose
    public Boolean error;
    @SerializedName("mensaje")
    @Expose
    public String message;
    @SerializedName("paises")
    @Expose
    public List<Country> countries = new ArrayList<>();


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(this.error);
        dest.writeString(this.message);
        dest.writeTypedList(this.countries);
    }

    public CountryResult() {
    }

    protected CountryResult(Parcel in) {
        this.error = (Boolean) in.readValue(Boolean.class.getClassLoader());
        this.message = in.readString();
        this.countries = in.createTypedArrayList(Country.CREATOR);
    }

    public static final Parcelable.Creator<CountryResult> CREATOR = new Parcelable.Creator<CountryResult>() {
        @Override
        public CountryResult createFromParcel(Parcel source) {
            return new CountryResult(source);
        }

        @Override
        public CountryResult[] newArray(int size) {
            return new CountryResult[size];
        }
    };
}
