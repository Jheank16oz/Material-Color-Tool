
package com.americanassist.proveedor.pending;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SwitchCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ViewSwitcher;

import com.americanassist.proveedor.DrawerActivity;
import com.americanassist.proveedor.MoreInfoActivity;
import com.americanassist.proveedor.R;
import com.americanassist.proveedor.adapters.PendingAssistanceAdapter;
import com.americanassist.proveedor.commons.Controllers.BaseActivity;
import com.americanassist.proveedor.dialogs.TwoOptionsDialog;
import com.americanassist.proveedor.model.RequestAssistance;
import com.americanassist.proveedor.rejectassistance.RejectAssistanceActivity;

import java.util.ArrayList;

import jp.wasabeef.recyclerview.animators.SlideInUpAnimator;

import static android.app.Activity.RESULT_OK;
import static com.americanassist.proveedor.BaseApplication.getInstance;
import static com.americanassist.proveedor.MoreInfoActivity.CURRENT_ASSISTANCE;

/**
 * <p>PendingRequestFragment, contiene las caracteristicas de las vista
 * de asistencias pendientes.</p>
 */
public class PendingRequestFragment extends Fragment implements PendingContract.View,PendingAssistanceAdapter.PendingAssistanceAdapterListener, PendingAssistanceAdapter.OnItemClickListener,PendingAssistanceAdapter.OnReloadClickListener{


    private PendingContract.Presenter mPresenter;


    /**
     * Request code para el cancelado de asistencia.
     */
    private static final int CANCEL_ASSISTANCE = 6;

    protected RecyclerView mAssistanceRecyclerView;
    private PendingAssistanceAdapter mPendingAssistanceAdapter;
    protected LinearLayoutManager mLinearLayoutManager;
    private View view;
    private SwitchCompat activeSwitchCompat;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_pending_requests, container, false);
        initializeComponents(view);
        return view;
    }

    private void initializeComponents(View view) {
        mAssistanceRecyclerView = view.findViewById(R.id.APR_recyclerview_listitems);
       /* TextView tatNoAssistance = view.findViewById(R.id.APR_textview_noassistances);
        tatNoAssistance.setVisibility(View.GONE);*/
        mLinearLayoutManager = new LinearLayoutManager(getContext());
        mAssistanceRecyclerView.setLayoutManager(mLinearLayoutManager);
        view.findViewById(R.id.refresh).setOnClickListener(view1 -> mPresenter.resetInformation());
        activeSwitchCompat = view.findViewById(R.id.active);

        //Sound Notification
        initializeList();
    }

    @Override
    public void initializeActiveCheckedListener(){
        if (!isAdded()) {
            return;
        }
        activeSwitchCompat.setOnCheckedChangeListener((compoundButton, b) -> mPresenter.validateUserActivity(b));
    }

    private void initializeList() {
        mAssistanceRecyclerView.setItemAnimator(new SlideInUpAnimator());
        mPendingAssistanceAdapter = new PendingAssistanceAdapter(getContext(),this);
        mPendingAssistanceAdapter.setOnItemClickListener(this);
        mPendingAssistanceAdapter.setOnReloadClickListener(this);
        mAssistanceRecyclerView.setAdapter(mPendingAssistanceAdapter);

        //Paginacion
        mAssistanceRecyclerView.addOnScrollListener(recyclerViewOnScrollListener);

        if (getActivity()!=null) {
            mPresenter.updateUserState(((DrawerActivity) getActivity()).getAssistance());
        }
    }

    @Override
    public void onResume() {
        super.onResume();

        // Sound notification
        updateFooter(PendingAssistanceAdapter.FooterType.LOAD_MORE);
        mPresenter.resetInformation();
    }

    @Override
    public void onConfirmClicked(RequestAssistance assistance) {
        if (!isAdded()){
            return;
        }

        TwoOptionsDialog twoOptionsDialog = new TwoOptionsDialog(getContext(),getString(R.string.confirma_asistencia_titulo), getString(R.string.confirma_asistencia_content) +" "+ assistance.serviceName + "?", getString(R.string.cancelar), getString(R.string.confirmar), new TwoOptionsDialog.TwoOptionsDialogListener() {
            @Override
            public void onCancelClicked() {
                // ignored
            }

            @Override
            public void onAcceptClicked() {
                mPresenter.acceptAssistance(assistance.id,assistance.serviceId,assistance.acceptAssistance);
            }
        });
        twoOptionsDialog.show();
    }

    @Override
    public void onRejectClicked(RequestAssistance assistance) {
        Intent i = new Intent(getContext(),RejectAssistanceActivity.class);
        i.putExtra(RejectAssistanceActivity.ASSISTANCE_ID, assistance.id);
        i.putExtra(RejectAssistanceActivity.REJECT_TYPE, RejectAssistanceActivity.REQUEST_ASSISTANCE);
        startActivityForResult(i,CANCEL_ASSISTANCE);
    }

    @Override
    public void onMoreInfoClicked(RequestAssistance assistance) {
        if (!isAdded()){
            return;
        }
        Intent detailIntent = new Intent(getContext(), MoreInfoActivity.class);
        detailIntent.putExtra(CURRENT_ASSISTANCE,assistance);
        startActivity(detailIntent);
    }

    @Override
    public void onItemClick(int position, View view) {
        // ignored
    }

    @Override
    public void onReloadClick() {
        if (!isAdded()){
            return;
        }

        updateFooter(PendingAssistanceAdapter.FooterType.LOAD_MORE);
        mPresenter.loadMoreData();
    }

    private RecyclerView.OnScrollListener recyclerViewOnScrollListener = new RecyclerView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
            super.onScrollStateChanged(recyclerView, newState);
        }

        @Override
        public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
            super.onScrolled(recyclerView, dx, dy);
            int visibleItemCount = mLinearLayoutManager.getChildCount();
            int firstVisibleItemPosition = mLinearLayoutManager.findFirstVisibleItemPosition();
            int lastVisibleItemPosition = mLinearLayoutManager.findLastVisibleItemPosition();

            mPresenter.validateScrolled(visibleItemCount,firstVisibleItemPosition,lastVisibleItemPosition);
        }
    };


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CANCEL_ASSISTANCE){
            if (resultCode == RESULT_OK){
                if (isAdded()) {
                    Snackbar.make(view.findViewById(android.R.id.content), R.string.asistencia_rechazada_mensaje_correcto, Snackbar.LENGTH_SHORT).show();
                    mPresenter.resetInformation();
                }
            }
        }
    }

    @Override
    public void loadData(ArrayList<RequestAssistance> assistance) {
        if (!isAdded()){
            return;
        }
        mPendingAssistanceAdapter.addAll(assistance);
    }

    @Override
    public void setLoading(boolean isLoading) {
        if(!isAdded()) {
            if (getActivity()!=null){
                if (isLoading) {
                    ((BaseActivity) getActivity()).showLoadingView();
                }else {
                    ((BaseActivity) getActivity()).hideLoadingView();
                }
            }
        }
    }

    @Override
    public void displayMessage(String message) {
        if (!isAdded()){
            return;
        }
        Snackbar.make(view,message, Snackbar.LENGTH_LONG).show();
    }

    @Override
    public void updateFooter(PendingAssistanceAdapter.FooterType type) {
        if (!isAdded()){
            return;
        }

        mPendingAssistanceAdapter.updateFooter(type);
    }

    @Override
    public void removeFooter() {
        if (!isAdded()){
            return;
        }
        mPendingAssistanceAdapter.removeFooter();
    }

    @Override
    public void addFooter() {
        if (!isAdded()){
            return;
        }
        mPendingAssistanceAdapter.addFooter();
    }

    @Override
    public void resetList() {
        if (!isAdded()){
            return;
        }
        if (mPendingAssistanceAdapter != null) {
            mPendingAssistanceAdapter.clearAll();
        }
    }

    @Override
    public void displayCosts(@NonNull Bundle data) {
        if (isAdded()){
            if (getActivity()!=null) {
                ((DrawerActivity) getActivity()).displayCraneCost(data);
            }
        }
    }

    @Override
    public void refreshState() {
        if (isAdded()){
            if (getActivity()!=null) {
                ((DrawerActivity) getActivity()).updateAssistanceState();
            }
        }
    }

    @Override
    public boolean validateEmptyState() {
        if (!isAdded()){
            return false;
        }
        if (mPendingAssistanceAdapter.isEmpty()){
            ((ViewSwitcher)view.findViewById(R.id.views)).setDisplayedChild(1);
            displayMessage(getString(R.string.sin_asistencias));
        }else{
            ((ViewSwitcher)view.findViewById(R.id.views)).setDisplayedChild(0);
        }

        return !mPendingAssistanceAdapter.isEmpty();
    }

    @Override
    public void displayInactiveState(boolean display) {
        if (!isAdded()){
            return;
        }
        if (display){
            (view.findViewById(R.id.inactive)).setVisibility(View.VISIBLE);
            (view.findViewById(R.id.views)).setVisibility(View.GONE);
        }else{
            (view.findViewById(R.id.inactive)).setVisibility(View.GONE);
            (view.findViewById(R.id.views)).setVisibility(View.VISIBLE);

            validateEmptyState();
        }
    }

    @Override
    public void checkActive(boolean b) {
        if (isAdded()) {
            activeSwitchCompat.setChecked(b);
        }
    }

    @Override
    public void displayInactivityOptions(CharSequence[] justifications, DialogInterface.OnClickListener singleChoiceListener, DialogInterface.OnClickListener onPositiveClicked) {
        if (!isAdded()){
            return;
        }
        if (getContext() == null){
            return;
        }

        new AlertDialog.Builder(getContext())
                .setTitle(R.string.titulo_dialogo_inactividad)
                .setSingleChoiceItems(justifications,0, singleChoiceListener)
                .setPositiveButton(R.string.aceptar, onPositiveClicked)
                .setNegativeButton(R.string.cancelar,null)
                .show();
    }

    @Override
    public void inactiveUpdate() {
        if (!isAdded() || getActivity() == null){
            return;
        }

        ((DrawerActivity)getActivity()).updateAssistanceState();
    }

    @Override
    public void setPresenter(PendingContract.Presenter presenter) {
        mPresenter = presenter;
    }
}
