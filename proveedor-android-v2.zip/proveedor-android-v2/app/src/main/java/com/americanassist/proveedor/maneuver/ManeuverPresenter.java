package com.americanassist.proveedor.maneuver;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 *
 * <p>Presentador de las caracteristicas de Maniobras</p>
 */

public class ManeuverPresenter implements ManeuverContract.Presenter{

    private final ManeuverContract.View mManeuverContractView;

    public ManeuverPresenter(ManeuverContract.View view) {
        mManeuverContractView = checkNotNull(view);
        mManeuverContractView.setPresenter(this);
    }

    @Override
    public void start() {

    }

    @Override
    public void updateAssistanceState(String state) {

        mManeuverContractView.displayState(state);
    }

}
