package com.americanassist.proveedor.cranecost;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 *
 * <p>Presentador para el control de las caracteristicas de Costos grua</p>
 */

public class CraneCostPresenter implements CraneCostContract.Presenter {

    private final CraneCostContract.View mCraneCostContractView;

    public CraneCostPresenter(CraneCostContract.View view) {
        mCraneCostContractView = checkNotNull(view);
        mCraneCostContractView.setPresenter(this);
    }

    @Override
    public void start() {
    }

    @Override
    public void updateAssistanceState(String state) {
        mCraneCostContractView.displayState(state);

    }

    @Override
    public void initCosts(String distance, String costs, String assistanceId, String route1, String route2) {
        if (distance!=null && costs!=null){
            mCraneCostContractView.setCosts(distance,costs, assistanceId, route1, route2);
        }
    }
}
