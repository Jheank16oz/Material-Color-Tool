package com.americanassist.proveedor;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.RelativeLayout;
import android.widget.Toast;
import com.americanassist.proveedor.adapters.MoreInfoAdapter;
import com.americanassist.proveedor.commons.Controllers.BaseActivity;
import com.americanassist.proveedor.dialogs.ErrorDialog;
import com.americanassist.proveedor.managers.Server.ApiManager;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.AditionalInfo;
import com.americanassist.proveedor.model.Assistance;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.model.Service;
import com.americanassist.proveedor.utils.Functions;

import java.util.ArrayList;

/**
 * Vista de Detalle de asistencia
 */
public class MoreInfoActivity extends BaseActivity {

    public static final String CURRENT_ASSISTANCE = "assistance";
    private RelativeLayout rlBack;

    private Context mContext;
    protected LinearLayoutManager llm;
    private MoreInfoAdapter moreInfoAdapter;
    private String mAssistanceId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_more_info);

        RecyclerView recyclerView = findViewById(R.id.AMI_recyclerview_listitems);
        rlBack = findViewById(R.id.AMI_relativelayout_back);

        mContext = this;
        llm = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(llm);
        moreInfoAdapter = new MoreInfoAdapter(mContext);
        recyclerView.setAdapter(moreInfoAdapter);

        // Obtenemos el id de la asistencia dependiendo del tipo de Modelo
        // que se reciba bajo la llave CURRENT_ASSISTANCE
        if (getIntent().getParcelableExtra(CURRENT_ASSISTANCE) instanceof Assistance){
            mAssistanceId = ((Assistance)getIntent().getParcelableExtra(CURRENT_ASSISTANCE)).id;
        }else {
            // por defecto obtiene el id de la asistencia como
            // un Service.
            Service service = getIntent().getParcelableExtra(CURRENT_ASSISTANCE);
            if (service == null) {
                Toast.makeText(mContext, R.string.assistencia_no_disponible, Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
            mAssistanceId = service.id;
        }


        Provider mProvider = SharedPreferencesManager.getProvider(this);
        if (mProvider != null) {
            getAdditionalInfo(mProvider);
        }

        initListeners();
    }

    private void getAdditionalInfo(@NonNull Provider mProvider) {

        if (Functions.checkInternetConnection(mContext)) {
            return;
        }

        showLoadingView();
        new ApiManager(mContext).getAditionalInfoForAssistance(mAssistanceId, mProvider.country,mProvider.idProvider, mProvider.idContact, new ApiManagerHelper.ApiGetAditionalInfoCallback() {
            @Override
            public void onGetAditionalInfoSuccess(ArrayList<AditionalInfo> aditionalInfos) {
                hideLoadingView();
                moreInfoAdapter.addAditionalInfos(aditionalInfos);
            }

            @Override
            public void onGetAditionalInfoError(String error) {
                hideLoadingView();
                new ErrorDialog(mContext, error).show();
            }
        });
    }

    private void initListeners() {
        rlBack.setOnClickListener(v -> finish());
    }
}
