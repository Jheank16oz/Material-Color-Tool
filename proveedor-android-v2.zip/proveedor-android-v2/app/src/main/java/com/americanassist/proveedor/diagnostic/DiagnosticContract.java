package com.americanassist.proveedor.diagnostic;

import com.americanassist.proveedor.BasePresenter;
import com.americanassist.proveedor.BaseView;
import com.americanassist.proveedor.model.Question;

import java.util.ArrayList;

/**
 *
 * Contrato para las caracteristicas de la vista y presentador de
 * Diagnosticos.
 */

public interface DiagnosticContract {

    interface View extends BaseView<DiagnosticContract.Presenter> {
        void displayState(String state);
        void setQuestions(ArrayList<Question> questions);
        void displayQuestions();
    }

    interface Presenter extends BasePresenter {
        void updateAssistanceState(String state);
    }
}
