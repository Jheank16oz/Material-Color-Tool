package com.americanassist.proveedor.solution;

import com.americanassist.proveedor.BasePresenter;
import com.americanassist.proveedor.BaseView;

/**
 *
 * <p>Contrato de la vista y presentador de caracteristicas de termino
 * de una asistencia.</p>
 */

public interface SolutionContract {
    interface View extends BaseView<SolutionContract.Presenter> {

        void displayState(String state);

    }

    interface Presenter extends BasePresenter {
        void updateAssistanceState(String state);
    }
}
