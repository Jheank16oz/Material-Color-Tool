package com.americanassist.proveedor.register;

import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.americanassist.proveedor.R;
import com.americanassist.proveedor.commons.Controllers.BaseActivity;
import com.americanassist.proveedor.model.Country;
import com.americanassist.proveedor.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

/**
 * <p>Vista de Registro de usuario</p>
 */
public class RegisterActivity extends BaseActivity implements RegisterContract.View{

    @BindView(R.id.email)
    EditText mEmailEditText;
    @BindView(R.id.username)
    EditText mUsernameEditText;
    @BindView(R.id.phone)
    EditText mPhoneEditText;
    @BindView(R.id.service)
    EditText mServiceEditText;
    @BindView(R.id.city)
    EditText mCityEditText;
    @BindView(R.id.country)
    Spinner mCountrySpinner;
    @BindView(R.id.description)
    EditText mDescriptionEditText;
    @BindView(R.id.send)
    Button mSendButton;

    private List<Country> countries = new ArrayList<>();
    private RegisterContract.Presenter mPresenter;
    private ArrayAdapter mCountriesAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ButterKnife.bind(this);
        displayEmergencyButton = false;

        assert getSupportActionBar()!=null;
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle(getString(R.string.registro));
        mSendButton.setOnClickListener(v -> attemptSend());
        initializeCountrySpinner();
        setPresenter(new RegisterPresenter(this, this));
        mPresenter.requestCountries();
    }

    private void initializeCountrySpinner() {
        mCountriesAdapter = new ArrayAdapter<>(this,android.R.layout.simple_list_item_activated_1,countries);
        mCountrySpinner.setAdapter(mCountriesAdapter);
    }

    /**
     * Se encarga de validar los campos de registro y autorizar
     * el envio de registro.
     */
    private void attemptSend() {
        String username = mUsernameEditText.getText().toString();
        String email = mEmailEditText.getText().toString();
        String phone = mPhoneEditText.getText().toString();
        String service = mServiceEditText.getText().toString();
        String city = mCityEditText.getText().toString();
        String description = mDescriptionEditText.getText().toString();

        removeErrors();

        if (username.isEmpty()){
            mUsernameEditText.setError(getString(R.string.campo_necesario));
            mUsernameEditText.requestFocus();
            return;
        }else if(email.isEmpty()){
            mEmailEditText.setError(getString(R.string.campo_necesario));
            mEmailEditText.requestFocus();
            return;
        }else if (!Utils.isValidEmail(email)){
            mEmailEditText.setError(getString(R.string.correo_invalido));
            mEmailEditText.requestFocus();
            return;
        }else if(phone.isEmpty()){
            mPhoneEditText.setError(getString(R.string.campo_necesario));
            mPhoneEditText.requestFocus();
            return;
        } else if (service.isEmpty()) {
            mServiceEditText.setError(getString(R.string.campo_necesario));
            mServiceEditText.requestFocus();
            return;
        }else if (mCountrySpinner.getSelectedItemPosition() == 0){
            Snackbar.make(findViewById(android.R.id.content), R.string.seleccione_pais,Snackbar.LENGTH_SHORT).show();
            return;
        }else if (city.isEmpty()){
            mCityEditText.setError(getString(R.string.campo_necesario));
            mCityEditText.requestFocus();
            return;
        }else if (description.isEmpty()){
            mDescriptionEditText.setError(getString(R.string.campo_necesario));
            mDescriptionEditText.requestFocus();
            return;
        }


        String idPais = countries.get(mCountrySpinner.getSelectedItemPosition()).idPais;

        mPresenter.sendRequestRegisterProvider(username, email,phone, service,city, idPais,description);
    }

    /**
     * Elimina los mensajes de error de las entradas
     * de texto
     */
    private void removeErrors() {
        mUsernameEditText.setError(null);
        mEmailEditText.setError(null);
        mPhoneEditText.setError(null);
        mServiceEditText.setError(null);
        mCityEditText.setError(null);
        mDescriptionEditText.setError(null);
    }

    @Override
    public void setPresenter(RegisterContract.Presenter presenter) {
        mPresenter = presenter;
    }

    @Override
    public void displayCountries() {
        if (mCountriesAdapter!=null) {
            mCountriesAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void setCountries(List<Country> countries) {
        this.countries.clear();
        this.countries.add(new Country("",getString(R.string.seleccione_pais)));
        this.countries.addAll(countries);
    }

    @Override
    public void setLoading(boolean isLoading) {
        if (isLoading)
            showLoadingView();
        else
            hideLoadingView();
    }

    @Override
    public void displaySuccessFulRequest(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
