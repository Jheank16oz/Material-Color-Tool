package com.americanassist.proveedor.dialogs

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Window
import android.widget.Toast
import com.americanassist.proveedor.R
import com.americanassist.proveedor.managers.Server.ApiManager
import com.americanassist.proveedor.managers.Server.ApiManagerHelper
import com.americanassist.proveedor.managers.SharedPreferencesManager
import com.americanassist.proveedor.model.Provider
import kotlinx.android.synthetic.main.dialog_reprogram_type.*

/**
 * <p>Dialogo encargado de a gestion de reprogramacion de asistencias</p>
 *
 */
class ReprogramAssistanceDialog(context: Context, private val assistanceId:String,
                                private val onReprogramActionsListener:OnReprogramActionsListener) : Dialog(context) {

    val mProvider:Provider? = SharedPreferencesManager.getProvider(context)


    /**
     * Callback para la notificacion de
     * acciones de reprogramacion
     */
    interface OnReprogramActionsListener {
        fun onReprogram()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestWindowFeature(Window.FEATURE_NO_TITLE)
        window?.setBackgroundDrawable(
                android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        setContentView(R.layout.dialog_reprogram_type)


        accept.setOnClickListener{
            if (!reason.editText?.text.toString().isEmpty()) {
                programAssistance(reason.editText?.text.toString(), time.selectedItem.toString())
            }else{
                reason.error = context.getString(R.string.campo_necesario)
            }
        }

        cancel.setOnClickListener {
            dismiss()
        }
    }

    /**
     * Conexion  a la api de reprogramar asistencias y envio de
     * informacion.
     */
    private fun programAssistance(reason:String, minutes:String){
        if (mProvider == null){
            return
        }
        // mostramos la vista de progreso
        content.displayedChild = 1
        ApiManager(context).reprogramAssistance(assistanceId, mProvider.idProvider,
                mProvider.idContact, mProvider.country, reason, minutes,
                object : ApiManagerHelper.ApiReprogramAssistanceCallback {

            override fun onReprogramAssistanceSuccess() {
                dismiss()
                onReprogramActionsListener.onReprogram()
            }

            override fun onReprogramAssistanceError(error: String) {
                Toast.makeText(context,error,Toast.LENGTH_SHORT).show()
                dismiss()
            }
        })
    }

}
