package com.americanassist.proveedor.commons.Components;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import com.americanassist.proveedor.R;

public abstract class RecyclerLoadingFooterAdapter <VH extends RecyclerView.ViewHolder>
        extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int TYPE_FOOTER = -99;
    private FooterViewHolder footerViewHolder;

    private LayoutInflater mLayoutInflater;
    private Context mContext;

    public RecyclerLoadingFooterAdapter(Context context) {
        mContext = context;
        mLayoutInflater = LayoutInflater.from(context);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        if (viewType == TYPE_FOOTER) {
            View v = mLayoutInflater.inflate(R.layout.card_loading_footer, parent, false);
            footerViewHolder = new RecyclerLoadingFooterAdapter.FooterViewHolder(v);
            return footerViewHolder;
        } else {
            return onActualCreateViewHolder(parent, viewType);
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (holder.getItemViewType() != TYPE_FOOTER) {
            onActualBindViewHolder((VH) holder, position);
        }
    }

    @Override
    public int getItemCount() {
        return getActualItemCount() + 1;
    }

    public abstract int getActualItemCount();

    public abstract void onActualBindViewHolder(VH holder, int position);

    public abstract VH onActualCreateViewHolder(ViewGroup parent, int viewType);

    public abstract int getActualItemViewType(int position);

    @Override
    public int getItemViewType(int position) {
        if (getActualItemCount() == position) {
            return TYPE_FOOTER;
        } else {
            return getActualItemViewType(position);
        }
    }

    public void showLoading() {
        footerViewHolder.frameLoading.setVisibility(View.VISIBLE);
    }

    public void hideLoading() {
        footerViewHolder.frameLoading.setVisibility(View.GONE);
    }

    class FooterViewHolder extends RecyclerView.ViewHolder {

        private FrameLayout frameLoading;

        public FooterViewHolder(View itemView) {
            super(itemView);
            frameLoading = itemView.findViewById(R.id.CLF_framelayout_loading);
        }
    }
}
