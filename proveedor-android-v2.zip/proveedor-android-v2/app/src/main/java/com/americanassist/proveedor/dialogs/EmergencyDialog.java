package com.americanassist.proveedor.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Toast;

import com.americanassist.proveedor.R;
import com.americanassist.proveedor.connection.modelRepository.UserRepository;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.Provider;
import com.google.android.gms.maps.model.LatLng;

import static com.americanassist.proveedor.BaseApplication.getInstance;

/**
 * Dialogo de emergencia encargado del envio de notificaciones
 * de emergencia.
 */
public class EmergencyDialog extends Dialog {


    private final UserRepository mUserRepository;

    public EmergencyDialog(Context context) {
        super(context);
        mUserRepository = new UserRepository(context);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(
                new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        setContentView(R.layout.dialog_emergency);

        View accept = findViewById(R.id.accept);
        View cancel = findViewById(R.id.cancel);

        if (accept!=null)
            accept.setOnClickListener(view-> {
                dismiss();
                sendAlert();
            });

        if (cancel!=null)
            cancel.setOnClickListener(view -> dismiss());
    }

    /*
       Aqui nos encargamos de enviar al webservice evento_panico_proveedor
       la alerta del tecnico (usuario)
    */
    private void sendAlert(){
        final Provider mProvider = SharedPreferencesManager.getProvider(getContext());
        LatLng mCurrentLocation = getInstance().getCurrentLocation();

        if(mCurrentLocation == null){
            Toast.makeText(getContext(), R.string.mensaje_esperando_ubicacion_actual, Toast.LENGTH_SHORT).show();
            return;
        }
        if (mProvider != null) {
            mUserRepository.panicAlert( mProvider.idProvider,
                    mProvider.idContact,
                    mProvider.country,
                    mCurrentLocation.latitude,
                    mCurrentLocation.longitude,
                    detail -> Toast.makeText(getContext(), detail.message, Toast.LENGTH_SHORT).show());
        }
    }

}
