package com.americanassist.proveedor;

import android.content.Context;
import android.support.multidex.MultiDexApplication;
import android.util.Log;

import com.crashlytics.android.Crashlytics;
import com.google.android.gms.maps.model.LatLng;

import io.fabric.sdk.android.Fabric;

/**
 * Application base para la administracion de
 * propiedades a nivel global.
 * hereda de Multidex con el fin de evitar el desbordamiento
 * de tamanio de la app.
 */
public class BaseApplication extends MultiDexApplication {


    private LatLng currentLocation;
    private float bearing;

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        Fabric.with(this, new Crashlytics());
    }

    private static BaseApplication mInstance;

    public static BaseApplication getInstance() {
        return mInstance;
    }

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(newBase);
    }

    public LatLng getCurrentLocation() {
        return currentLocation;
    }

    public void setCurrentLocation(LatLng currentLocation) {
        this.currentLocation = currentLocation;
    }


    public float getBearing() {
        return bearing;
    }

    public void setBearing(float bearing) {
        this.bearing = bearing;
    }
}
