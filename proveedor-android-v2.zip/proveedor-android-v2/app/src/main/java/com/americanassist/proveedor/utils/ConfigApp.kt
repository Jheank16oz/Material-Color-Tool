package com.americanassist.proveedor.utils

import android.content.Context
import com.americanassist.proveedor.BuildConfig
import com.americanassist.proveedor.config.AppConfigPreference


/**
 *
 *  <p>ConfigApp</p>
 */
class ConfigApp{

    companion object {
        private const val PRODUCTION_ENABLED = "release"

        @JvmStatic
        fun getUrlServer(context: Context): String {
            return if (isDefault(context)) BuildConfig.URL_SERVER else BuildConfig.URL_SERVER_RELEASE
        }

        @JvmStatic
        fun getUrlSocketCoords(context: Context): String {
            return if (isDefault(context)) BuildConfig.REGEX_SOCKET_COORDS else BuildConfig.REGEX_SOCKET_COORDS_RELEASE

        }

        @JvmStatic
        fun getUrlSocketDistance(context: Context): String {
            return if (isDefault(context)) BuildConfig.REGEX_SOCKET_DISTANCE_MATRIX else BuildConfig.REGEX_SOCKET_DISTANCE_MATRIX_RELEASE
        }

        fun removeProvider(context: Context) {
            val sp = getSharedPreferences(context)
            sp.clear()
        }
        @JvmStatic
        fun setReleaseEnable(context: Context, boolean: Boolean){
            val sp = getSharedPreferences(context)
            sp.put(PRODUCTION_ENABLED, boolean)
        }

        private fun getSharedPreferences(context: Context): AppConfigPreference {
            return AppConfigPreference(context)
        }

        @JvmStatic
        fun isDefault(context: Context) : Boolean{
            val sp = getSharedPreferences(context)
            if (BuildConfig.FLAVOR != "appEditor"){
                return true
            }
            return !sp.getBoolean(PRODUCTION_ENABLED, BuildConfig.BUILD_TYPE != "debug")

        }
    }
}
