package com.americanassist.proveedor.rejectassistance

import android.content.Context
import com.americanassist.proveedor.managers.Server.ApiManager
import com.americanassist.proveedor.managers.Server.ApiManagerHelper
import com.americanassist.proveedor.managers.SharedPreferencesManager
import com.americanassist.proveedor.model.JustificationRejection
import com.americanassist.proveedor.model.Provider
import com.americanassist.proveedor.utils.Functions
import java.util.*

/**
 *
 * PResentador de las caracteristicas de rechazo de asistencia
 */
class RejectPresenter(var ctx: Context ,var  view: RejectContract.View):RejectContract.Presenter{

    private var mProvider:Provider?
    init {
        view.setPresenter(this)
        mProvider = SharedPreferencesManager.getProvider(ctx)

    }
    override fun start() {}

    /**
     * Se encarga de obtener la lista de justificaciones de rechazo por REST
     * y compartirselos a la vista.
     */
    override fun getOptions() {
        if (mProvider == null) return


        if (Functions.checkInternetConnection(ctx)) {
            return
        }

        view.setLoading(true)

        ApiManager(ctx).getJustificationRejectionService(
                 mProvider?.country, object:ApiManagerHelper.ApiGetJustificationRejectionServiceCallback{
           override fun onGetGetJustificationRejectionServiceError(error: String?) {
               view.setLoading(false)
               view.displayRefresh(true)

           }

           override fun onGetGetJustificationRejectionServiceSuccess(justificationRejections: ArrayList<JustificationRejection>?) {
               view.displayOptions(justificationRejections)
               view.setLoading(false)
               view.displayRefresh(false)

           }
       })
    }

    /**
     * Se encarga de enviar la cancelacion de asistencia
     */
    override fun cancelAssistance(assistanceId: String?, type:String, causeResponse:String) {

        if (Functions.checkInternetConnection(ctx)) {
            return
        }

        view.setLoading(true)

        if (type == RejectAssistanceActivity.REQUEST_ASSISTANCE) {
            ApiManager(ctx).rejectAssistance(
                    assistanceId,
                    mProvider?.idProvider,
                    mProvider?.idContact,
                    mProvider?.country,
                    causeResponse, object : ApiManagerHelper.ApiRejectAssistanceCallback {

                override fun onRejectAssistanceSuccess() {
                    view.setLoading(false)
                    view.sendResult()
                }


                override fun onRejectAssistanceError(error: String) {
                    view.setLoading(false)
                    view.displayMessage(error)
                }
            })
        }else if (type == RejectAssistanceActivity.PROCESS_ASSISTANCE){

            ApiManager(ctx).cancelAssistance(assistanceId,
                    mProvider?.idProvider,
                    mProvider?.idContact,
                    mProvider?.country,
                    causeResponse, object : ApiManagerHelper.ApiCancelAssistanceCallback {
                override fun onCancelAssistanceSuccess() {
                    view.setLoading(false)
                    view.sendResult()
                }

                override fun onCancelAssistanceError(error: String) {
                    view.setLoading(false)
                    view.displayMessage(error)
                }
            })


        }
    }

}