package com.americanassist.proveedor.adapters;

import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.americanassist.proveedor.R;
import com.americanassist.proveedor.model.Question;
import com.americanassist.proveedor.utils.ConfigUtils;
import com.bumptech.glide.Glide;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

/**
 * <p>Adaptador encargado de gestionar las listas de preguntas
 * dinamicas.
 * Soporta  TYPE_TEXT, TYPE_DATE, TYPE_DIRECTION, TYPE_IMAGE y TYPE_LIST</p>
 *
 */
public class QuestionsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder>{

    private static final int TYPE_TEXT = 1;
    private static final int TYPE_DIRECTION = 2;
    private static final int TYPE_IMAGE = 3;
    private static final int TYPE_DATE = 4;
    private static final int TYPE_LIST = 5;

    private LayoutInflater mLayoutInflater;
    private Context mContext;
    public ArrayList<Question> data = new ArrayList<>();
    private QuestionsAdapterCallback questionsAdapterCallback;

    public interface QuestionsAdapterCallback {
        void onImageClicked(int position);
        void onDateClicked(int position);
        void onDirectionClicked(int position);
    }

    public QuestionsAdapter(Context context, QuestionsAdapterCallback questionsAdapterCallback) {
        mContext = context;
        this.questionsAdapterCallback = questionsAdapterCallback;
        mLayoutInflater = LayoutInflater.from(context);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case TYPE_TEXT:
                View v = mLayoutInflater.inflate(R.layout.card_question_text, parent, false);
                return new QuestionsAdapter.TextVH(v);
            case TYPE_DATE:
                View v2 = mLayoutInflater.inflate(R.layout.card_question_date, parent, false);
                return new QuestionsAdapter.DateVH(v2);
            case TYPE_DIRECTION:
                View v3 = mLayoutInflater.inflate(R.layout.card_question_direction, parent, false);
                return new QuestionsAdapter.DirectionVH(v3);
            case TYPE_IMAGE:
                View v4 = mLayoutInflater.inflate(R.layout.card_question_image, parent, false);
                return new QuestionsAdapter.ImageVH(v4);
            case TYPE_LIST:
                View v5 = mLayoutInflater.inflate(R.layout.card_question_list, parent, false);
                return new QuestionsAdapter.ListVH(v5);
            default:
                return null;
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        Question question = data.get(position);
        switch (holder.getItemViewType()) {
            case TYPE_TEXT:
                ((TextVH) holder).txtQuestion.setText(question.question);
                if (question.text != null) {
                    ((TextVH) holder).editQuestion.setText(question.text);
                }
                else{
                    ((TextVH) holder).editQuestion.setText("");
                    ((TextVH) holder).editQuestion.setHint(question.placeholder);
                }
                ((TextVH) holder).editQuestion.addTextChangedListener(new TextWatcher() {

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {
                        data.get(position).text = s.toString();
                    }

                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count,
                                                  int after) {
                        // TODO Auto-generated method stub
                    }

                    @Override
                    public void afterTextChanged(Editable s) {
                        // TODO Auto-generated method stub

                    }
                });
                break;
            case TYPE_DIRECTION:
                ((DirectionVH) holder).mTittleTextView.setText(question.question);
                ((DirectionVH) holder).mSubtitleTextView.setText("");
                if (question.mPlace!=null){

                    ((DirectionVH) holder).mSubtitleTextView.setText(question.mPlace.getName());
                    double latitude = question.mPlace.getLatLng().latitude;
                    double longitude = question.mPlace.getLatLng().longitude;
                    ((DirectionVH) holder).mSubtitleTextView.setVisibility(View.VISIBLE);
                    Glide.with(mContext).load(getUrl(latitude,longitude)).into(((DirectionVH) holder).mMapImageView);
                    ((DirectionVH) holder).mMapImageView.setVisibility(View.VISIBLE);
                }
                ((DirectionVH) holder).mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        questionsAdapterCallback.onDirectionClicked(position);
                    }
                });
                break;

            case TYPE_DATE:
                ((DateVH) holder).txtQuestion.setText(question.question);
                ((DateVH) holder).editDate.setOnClickListener(v -> questionsAdapterCallback.onDateClicked(position));
                if (question.calendar != null) {
                    SimpleDateFormat dateFormatHour = new SimpleDateFormat("d 'de' MMMM HH:mm");
                    ((DateVH) holder).editDate.setText(dateFormatHour.format(question.calendar.getTime()));
                }
                else{
                    ((DateVH) holder).editDate.setHint(question.placeholder);
                }
                break;

            case TYPE_IMAGE:
                ((ImageVH) holder).txtQuestion.setText(question.question);
                ((ImageVH) holder).imgAddPicture.setOnClickListener(v -> questionsAdapterCallback.onImageClicked(position));
                ((ImageVH) holder).imgPicture.setOnClickListener(v -> questionsAdapterCallback.onImageClicked(position));
                if (question.filePicture != null){
                    (((ImageVH) holder).imgPicture).setVisibility(View.VISIBLE);
                    (((ImageVH) holder).imgAddPicture).setVisibility(View.GONE);

                    Glide.with(mContext).load(question.filePicture).into(((ImageVH) holder).imgPicture);
                }
                else{
                    (((ImageVH) holder).imgPicture).setVisibility(View.GONE);
                    (((ImageVH) holder).imgAddPicture).setVisibility(View.VISIBLE);

                }
                break;

            case TYPE_LIST:
                ((ListVH) holder).txtQuestion.setText(question.question);
                LinearLayoutManager llm = new LinearLayoutManager(mContext);
                ((ListVH) holder).recyclerOptions.setLayoutManager(llm);
                QuestionOptionsAdapter questionOptionsAdapter = new QuestionOptionsAdapter(mContext);
                ((ListVH) holder).recyclerOptions.setAdapter(questionOptionsAdapter);
                questionOptionsAdapter.replaceAll(question.questionOptions);
                break;

            default:
                break;
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    @Override
    public int getItemViewType(int position) {
        Question question = data.get(position);
        if (question.type.equals(Question.TYPE_TEXT)){
            return TYPE_TEXT;
        }
        else if (question.type.equals(Question.TYPE_DIRECTION)){
            return TYPE_DIRECTION;
        }
        else if (question.type.equals(Question.TYPE_IMAGE)) {
            return TYPE_IMAGE;
        }
        else if (question.type.equals(Question.TYPE_DATETIME)){
            return TYPE_DATE;
        }
        else if (question.type.equals(Question.TYPE_LIST)){
            return TYPE_LIST;
        }
        else{
            return 0;
        }
    }



    public void replaceAll(ArrayList<Question> questions) {
        data.clear();
        this.data.addAll(questions);
        notifyDataSetChanged();
    }


    class TextVH extends RecyclerView.ViewHolder {
        TextView txtQuestion;
        EditText editQuestion;

        public TextVH(View itemView) {
            super(itemView);
            txtQuestion = itemView.findViewById(R.id.CQT_textview_question);
            editQuestion = itemView.findViewById(R.id.CQT_edittext_question);
        }
    }

    class DirectionVH extends RecyclerView.ViewHolder{
        TextView mTittleTextView;
        TextView mSubtitleTextView;
        ImageView mMapImageView;
        View mView;
        public DirectionVH(View itemView){
            super(itemView);
            mView = itemView;
            mTittleTextView = itemView.findViewById(R.id.tittle);
            mSubtitleTextView = itemView.findViewById(R.id.subtitle);
            mMapImageView = itemView.findViewById(R.id.map);
        }
    }

    class DateVH extends RecyclerView.ViewHolder {
        TextView txtQuestion;
        EditText editDate;

        public DateVH(View itemView) {
            super(itemView);
            txtQuestion = itemView.findViewById(R.id.CQD_textview_question);
            editDate = itemView.findViewById(R.id.CQD_edittext_date);
        }
    }

    class ImageVH extends RecyclerView.ViewHolder {
        TextView txtQuestion;
        ImageView imgPicture;
        ImageView imgAddPicture;

        public ImageVH(View itemView) {
            super(itemView);
            txtQuestion = itemView.findViewById(R.id.CQI_textview_question);
            imgPicture = itemView.findViewById(R.id.CQI_imageview_picture);
            imgAddPicture = itemView.findViewById(R.id.camera);
        }
    }

    class ListVH extends RecyclerView.ViewHolder {
        TextView txtQuestion;
        RecyclerView recyclerOptions;

        ListVH(View itemView) {
            super(itemView);
            txtQuestion = itemView.findViewById(R.id.CQL_textview_question);
            recyclerOptions = itemView.findViewById(R.id.CQL_recyclerview_listoptions);
        }
    }

    private String getUrl(double latitude, double longitude) {

        return "https://maps.googleapis.com/maps/api/staticmap?center="+latitude+","+longitude+
                "&zoom=20&size=600x300&markers=color:red%7Clabel:D%7C"+latitude+","+longitude+"&key="+ ConfigUtils.getActiveDistanceMatrixApiKey(mContext);
    }
}

