package com.americanassist.proveedor;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.americanassist.proveedor.commons.Controllers.BaseActivity;
import com.americanassist.proveedor.cost.CostFragment;
import com.americanassist.proveedor.cost.CostPresenter;
import com.americanassist.proveedor.cranecost.CraneCostFragment;
import com.americanassist.proveedor.cranecost.CraneCostPresenter;
import com.americanassist.proveedor.diagnostic.DiagnosticFragment;
import com.americanassist.proveedor.diagnostic.DiagnosticPresenter;
import com.americanassist.proveedor.dialogs.ErrorDialog;
import com.americanassist.proveedor.dialogs.TwoOptionsDialog;
import com.americanassist.proveedor.dialogs.WaitingDialog;
import com.americanassist.proveedor.managers.Server.ApiManager;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.maneuver.ManeuverFragment;
import com.americanassist.proveedor.maneuver.ManeuverPresenter;
import com.americanassist.proveedor.map.MapAssistanceFragment;
import com.americanassist.proveedor.map.MapAssistancePresenter;
import com.americanassist.proveedor.model.Assistance;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.model.Question;
import com.americanassist.proveedor.pending.PendingPresenter;
import com.americanassist.proveedor.pending.PendingRequestFragment;
import com.americanassist.proveedor.servicehistory.ServiceHistoryActivity;
import com.americanassist.proveedor.services.ActiveRequestService;
import com.americanassist.proveedor.services.SocketEvents;
import com.americanassist.proveedor.solution.SolutionFragment;
import com.americanassist.proveedor.solution.SolutionPresenter;
import com.americanassist.proveedor.utils.Functions;
import com.daimajia.androidanimations.library.Techniques;
import com.daimajia.androidanimations.library.YoYo;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

import static com.americanassist.proveedor.BaseApplication.getInstance;

/**
 * Actividad principal de la app aqui se administra las vistas
 * del estado de la asistencia, comunica a Diagnostico, Costos, Maniobras y
 * Termino; Tambien administra el envio de Notificaciones recibidas
 * de ActiveRequestService y asi notificar a los presentadores
 * correspondientes.
 */
public class DrawerActivity extends BaseActivity implements LateralMenuFragment.LateralMenuFragmentCallback{

    public static final int DIAGNOSTIC_FRAGMENT = 1;
    public static final int MAP_FRAGMENT = 2;
    public static final int COSTS_FRAGMENT = 3;
    public static final int CRANE_COSTS_FRAGMENT = 4;
    public static final int MANEUVER_FRAGMENT = 5;
    public static final int SOLUTION_FRAGMENT = 6;
    public static final int PENDING_FRAGMENT = 7;

    public static final String FROM_NOTIFICATION_REQUEST = "fromNotificationRequest";
    public static final String USER_INACTIVE = "inactivo";


    public DrawerLayout drawerLayout;

    public LateralMenuFragment lateralMenuFragment;
    private Context mContext;

    /** presentadores de cada uno de los fragmentos */
    private MapAssistancePresenter mMapPresenter;
    private DiagnosticPresenter mDiagnosticPresenter;
    private CostPresenter mCostPresenter;
    private CraneCostPresenter mCraneCostPresenter;
    private ManeuverPresenter mManeuverPresenter;
    private SolutionPresenter mSolutionPresenter;
    private PendingPresenter mPendingPresenter;

    /** fragments posibles para la vista */
    private MapAssistanceFragment mMapAssistanceFragment;
    private DiagnosticFragment mDiagnosticFragment ;
    private CostFragment mCostFragment;
    private CraneCostFragment mCraneCostFragment;
    private ManeuverFragment mManeuverFragment;
    private SolutionFragment mSolutionFragment;
    private PendingRequestFragment mPendingRequestFragment;

    private FragmentManager mFragmentManager;
    private String mCurrentFragmentClassName;
    private WaitingDialog mWaitingDialog;

    /** Messenger para la comunicacion del servicio. */
    Messenger mService = null;
    /** Indicador que guarda si hemos llamado bind en el servicio. */
    boolean mIsBound;
    /** TextView par mostrar el ejemplo. */
    TextView mCallbackText;

    private Assistance mAssistance;

    /**
     *  Lista de preguntas dedicada para almacenar las preguntas
     *  de diagnostico que se consulten.
     */
    private ArrayList<Question> diagnosticQuestionsList;
    private Toolbar mToolbar;
    private TextView mInternetTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        displayEmergencyButton = false;
        drawerLayout = findViewById(R.id.AM_drawer);
        mToolbar = findViewById(R.id.toolbar);
        mInternetTextView = findViewById(R.id.connection);
        setSupportActionBar(mToolbar);


        mCallbackText = findViewById(R.id.callback);

        mContext = this;

        // Menu lateral
        lateralMenuFragment = new LateralMenuFragment();
        lateralMenuFragment.callback = this;

        android.app.FragmentTransaction transaction = getFragmentManager().beginTransaction();
        transaction.add(R.id.AM_framelayout_lateralmenu, lateralMenuFragment);
        transaction.commit();

        mWaitingDialog = new WaitingDialog(mContext, "", true,
                v -> sendAlert(),
                v -> updateAssistanceState());

        mWaitingDialog.setCancelable(false);

        mMapAssistanceFragment = new MapAssistanceFragment();
        mDiagnosticFragment = new DiagnosticFragment();
        mCostFragment = new CostFragment();
        mCraneCostFragment = new CraneCostFragment();
        mManeuverFragment = new ManeuverFragment();
        mSolutionFragment = new SolutionFragment();
        mPendingRequestFragment = new PendingRequestFragment();

        mFragmentManager = getSupportFragmentManager();
        // creamos los presentadores
        mMapPresenter = new MapAssistancePresenter(mMapAssistanceFragment);
        mDiagnosticPresenter = new DiagnosticPresenter(mDiagnosticFragment);
        mCostPresenter = new CostPresenter(mCostFragment);
        mCraneCostPresenter = new CraneCostPresenter(mCraneCostFragment);
        mManeuverPresenter = new ManeuverPresenter(mManeuverFragment);
        mSolutionPresenter = new SolutionPresenter(mSolutionFragment);
        mPendingPresenter = new PendingPresenter(mPendingRequestFragment,this);


        updateAssistanceState();
    }

    /**
     * Valida el resultado de una actividad en caso
     * de que se necesite mostrar los costos de Grua
     * @param data resultado de Activity
     */
    public void displayCraneCost(Bundle data) {
        setFragment(CRANE_COSTS_FRAGMENT);
        mCraneCostFragment.setCosts(data.getString(CraneCostFragment.DISTANCE),
                data.getString(CraneCostFragment.COSTS),
                data.getString(CraneCostFragment.ASSISTANCE_ID),
                data.getString(CraneCostFragment.ASSISTANCE_ROUTE1),
                data.getString(CraneCostFragment.ASSISTANCE_ROUTE2));

    }

    public void validateOpenPendingRequest() {
        Intent mIntent = getIntent();
        if (mIntent != null && mIntent.hasExtra(FROM_NOTIFICATION_REQUEST)) {
            boolean fromNotificationRequest = getIntent().getBooleanExtra(FROM_NOTIFICATION_REQUEST, false);
            mIntent.removeExtra(FROM_NOTIFICATION_REQUEST);
            if (fromNotificationRequest) {
                if (mAssistance == null) {
                    mPendingPresenter.resetInformation();
                    Intent i = new Intent(DrawerActivity.this, DrawerActivity.class);
                    startActivity(i);
                }
            }
        }
    }

    /**
     * Valida las notificaciones generales que afectan a la vista.
     * @param state estado o tipo de notificacion.
     */
    private void validateReceiverState(String state) {

        if (state.equalsIgnoreCase(SocketEvents.NotificationListener.NOTIFICATION_TYPE_EXPIRED_SESSION)) {
            processLogout();
        }else if (state.equalsIgnoreCase(SocketEvents.NotificationListener.NOTIFICATION_TYPE_UPDATE)){
            updateAssistanceState();
        }
    }

    @Override
    public void onViewCreated() {
        if (mAssistance != null) {
            if (!mAssistance.estado.equalsIgnoreCase(USER_INACTIVE)) {
                lateralMenuFragment.blockPendingRequestsAndCloseSession();
            } else {
                lateralMenuFragment.unblockPendingRequestsAndCloseSession();
            }
        }else {
            lateralMenuFragment.unblockPendingRequestsAndCloseSession();
        }
    }

    @Override
    public void onBackPressed() {
        // se valida si se esta en una vista diferente al mapa y costo grua
        // para que al presionar atras retorne al mapa nuevamente
        if (!mCurrentFragmentClassName.equalsIgnoreCase(mMapAssistanceFragment.getClass().getName())
                && !mCurrentFragmentClassName.equalsIgnoreCase(mPendingRequestFragment.getClass().getName())) {
            setFragment(MAP_FRAGMENT);
        } else{
            Intent startMain = new Intent(Intent.ACTION_MAIN);
            startMain.addCategory(Intent.CATEGORY_HOME);
            startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(startMain);
        }
    }


    @Override
    public void onPendingRequestsClicked() {
        showFragment(mMapAssistanceFragment);
        toggleMenu();
        setFragment(PENDING_FRAGMENT);
    }



    @Override
    public void onServiceHistoryClicked()
    {
        showFragment(mMapAssistanceFragment);

        toggleMenu();
        Intent i = new Intent(DrawerActivity.this, ServiceHistoryActivity.class);
        startActivity(i);
    }

    @Override
    public void onContactClicked() {
        toggleMenu();
        makeCall();
    }


    @Override
    public void onLogoutClicked() {
        toggleMenu();
        new TwoOptionsDialog(mContext,getString(R.string.cerrar_sesion_pregunta) , getString(R.string.contenido_cerrar_sesion), getString(R.string.cancelar), getString(R.string.aceptar), new TwoOptionsDialog.TwoOptionsDialogListener() {
            @Override
            public void onCancelClicked() {
            }

            @Override
            public void onAcceptClicked() {
                processLogout();

            }
        }).show();
    }

    public void processLogout(){
        Provider mProvider = SharedPreferencesManager.getProvider(getBaseContext());
        if (mProvider != null) {
            logout(mProvider);
        }
    }

    /**
     * Se encarga de ejecutar el deslogueo REST y de detener
     * los servicios en proceso.
     * @param mProvider configuraciones obtenidas en login
     */
    private void logout(@NonNull Provider mProvider) {
        if (Functions.checkInternetConnection(getBaseContext())) {
            return;
        }

        showLoadingView();
        new ApiManager(mContext).logout(mProvider.token, mProvider.country, new ApiManagerHelper.ApiLogoutCallback() {
            @Override
            public void onLogoutSuccess() {
                hideLoadingView();
                //Eliminamos el proveedor
                SharedPreferencesManager.removeProvider(getBaseContext());
                if (mAssistance != null) {
                    mAssistance = null;
                }
                //Paramos el servicio de localizacion
                //stopService(new Intent(DrawerActivity.this, ActiveRequestService.class));
                //Volvemos a login
                doUnbindService();
                Intent i = new Intent(DrawerActivity.this, LoginActivity.class);
                startActivity(i);
                finish();
            }

            @Override
            public void onLogoutError(String error) {
                hideLoadingView();
                new ErrorDialog(mContext, error).show();
            }
        });
    }

    /**
     * Accion de llamada
     */
    private void makeCall() {
        if (Functions.checkInternetConnection(getBaseContext())) {
            return;
        }

        showLoadingView();
        Provider mProvider = SharedPreferencesManager.getProvider(this);
        if (mProvider == null){
            return;
        }
        new ApiManager(mContext).getTelephone(mProvider.country, new ApiManagerHelper.ApiGetTelephoneCallback() {
            @Override
            public void onGetTelephoneSuccess(final String telephone) {
                hideLoadingView();
                new AlertDialog.Builder(mContext)
                        .setMessage("Llamar al numero " + telephone)
                        .setPositiveButton("Aceptar", (dialogInterface, i) -> askForPermission(Manifest.permission.CALL_PHONE, null, new PermissionListener() {
                            @Override
                            public void onPermissionGranted() {
                                try {
                                    Intent intent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + telephone));
                                    startActivity(intent);
                                } catch (SecurityException e) {
                                    e.printStackTrace();
                                    Snackbar.make(((ViewGroup) findViewById(android.R.id.content)).getChildAt(0), "Necesitas dar permiso para poder realizar una llamada", Snackbar.LENGTH_LONG).show();
                                }
                            }

                            @Override
                            public void onPermissionDenied() {
                                Snackbar.make(findViewById(android.R.id.content), R.string.permiso_de_llamada_necesario,Snackbar.LENGTH_LONG).show();
                            }
                        }))
                        .setNegativeButton("Rechazar", (dialogInterface, i) -> dialogInterface.dismiss())
                        .create()
                        .show();
            }

            @Override
            public void onGetTelephoneError(String error) {
                hideLoadingView();
                new ErrorDialog(mContext, error).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_drawer, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                toggleMenu();
                break;
            case R.id.emergency:
                if (isUserFree()) {
                    displayEmergencyDialog();
                }else {
                    displayInactiveMessage();
                }
                break;
            case R.id.call:
                makeCall();
                break;
            case R.id.refresh:
                updateAssistanceState();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void displayInactiveMessage() {
        Snackbar.make(findViewById(android.R.id.content),
                R.string.mensaje_estado_inactivo, Snackbar.LENGTH_LONG).show();
    }

    public void toggleMenu() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(Gravity.START);
        } else {
            drawerLayout.openDrawer(Gravity.START);
            //validar si el fragment ha sido agregado isAdded()
            mMapPresenter.toggleMenuPressed();
        }
    }

    private void setTitleBar(String titleBar) {
        mToolbar.setTitle(titleBar);
    }

    public void setFragment(int fragment) {
        switch (fragment){
            case DIAGNOSTIC_FRAGMENT:
                setTitleBar(getString(R.string.diagnostico));
                mDiagnosticFragment.setQuestions(getDiagnosticQuestionsList());
                showFragment(mDiagnosticFragment);
                break;
            case MAP_FRAGMENT:
                setTitleBar(getString(R.string.en_ruta));
                showFragment(mMapAssistanceFragment);
                break;
            case COSTS_FRAGMENT:
                setTitleBar(getString(R.string.costos));
                showFragment(mCostFragment);
                break;
            case CRANE_COSTS_FRAGMENT:
                setTitleBar(getString(R.string.costos_grua));
                showFragment(mCraneCostFragment);
                break;
            case MANEUVER_FRAGMENT:
                setTitleBar(getString(R.string.maniobras));
                showFragment(mManeuverFragment);
                break;
            case SOLUTION_FRAGMENT:
                setTitleBar(getString(R.string.solucion));
                showFragment(mSolutionFragment);
                break;
            case PENDING_FRAGMENT:
                setTitleBar(getString(R.string.solicitudes_titulo));
                showFragment(mPendingRequestFragment);
                break;

        }
    }

    /**
     * Muestra el {@link WaitingDialog} este dialogo es de espera.
     * Puede que no se muestre si el dialogo no ha sido creado
     * o no lleque una descripcion {@param description}.
     */
    public void displayWaiting(@Nullable final String description, final boolean visible){

        if (mWaitingDialog == null)
            return;

        if (description == null && visible)
            return;

        runOnUiThread(() -> {
            if (visible){
                mWaitingDialog.setDescription(description);
                mWaitingDialog.show();

            }else if (mWaitingDialog.isShowing()){
                mWaitingDialog.dismiss();
            }
        });
    }

    public void showFragment(Fragment fragment) {
        mCurrentFragmentClassName = fragment.getClass().getName();
        mFragmentManager.beginTransaction().replace(R.id.content_fragment, fragment, fragment.getClass().getName())
                .commitAllowingStateLoss();
    }

    /**
     * Handler para recibir mensages del servicio {@link ActiveRequestService}.
     */
    @SuppressLint("HandlerLeak")
    class IncomingHandler extends Handler {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case ActiveRequestService.MSG_SET_VALUE:

                    Bundle mUpdateLocation = (Bundle) msg.obj;
                    mCallbackText.setText(String.format("Received from service:\n %s", mUpdateLocation.getString("locations")));
                    // se envian las actualizaciones de ubicacion al presentador del
                    // mapa, unicamente a este presentador ya que solo este hace uso de
                    // de las actualizaciones de distance,tiempo y ubicacion(LatLng)
                    mMapPresenter.updateLocationState(mUpdateLocation);


                    // Actualizamos las coordenadas de BaseApplication mediante las ubicaciones
                    // que se reciben desde el servicio, Se hace desde esta parte debido a que
                    // el servicio es remoto y maneja un Contexto diferente por lo cual no actualiza
                    // las variables de este contexto.
                    getInstance().setCurrentLocation(new LatLng(mUpdateLocation.getDouble(ActiveRequestService.LOCATION_LATITUDE,0),
                            mUpdateLocation.getDouble(ActiveRequestService.LOCATION_LONGITUDE,0)));
                    // inicializamos las solicitudes pendientes
                    mPendingPresenter.start();

                    break;
                case ActiveRequestService.MSG_SET_NOTIFICATION:
                    Bundle mBundle = (Bundle) msg.obj;
                    String notificationType = mBundle.getString(ActiveRequestService.NEW_NOTIFICATION);
                    String message = mBundle.getString(ActiveRequestService.NOTIFICATION_MESSAGE);

                    if (notificationType == null){
                        return;
                    }
                    // le enviamos a todos los presentadores de
                    // fragments los cambios recibidos de las Notificaciones FCM.
                    mMapPresenter.updateAssistanceState(notificationType, message);
                    mDiagnosticPresenter.updateAssistanceState(notificationType);
                    mCostPresenter.updateAssistanceState(notificationType);
                    mManeuverPresenter.updateAssistanceState(notificationType);
                    mSolutionPresenter.updateAssistanceState(notificationType);
                    mCraneCostPresenter.updateAssistanceState(notificationType);

                    validateReceiverState(notificationType);
                    break;

                case ActiveRequestService.MSG_ADD_ASSISTANCE:

                    mPendingPresenter.resetInformation();
                    Intent i = new Intent(DrawerActivity.this, DrawerActivity.class);
                    //i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    //i.putExtra(PLAY_NOTIFICATION,true);
                    startActivity(i);
                    playNotification();
                    break;
                case ActiveRequestService.MSG_CANCEL_ASSISTANCE:
                    // validamos si la actividad esta en primer plano para
                    // enviar una peticion de actualizacion por cancelado
                    mPendingPresenter.resetInformation();

                    break;

                case ActiveRequestService.MSG_UPDATE_INFO_ASSISTANCE:
                    Bundle mBundleTaD = (Bundle) msg.obj;
                    String time = mBundleTaD.getString(ActiveRequestService.NEW_TIME);
                    String distance = mBundleTaD.getString(ActiveRequestService.NEW_DISTANCE);
                    String direction = mBundleTaD.getString(ActiveRequestService.NEW_DIRECTION);

                    if (time == null || distance == null || direction == null){
                        return;
                    }
                    // le enviamos al presentador del mapa la actualizacion de tiempo y distancia
                    mMapPresenter.updateInfoAssistance(time, distance, direction);
                    break;

                default:
                    super.handleMessage(msg);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopNotification();
    }

    private void playNotification() {
        notification();
    }

    /**
     * Objetivo para que los clientes envien mensajes a IncomingHandler.
     */
    final Messenger mMessenger = new Messenger(new IncomingHandler());

    /**
     * Clase para interactuar con la interfaz principal del servicio..
     */
    private ServiceConnection mConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className,
                                       IBinder service) {
            // Esto es llamado cuando la conexion  con e servicio se
            // es establecida, dando un objeto del servicio que utilizamos para
            // interactuar con el servicio. Nos estamos comunicando con nuestro
            // servicio a traves de una interface IDL
            mService = new Messenger(service);
            mCallbackText.setText(getString(R.string.adjunto));

            // Queremos monitorear el servicio por el tiempo que estemos
            // conectado a el.
            try {
                Log.e("onservice", "connection");
                Message msg = Message.obtain(null,
                        ActiveRequestService.MSG_REGISTER_CLIENT);
                msg.replyTo = mMessenger;
                mService.send(msg);

                Bundle mBundle = new Bundle();
                msg = Message.obtain(null,ActiveRequestService.MSG_SET_VALUE);
                msg.obj = mBundle;
                mService.send(msg);

            } catch (RemoteException e) {
                e.printStackTrace();
                // En este caso, el servicio se ha bloqueado antes de que pudieramos.
                // en el mpmento no es necesario un posible intento de
                // reconexion
            }
        }

        public void onServiceDisconnected(ComponentName className) {

            // Esto se llama cuando la conexion con el servicio ha sido
            // inesperadamente desconectada, es decir, su proceso se bloqueo.
            mService = null;
            mCallbackText.setText(getString(R.string.desconectado));
            if (SharedPreferencesManager.isProviderEnabled(getBaseContext())) {
                if (isUserFree()) {
                    startService(new Intent(DrawerActivity.this, ActiveRequestService.class));
                    doBindService();
                }
            }
        }
    };

    private boolean isUserFree() {
        return mAssistance == null || !mAssistance.estado.equalsIgnoreCase(USER_INACTIVE);
    }

    /**
     * Inicializa el servicio
     */
    void doBindService() {
        // Estableccemos una conexion con el servicio.
        bindService(new Intent(DrawerActivity.this,
                ActiveRequestService.class), mConnection, Context.BIND_AUTO_CREATE);
        mIsBound = true;
        mCallbackText.setText(getString(R.string.union));
    }

    void doUnbindService() {
        if (mIsBound) {
            // si recibimos el servicio,y este esta registrado,
            // es el momendo de anular el registro
            if (mService != null) {
                try {
                    Message msg = Message.obtain(null,
                            ActiveRequestService.MSG_UNREGISTER_CLIENT);
                    msg.replyTo = mMessenger;
                    mService.send(msg);
                } catch (RemoteException e) {
                    e.printStackTrace();
                    // No hay nada en especial que hacer si el
                    // servicio arroja una excepcion
                }
            }

            // desplegar nuestra desconexion.
            unbindService(mConnection);
            mIsBound = false;
            mCallbackText.setText(getString(R.string.desvinculacion));
        }
    }

    public Assistance getAssistance() {
        return mAssistance;
    }

    public void setAssistance(Assistance assistance) {
        mAssistance = assistance;
        // le informamos al servicio que  la asistencia
        // ha sido cambiada con el fin de que no envie informacion erronea.
        requestUpdateLocationsService();
    }

    public void updateAssistanceState(){
        if (Functions.checkInternetConnection(getBaseContext())) {
            return;
        }

        Provider mProvider = SharedPreferencesManager.getProvider(this);

        if (mProvider != null) {
            showLoadingView();
            new ApiManager(this).getProviderState(mProvider.idProvider, mProvider.idContact, mProvider.country, new ApiManagerHelper.ApiGetProviderStateCallback() {
                @Override
                public void onGetProviderStateSuccess(Assistance assistance) {
                    mAssistance = assistance;
                    validateFreeState(assistance);
                    updateServiceState();
                    mMapPresenter.updateAssistanceState(assistance);
                    mPendingPresenter.updateUserState(assistance);
                    hideLoadingView();
                    requestUpdateLocationsService();

                    // validamos si se necesita abrir el panel de notificaciones
                    validateOpenPendingRequest();
                }

                @Override
                public void onGetProviderStateError(String error, boolean isDesconected) {
                    //En caso de que llegue el estado del proveedor desconectado se enviara al login
                    if (isDesconected){
                        Toast.makeText(DrawerActivity.this, error, Toast.LENGTH_SHORT).show();
                        processLogout();
                    }

                    hideLoadingView();
                }
            });
        }
    }


    /**
     * Funcion encargada de validar si el proveedor se encuentra en estado
     * libre.
     */
    public void validateFreeState(Assistance assistance) {
        setFragment(assistance == null || assistance.estado.equalsIgnoreCase(USER_INACTIVE) ? PENDING_FRAGMENT : MAP_FRAGMENT);
    }

    /**
     * Solicitamos al servicio una actualizacion de ubicacion {@link ActiveRequestService},
     */
    private void requestUpdateLocationsService() {
        Message msg = Message.obtain(null,
                ActiveRequestService.MSG_UPDATE_LOCATION);

        msg.obj = null;
        try {
            mService.send(msg);
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {
            Log.e("Serivicio remoto", "desconectado.");
        }
    }

    /**
     * Enviamos la cancelacion de asisencia
     * al servicio para que envie una ultima actualizacion
     * de ubicacion al servidor, esto es necesario
     * ya que si no se envia, no recibiremos
     * notificaciones de asistencias nuevas por parte
     * del servidor.
     */
    public void cancelAssistance() {
        Message msg = Message.obtain(null, ActiveRequestService.MSG_NEED_CLEAN_ASSISTANCE);
        msg.obj = null;
        try {
            mService.send(msg);
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (NullPointerException e) {
            Log.e("Serivicio remoto", "desconectado.");
        }
    }

    public ArrayList<Question> getDiagnosticQuestionsList() {
        return diagnosticQuestionsList;
    }

    public void setDiagnosticQuestionsList(ArrayList<Question> diagnosticQuestionsList) {
        this.diagnosticQuestionsList = diagnosticQuestionsList;
    }

    /**
     * Permite ejecutar una consulta cuando la conexion es
     * retomada.
     */
    @Override
    public void onConnectionReset() {
        super.onConnectionReset();
        // se valida que la asistencia no se este cargando antes
        // de ejecutar el estado de el proveedor
        updateAssistanceState();
        mInternetTextView.setBackgroundColor(getResources().getColor(R.color.green_400));
        mInternetTextView.setText(R.string.conectado);

        slideDown(mInternetTextView);
    }

    @Override
    public void onConnectionFailure() {
        super.onConnectionFailure();

        mInternetTextView.setBackgroundColor(getResources().getColor(R.color.red_error));
        mInternetTextView.setText(R.string.verificacion_internet);
        slideUp(mInternetTextView);


    }

    // slide the view from below itself to the current position
    public void slideUp(View view) {
        YoYo.with(Techniques.FadeIn)
                .duration(700)
                .onStart(animator -> view.setVisibility(View.VISIBLE))
                .playOn(view);
    }

    // slide the view from its current position to below itself
    public void slideDown(View view) {
        YoYo.with(Techniques.FadeOut)
                .duration(3000)
                .onEnd(animator -> view.setVisibility(View.GONE))
                .playOn(view);

    }


    public void updateServiceState(){
        if (isUserFree()) {
            startService(new Intent(DrawerActivity.this, ActiveRequestService.class));
            doBindService();
        }else {
            doUnbindService();
        }
    }




}
