package com.americanassist.proveedor.managers.Server;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.ProtocolException;
import java.net.URL;

public class HttpController {
    public static String METHOD_POST = "POST";
    public static String METHOD_GET = "GET";
    public static String METHOD_PUT = "PUT";
    public static String METHOD_DELETE = "DELETE";

    private static final int READ_TIMEOUT = 50000;
    private static final int CONNECT_TIMEOUT = 30000;

    private String boundary;
    private static final String LINE_FEED = "\r\n";
    private OutputStream outputStream;
    private PrintWriter writer;

    public HttpController() {
    }

    public ServerResponse makeHttpRequest(String url, String method, String query) {

        ServerResponse serverResponse = new ServerResponse();

        if (method.equals(METHOD_POST) || method.equals(METHOD_PUT)){
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                if (method.equals(METHOD_POST)) {
                    conn.setRequestMethod(METHOD_POST);
                } else if (method.equals(METHOD_PUT)) {
                    conn.setRequestMethod(METHOD_PUT);
                }
                conn.setDoOutput(true);
                conn.setDoInput(true);

                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(
                        new OutputStreamWriter(os, "UTF-8"));
                writer.write(query);
                writer.flush();
                writer.close();
                os.close();

                serverResponse.code = conn.getResponseCode();
                InputStream in;
                if (serverResponse.code == PostTask.CODE_200 || serverResponse.code == PostTask.CODE_201) {
                    in = new BufferedInputStream(conn.getInputStream());
                } else {
                    in = conn.getErrorStream();
                }
                String response = org.apache.commons.io.IOUtils.toString(in, "UTF-8");
                serverResponse.response = response;
                return serverResponse;

            } catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        else if (method.equals(METHOD_GET)){
            try {
                HttpURLConnection conn = (HttpURLConnection) new URL(url).openConnection();
                conn.setRequestMethod(METHOD_GET);
                conn.setDoInput(true);
                serverResponse.code = conn.getResponseCode();
                InputStream in;
                if (serverResponse.code == PostTask.CODE_200 || serverResponse.code == PostTask.CODE_201) {
                    in = new BufferedInputStream(conn.getInputStream());

                } else {
                    in = conn.getErrorStream();
                }
                String response = org.apache.commons.io.IOUtils.toString(in, "UTF-8");
                serverResponse.response = response;

                return serverResponse;
            }
            catch (ProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        serverResponse.response = "Connection Failed";

        return serverResponse;
    }

}
