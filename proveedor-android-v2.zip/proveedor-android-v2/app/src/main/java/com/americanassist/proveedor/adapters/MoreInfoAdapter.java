package com.americanassist.proveedor.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.americanassist.proveedor.R;
import com.americanassist.proveedor.model.AditionalInfo;
import com.americanassist.proveedor.utils.ConfigUtils;
import com.bumptech.glide.Glide;

import java.util.ArrayList;

/**
 * <p>Adaptador encargado de gestionar la lista de detalles de asistencias</p>
 */
public class MoreInfoAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int TYPE_TEXT = 1;
    private static final int TYPE_IMAGE = 2;
    private static final int TYPE_MAP = 3;


    public ArrayList<AditionalInfo> mData = new ArrayList<>();
    private LayoutInflater mLayoutInflater;
    private Context mContext;

    public MoreInfoAdapter(Context ctx) {
        mLayoutInflater = LayoutInflater.from(ctx);
        mContext = ctx;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        switch (viewType) {
            case TYPE_TEXT:
                View v = mLayoutInflater.inflate(R.layout.card_adicional_info, parent, false);
                return new MoreInfoAdapter.MoreInfoTextVH(v);
            case TYPE_IMAGE:
                View v2 = mLayoutInflater.inflate(R.layout.card_adicional_info_image, parent, false);
                return new MoreInfoAdapter.MoreInfoImageVH(v2);
            case TYPE_MAP:
                View v3 = mLayoutInflater.inflate(R.layout.card_adicional_info_map, parent, false);
                return new MoreInfoAdapter.MoreInfoMapVH(v3);
            default:
                return null;
        }
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        final AditionalInfo aditionalInfo = mData.get(position);

        switch (holder.getItemViewType()) {
            case TYPE_TEXT:
                ((MoreInfoTextVH) holder).txtTitle.setText(aditionalInfo.title);
                ((MoreInfoTextVH) holder).txtResponse.setText(aditionalInfo.response);
                break;

            case TYPE_IMAGE:
                ((MoreInfoImageVH) holder).txtTitle.setText(aditionalInfo.title);
                Glide.with(mContext).load(aditionalInfo.response).into(((MoreInfoImageVH) holder).imgPicture);
                break;

            case TYPE_MAP:
                //((MoreInfoMapVH) holder).mSubtitleTextView.setVisibility(View.VISIBLE);
                ((MoreInfoMapVH) holder).mTittleTextView.setText(aditionalInfo.response);
                ((MoreInfoMapVH) holder).mMapImageView.setVisibility(View.VISIBLE);
                Glide.with(mContext).load(getUrl(aditionalInfo.latitude,aditionalInfo.longitude)).into(((MoreInfoMapVH) holder).mMapImageView);
                break;

            default:
                break;
        }
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    @Override
    public int getItemViewType(int position) {
        AditionalInfo aditionalInfo = mData.get(position);
        switch (aditionalInfo.type) {
            case AditionalInfo.TYPE_TEXT:
                return TYPE_TEXT;
            case AditionalInfo.TYPE_IMAGE:
                return TYPE_IMAGE;
            case AditionalInfo.TYPE_MAP:
                return TYPE_MAP;
            default:
                return 0;
        }
    }

    public void addAditionalInfos(ArrayList<AditionalInfo> aditionalInfos) {
        mData.addAll(aditionalInfos);
        notifyDataSetChanged();
    }

    public void clean() {
        mData.clear();
        notifyDataSetChanged();
    }

    class MoreInfoTextVH extends RecyclerView.ViewHolder {
        TextView txtTitle;
        TextView txtResponse;

        public MoreInfoTextVH(View itemView) {
            super(itemView);
            txtResponse = itemView.findViewById(R.id.CAI_edittext_response);
            txtTitle = itemView.findViewById(R.id.CAI_textview_title);
        }
    }

    class MoreInfoImageVH extends RecyclerView.ViewHolder {
        TextView txtTitle;
        ImageView imgPicture;

        public MoreInfoImageVH(View itemView) {
            super(itemView);
            imgPicture = itemView.findViewById(R.id.CAII_imageview_picture);
            txtTitle = itemView.findViewById(R.id.CAII_textview_title);
        }
    }

    class MoreInfoMapVH extends RecyclerView.ViewHolder {
        private TextView mTittleTextView;
        private TextView mSubtitleTextView;
        private ImageView mMapImageView;

        public MoreInfoMapVH(View itemView) {
            super(itemView);

            mTittleTextView = itemView.findViewById(R.id.tittle);
            mSubtitleTextView = itemView.findViewById(R.id.subtitle);
            mMapImageView = itemView.findViewById(R.id.map);
        }
    }

    /**
     * Se encarga de devolver una url de la
     * api de static maps para la carga  en campos de tipo direccion
     * @param latitude latitude para la url
     * @param longitude longitud para la url
     * @return url final con la api de google
     */
    private String getUrl(double latitude, double longitude) {
        return "https://maps.googleapis.com/maps/api/staticmap?center="+latitude+","+longitude+
                "&zoom=20&size=600x300&markers=color:red%7Clabel:D%7C"+latitude+","+longitude+"&key="+ ConfigUtils.getActiveDistanceMatrixApiKey(mContext);
    }
}
