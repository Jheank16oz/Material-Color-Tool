package com.americanassist.proveedor.maneuver;

import com.americanassist.proveedor.BasePresenter;
import com.americanassist.proveedor.BaseView;

/**
 * Created by ICATECH on 23/03/18.
 *
 * <p>Contrato de las caracteristicas del Presentador y Vista de Maniobras</p>
 */

public interface ManeuverContract {

    interface View extends BaseView<ManeuverContract.Presenter> {
        void displayState(String state);

    }

    interface Presenter extends BasePresenter {
        void updateAssistanceState(String state);
    }
}
