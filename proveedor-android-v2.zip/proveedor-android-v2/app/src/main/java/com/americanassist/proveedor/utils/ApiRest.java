package com.americanassist.proveedor.utils;

import android.content.Context;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;

/**
 * Framework para las conexiones AsyncHttpClient REST
 */
public class ApiRest
{
    private static String BASE_URL;

    public ApiRest(Context context){
        BASE_URL = ConfigApp.getUrlServer(context);
    }

    private static AsyncHttpClient aSyncClient = new AsyncHttpClient();
    public void get(String url, RequestParams params, AsyncHttpResponseHandler
            responseHandler)
    {

        aSyncClient.setConnectTimeout(50000);
        aSyncClient.setResponseTimeout(50000);
        aSyncClient.get(getAbsoluteUrl(url), params, responseHandler);
    }
    public static void post(String url, RequestParams params, AsyncHttpResponseHandler
            responseHandler)
    {
        aSyncClient.setConnectTimeout(100000);
        aSyncClient.setResponseTimeout(100000);
        aSyncClient.post(getAbsoluteUrl(url), params, responseHandler);
    }
    public static void put(String url, AsyncHttpResponseHandler responseHandler)
    {
        aSyncClient.setConnectTimeout(50000);
        aSyncClient.setResponseTimeout(50000);
        aSyncClient.put(null, getAbsoluteUrl(url), null, "application/json", responseHandler);
    }
    public static void delete(String url, RequestParams params, AsyncHttpResponseHandler
            responseHandler)
    {
        aSyncClient.setConnectTimeout(50000);
        aSyncClient.setResponseTimeout(50000);
        aSyncClient.delete(getAbsoluteUrl(url), params, responseHandler);
    }
    private static String getAbsoluteUrl(String relativeUrl)
    {
        return BASE_URL + relativeUrl;
    }
    public static void getCustom(String url, RequestParams params, AsyncHttpResponseHandler
            responseHandler)
    {
        aSyncClient.setConnectTimeout(50000);
        aSyncClient.setResponseTimeout(50000);
        aSyncClient.get(url, params, responseHandler);
    }
}