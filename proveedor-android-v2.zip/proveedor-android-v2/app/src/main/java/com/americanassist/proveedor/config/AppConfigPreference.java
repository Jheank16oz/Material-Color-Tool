package com.americanassist.proveedor.config;

import android.content.Context;

import net.grandcentrix.tray.TrayPreferences;

/**
 * <p> AppConfigPreference, crea un acceso de preferencias para un módulo </p>
 */
public class AppConfigPreference extends TrayPreferences {

    public AppConfigPreference(final Context context) {
        super(context, "myConfig", 1);
    }
}
