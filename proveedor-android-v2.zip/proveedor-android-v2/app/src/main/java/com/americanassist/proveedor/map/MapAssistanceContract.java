package com.americanassist.proveedor.map;

import android.os.Bundle;

import com.americanassist.proveedor.BasePresenter;
import com.americanassist.proveedor.BaseView;
import com.americanassist.proveedor.model.Assistance;
import com.google.android.gms.maps.model.LatLng;

/**
 *
 * Contrato para la vista y Presentador de las caracteriticas del mapa
 */
public interface MapAssistanceContract {


    interface View extends BaseView<Presenter> {
        void displayState(String state, String message);

        void toggleMenuPressed();

        void displayLocationChanced();

        void setLocationChances(LatLng latLng, float bearing);

        void updateInfoAssistance(String time, String distance, String direction);

        void refreshStatus();

        void updateAssistanceState(Assistance assistance);

    }

    interface Presenter extends BasePresenter {
        void updateAssistanceState(String notificationType, String state);

        void updateInfoAssistance(String time, String distance, String direction);

        void updateLocationState(Bundle bundle);

        void toggleMenuPressed();

        void refreshStatus();

        void updateAssistanceState(Assistance assistance);
    }
}
