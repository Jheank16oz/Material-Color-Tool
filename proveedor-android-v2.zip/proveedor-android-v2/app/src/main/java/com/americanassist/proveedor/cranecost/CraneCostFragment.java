package com.americanassist.proveedor.cranecost;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.americanassist.proveedor.BaseApplication;
import com.americanassist.proveedor.DrawerActivity;
import com.americanassist.proveedor.R;
import com.americanassist.proveedor.adapters.CostsAdapter;
import com.americanassist.proveedor.dialogs.ErrorDialog;
import com.americanassist.proveedor.managers.Server.ApiManager;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.Cost;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.utils.Functions;
import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_ACCEPT_COSTS;
import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_ACCEPT_COSTS_TOWING;
import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_ACCEPT_MANEUVER;
import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.NOTIFICATION_TYPE_CANCEL;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by ICATECH on 23/03/18.
 * <p>Vistas de Costos grua controla la lista de costos grua
 * dinamicos</p>
 */

public class CraneCostFragment extends Fragment implements CostsAdapter.CostsAdapterCallback, CraneCostContract.View{

    private TextView txtTotal;
    private Context mContext;
    protected LinearLayoutManager llm;
    private CostsAdapter costsAdapter;
    private ErrorDialog errorDialog;

    private CraneCostContract.Presenter mPresenter;
    private String distance;
    private String costs;


    private String assistanceId, route1, route2;
    public static final String COSTS = "costs";
    public static final String DISTANCE = "distance";
    public static final String ASSISTANCE_ID = "assistanceId";
    public static final String ASSISTANCE_ROUTE1 = "assistanceRoute1";
    public static final String ASSISTANCE_ROUTE2 = "assistanceRoute2";



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.cranecost_fragment, container, false);
        initializeComponents(view);
        return view;
    }

    private void initializeComponents(View view) {
        mContext = getContext();
        RecyclerView recyclerCosts = view.findViewById(R.id.AC_recyclerview_listcosts);
        txtTotal = view.findViewById(R.id.AC_textview_total);
        view.findViewById(R.id.send).setOnClickListener(v -> onButSendClicked());

        llm = new LinearLayoutManager(getContext());
        recyclerCosts.setLayoutManager(llm);
        costsAdapter = new CostsAdapter(getContext(), this);
        recyclerCosts.setAdapter(costsAdapter);


        txtTotal.setVisibility(View.GONE);
        displayCosts();

    }

    @Override
    public void setCosts(String distance,String costs, String assistanceId, String route1, String route2){
        this.distance = distance;
        this.costs = costs;
        this.assistanceId = assistanceId;
        this.route1 = route1;
        this.route2 = route2;
    }

    @Override
    public void displayCosts(){
        try {
            ArrayList<Cost> costList = Cost.getListCostsFromJson(new JSONArray(costs));
            txtTotal.setVisibility(View.VISIBLE);
            costsAdapter.addCosts(costList);
            costsAdapter.notifyDataSetChanged();
            calculateTotalAmount();
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }


    /**
     * Se encarga de calcular el total de costos ingresados.
     */
    private void calculateTotalAmount() {
        double total = 0.0;
        for (int i = 0; i < costsAdapter.mData.size(); i++) {
            if (costsAdapter.mData.get(i).checked) {
                total += costsAdapter.mData.get(i).amount;
            }
        }
        txtTotal.setText(String.format("%.2f", total));
    }

    @Override
    public void onEditChanged() {
        calculateTotalAmount();
    }



    public void onButSendClicked() {
        final Provider mProvider = SharedPreferencesManager.getProvider(getContext());
        ((DrawerActivity) getActivity()).showLoadingView();

        if (mProvider != null) {
            getCosts(mProvider);
        }

    }

    /**
     * Gestiona la lista de costos a enviar a la api
     * @param mProvider proveedor obtenido en login
     */
    private void getCosts(@NonNull final Provider mProvider) {
        if (getActivity() == null) {
            return;
        }

        if (Functions.checkInternetConnection(mContext)) {
            return;
        }

        final LatLng mCurrentLocation = ((BaseApplication)getActivity().getApplication()).getCurrentLocation();

        if (assistanceId == null){
            Toast.makeText(getContext(), R.string.intentalo_mas_tarde, Toast.LENGTH_SHORT).show();
            return;
        }
        new ApiManager(mContext).sendCostsAssistanceTowing(mProvider.country, assistanceId, mProvider.idProvider, mProvider.idContact, mCurrentLocation.latitude, mCurrentLocation.longitude, route1, route2, generateJsonFromCosts(), distance, new ApiManagerHelper.ApiSendCostCallback() {
            @Override
            public void onSendCostsSuccess(int block) {
                ((DrawerActivity)getActivity()).hideLoadingView();
                // Enviamos al mapa para que se actualize el estado y el defina la vista a la cual
                // continuar.
                ((DrawerActivity)getActivity()).setFragment(DrawerActivity.MAP_FRAGMENT);

            }

            @Override
            public void onSendCostsError(String error) {
                ((DrawerActivity)getActivity()).hideLoadingView();
                errorDialog = new ErrorDialog(mContext, error);
                errorDialog.show();
                errorDialog.setCancelable(false);
                errorDialog.setCanceledOnTouchOutside(true);
                errorDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
                    @Override
                    public void onCancel(DialogInterface dialog) {
                        // pasamos al mapa
                        ((DrawerActivity)getActivity()).setFragment(DrawerActivity.MAP_FRAGMENT);
                    }
                });
            }
        });

    }

    /**
     * Genera la lista de costos en Formato JSON
     * para enviar al server
     * @return lista de costos en JSON
     */
    private String generateJsonFromCosts() {
        JSONArray jsonArray = new JSONArray();
        for (int i = 0; i < costsAdapter.mData.size(); i++) {
            Cost cost = costsAdapter.mData.get(i);
            if (cost.checked) {
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("idcosto", cost.id);
                    jsonObject.put("value", cost.amount);
                    jsonObject.put("descripcion", cost.description);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                jsonArray.put(jsonObject);
            }
        }
        return jsonArray.toString();
    }

    @Override
    public void displayState(String state) {
        if (!isAdded()){
            return;
        }
        switch (state){
            case NOTIFICATION_ACCEPT_COSTS:
                // Quitamos popup
                ((DrawerActivity)getActivity()).displayWaiting(null,false);

                // Pasamos a pantalla de termino
                ((DrawerActivity)getActivity()).setFragment(DrawerActivity.SOLUTION_FRAGMENT);
                break;
            case NOTIFICATION_TYPE_CANCEL:
                ((DrawerActivity)getActivity()).displayWaiting(null,false);

                errorDialog = new ErrorDialog(mContext, "Su asistencia ha sido cancelada por el cliente");
                errorDialog.show();
                errorDialog.setCancelable(false);
                errorDialog.setCanceledOnTouchOutside(true);
                errorDialog.setOnCancelListener(dialog -> {
                    // Volvemos al mapa
                    // finish();
                    ((DrawerActivity)getActivity()).setFragment(DrawerActivity.MAP_FRAGMENT);
                });
                break;
            case NOTIFICATION_ACCEPT_COSTS_TOWING:
                // Quitamos popup
                ((DrawerActivity)getActivity()).displayWaiting(null,false);

                // Volvemos al mapa
                ((DrawerActivity)getActivity()).setFragment(DrawerActivity.MAP_FRAGMENT);
                break;
            case NOTIFICATION_ACCEPT_MANEUVER:

                // Quitamos popup
                ((DrawerActivity)getActivity()).displayWaiting(null,false);

                // Volvemos al mapa
                ((DrawerActivity)getActivity()).setFragment(DrawerActivity.MAP_FRAGMENT);
                break;

        }
    }

    @Override
    public void setPresenter(CraneCostContract.Presenter presenter) {
        mPresenter = checkNotNull(presenter);
    }
}
