package com.americanassist.proveedor.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Country implements Parcelable {

    @SerializedName("idpais")
    @Expose
    public String idPais;
    @SerializedName("descripcion")
    @Expose
    public String description;

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.idPais);
        dest.writeString(this.description);
    }

    public Country(String idPais ,String description) {
        this.idPais =idPais;
        this.description = description;
    }

    private Country(Parcel in) {
        this.idPais = in.readString();
        this.description = in.readString();
    }

    static final Parcelable.Creator<Country> CREATOR = new Parcelable.Creator<Country>() {
        @Override
        public Country createFromParcel(Parcel source) {
            return new Country(source);
        }

        @Override
        public Country[] newArray(int size) {
            return new Country[size];
        }
    };

    @Override
    public String toString() {
        return description;
    }

}
