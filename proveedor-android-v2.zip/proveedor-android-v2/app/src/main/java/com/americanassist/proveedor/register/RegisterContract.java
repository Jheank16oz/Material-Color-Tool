package com.americanassist.proveedor.register;

import com.americanassist.proveedor.BasePresenter;
import com.americanassist.proveedor.BaseView;
import com.americanassist.proveedor.model.Country;

import java.util.List;

/**
 *
 * <p>Contrato del Presentador y Vista de las caracteristicas del Registro de
 * proveedor</p>
 */

public interface RegisterContract {

    interface View extends BaseView<RegisterContract.Presenter> {

        void displayCountries();
        void setCountries(List<Country> countries);
        void setLoading(boolean isLoading);
        void displaySuccessFulRequest(String message);
    }

    interface Presenter extends BasePresenter {
        void requestCountries();
        void sendRequestRegisterProvider(String username, String email, String phone,
                           String service, String city, String country,String description);

    }
}
