package com.americanassist.proveedor.diagnostic;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 *
 * <p>Presentador para las caracteristicas de Diagnostico</p>
 */

public class DiagnosticPresenter implements DiagnosticContract.Presenter{

    private final DiagnosticContract.View mDiagnosticView;

    public DiagnosticPresenter(DiagnosticContract.View view) {
        mDiagnosticView = checkNotNull(view);
        mDiagnosticView.setPresenter(this);
    }
    @Override
    public void start() {
        mDiagnosticView.displayQuestions();
    }

    @Override
    public void updateAssistanceState(String state) {
        mDiagnosticView.displayState(state);
    }


}
