package com.americanassist.proveedor.register;
import android.content.Context;

import com.americanassist.proveedor.connection.modelRepository.UserRepository;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.model.Country;

import java.util.List;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 *
 *
 * Presentador de las caracteristicas de Registro de proveedor
 */

public class RegisterPresenter implements RegisterContract.Presenter {

    private final RegisterContract.View mRegisterView;
    private UserRepository mUserRepository;

    RegisterPresenter(RegisterContract.View view, Context context) {
        mRegisterView = checkNotNull(view);
        mRegisterView.setPresenter(this);

        mUserRepository = new UserRepository(context);
    }
    @Override
    public void start() {}

    @Override
    public void requestCountries() {
        mRegisterView.setLoading(true);
        mUserRepository.getCountries(new ApiManagerHelper.CountriesCallback() {
            @Override
            public void onSuccess(List<Country> countries) {
                mRegisterView.setLoading(false);
                mRegisterView.setCountries(countries);
                mRegisterView.displayCountries();
            }

            @Override
            public void onFailure() {
                mRegisterView.setLoading(false);
            }


        });
    }

    @Override
    public void sendRequestRegisterProvider(String username, String email, String phone, String service,
                              String city, String country, String description) {

        mRegisterView.setLoading(true);
        mUserRepository.sendRequestRegisterProvider(username, description, country, email, phone, service,city,
                new ApiManagerHelper.ProviderRegisterCallback() {
                    @Override
                    public void onSuccess(String message) {
                        mRegisterView.setLoading(true);
                        mRegisterView.displaySuccessFulRequest(message);
                    }

                    @Override
                    public void onFailure() {
                        mRegisterView.setLoading(false);
                    }
                });
    }


}
