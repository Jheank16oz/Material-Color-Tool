package com.americanassist.proveedor.cost;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by ICATECH on 23/03/18.
 *
 * <p>Presentador de Costos</p>
 */

public class CostPresenter implements CostContract.Presenter{

    private final CostContract.View mCostContractView;

    public CostPresenter(CostContract.View view) {
        mCostContractView = checkNotNull(view);
        mCostContractView.setPresenter(this);
    }

    @Override
    public void start() {

    }

    @Override
    public void updateAssistanceState(String state) {

        mCostContractView.displayState(state);

    }

}
