package com.americanassist.proveedor;

import android.content.Context;
import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.americanassist.proveedor.config.ConfigurationAppActivity;
import com.americanassist.proveedor.connection.modelRepository.UserRepository;
import com.americanassist.proveedor.dialogs.TwoOptionsDialog;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.model.Session;
import com.americanassist.proveedor.register.RegisterActivity;
import com.americanassist.proveedor.services.ActiveRequestService;
import com.americanassist.proveedor.utils.Functions;

/**
 * Vista encargada de acciones de inicio de sesion
 */
public class LoginActivity extends LocationRequestActivity {

    private Button mLoginButton;
    private EditText mUsernameEditText;
    private EditText mPasswordEditText;

    private Context mContext;
    private final int REQUEST_CONFIGURATION = 3;

    // Modelo encargado de condensar la informacion de envio y llegada de los respectivos webservices
    private UserRepository mUserRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Inicializamos
        mUserRepository = new UserRepository(this);
        displayEmergencyButton = false;
        mLoginButton = findViewById(R.id.login);
        mUsernameEditText = findViewById(R.id.username);
        mPasswordEditText = findViewById(R.id.password);
        TextView mVersionTextView = findViewById(R.id.version);

        mVersionTextView.setText(String.format("Version: %s", BuildConfig.VERSION_NAME));

        mContext = this;

        initListeners();
    }

    private void initListeners() {
        findViewById(R.id.register).setOnClickListener(v -> startActivity(new Intent(getBaseContext(), RegisterActivity.class)));

        mLoginButton.setOnClickListener(v -> {
            if (allCorrect()) {
                showLoadingView();

                if (!BuildConfig.SUPPRESS_APP_CONFIG && isUserConfig()){
                    hideLoadingView();
                    startActivityForResult(new Intent(this, ConfigurationAppActivity.class), REQUEST_CONFIGURATION);

                }else if (super.hasLocation()) {
                    executeUserAuthentication(getLocation());
                } else {
                    hideLoadingView();
                    super.validateGps();
                }
            } else {
                Toast toast = Toast.makeText(mContext, R.string.campos_necesario, Toast.LENGTH_SHORT);
                toast.show();
            }
        });
    }

    /**
     * Se consulta la respuesta de los webservices con las respuestas concentradas
     * en los metodos pertenecientes al callback
     * @param mLastLocation recibe la ubicacion actual del tecnico
     */
    private void executeUserAuthentication(final Location mLastLocation) {
        mUserRepository.login(mUsernameEditText.getText().toString().trim(),
                mLastLocation.getLatitude(),
                mLastLocation.getLongitude(),
                mPasswordEditText.getText().toString().trim(),
                new ApiManagerHelper.SessionCallback() {
                    @Override
                    public void duplicatedSession(final Session session) {
                        hideLoadingView();

                        new TwoOptionsDialog(mContext, getString(R.string.sesion_duplicada_titulo), getString(R.string.sesion_duplicada_contenido), getString(R.string.cancelar), getString(R.string.aceptar), new TwoOptionsDialog.TwoOptionsDialogListener() {
                            @Override
                            public void onCancelClicked() {
                                Toast.makeText(LoginActivity.this, getString(R.string.no_inicio_sesion), Toast.LENGTH_SHORT).show();
                            }

                            @Override
                            public void onAcceptClicked() {
                                showLoadingView();
                                // En caso de que acepte iniciar sesion, se envia la peticion de cerrar las demas sesiones
                                processExpiredSession(session, mLastLocation);
                            }
                        }).show();
                    }

                    @Override
                    public void login(Provider provider) {
                        processConfigurationApp(provider);
                    }

                    @Override
                    public void onFailure() {
                        hideLoadingView();
                    }
                });
    }

    private void processExpiredSession(Session session, Location mLastLocation) {
        mUserRepository.expiredSessions(
                session.idproveedor,
                session.idcontacto,
                session.country,
                String.valueOf(mLastLocation.getLatitude()),
                String.valueOf(mLastLocation.getLongitude()),
                this::processConfigurationApp);
        hideLoadingView();
    }

    /**
     * Metodo que elimina al proveedor actual de preferencias para que no pueda ser
     * accedido por de nuevo y asi ese tecnico (usuario), ya no pueda tener acceso
     * a los beneficios de la aplicacion
     * @param provider contiene todos los datos del proveedor
     */
    private void processLogin(Provider provider) {
        SharedPreferencesManager.setProvider(provider, getBaseContext());
        // Empezamos a enviar coordenadas
        //startService(new Intent(LoginActivity.this, ActiveRequestService.class));
        // Una vez hecho el login comprobamos el estado del proveedor (asistencia pendiente...)
        hideLoadingView();
        Intent i = new Intent(LoginActivity.this, DrawerActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(i);
    }

    /**
     * Se procesan las configuraciones de la aplicacion actual
     * @param provider proveedor actual
     */
    public void processConfigurationApp(final Provider provider) {

        if (Functions.checkInternetConnection(mContext)) {
            return;
        }

        configurationApp(provider, new ApiManagerHelper.GetConfigurationCallback() {
            @Override
            public void onSuccessConfigurationLoaded() {
                processLogin(provider);
            }

            @Override
            public void onFailureConfigurationLoaded() {
                hideLoadingView();
                Toast.makeText(getBaseContext(), getString(R.string.configuracion_incorrecta), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean allCorrect() {
        return mUsernameEditText.length() != 0 && mPasswordEditText.length() != 0;
    }


    public boolean isUserConfig() {
        String username = mUsernameEditText.getText().toString().trim();
        String password = mPasswordEditText.getText().toString().trim();
        return username.equals(BuildConfig.USER_CONFIG) && password.equals(BuildConfig.PASSWORD_CONFIG);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CONFIGURATION) {
            if (resultCode == RESULT_OK){
                mUserRepository = new UserRepository(this);
                //limpiamos el usuario
                if (mUsernameEditText != null && mPasswordEditText != null) {
                    mUsernameEditText.setText("");
                    mPasswordEditText.setText("");
                }
            }
        }
    }
}
