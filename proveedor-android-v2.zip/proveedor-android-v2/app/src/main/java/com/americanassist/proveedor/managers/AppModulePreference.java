package com.americanassist.proveedor.managers;

import android.content.Context;

import net.grandcentrix.tray.TrayPreferences;

/**
 * <p> AppModulePreference, crea un acceso de preferencias para un módulo </p>
 */
class AppModulePreference extends TrayPreferences {

    AppModulePreference(final Context context) {
        super(context, "myModule", 1);
    }
}