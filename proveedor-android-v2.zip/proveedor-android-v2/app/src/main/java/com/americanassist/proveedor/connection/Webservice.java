package com.americanassist.proveedor.connection;

import com.americanassist.proveedor.model.CountryResult;
import com.americanassist.proveedor.model.Detail;
import com.americanassist.proveedor.model.InactivtyJustification;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.model.Session;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

/**
 * <p>Interfaz para realizar solicitudes, trabajando bajo
 * el client Rest Retrofit</p>
 *
 */

public interface Webservice {

    /**
     *
     * @param user nombre de usuario utilizado para iniciar sesion en la vista del login
     * @param latitude latitud actual en la que se encuentra el tecnico
     * @param longitude longitud actual en la que se encuentra el tecnico
     * @param password contrasenia utilizada para iniciar sesion en la vista del login
     * @param firebaseToken identificador unico de sesion en el momento en este dispositivo
     * @return
     */
    @POST("inicio_sesion_proveedor/")
    @FormUrlEncoded
    Call<Session> getUserSession(
            @Field("usuario") String user,
            @Field("latitud") String latitude,
            @Field("longitud") String longitude,
            @Field("DialDevice") String dialDevice,
            @Field("clave") String password,
            @Field("DeviceToken") String firebaseToken);

    /**
     *
     * @param idproveedor este es el identificador de la empresa a la cual pertenece el tecnico
     * @param idcontacto identificacion del tecnico como tal
     * @param country pais actual, en el que se encuentra el tecnico
     * @param firebaseToken identificador unico de sesion en el momento en este dispositivo
     * @return
     */
    @POST("sesiones_caducadas_provedor/")
    @FormUrlEncoded
    Call<Provider> getExpiredSession(
            @Field("idproveedor") String idproveedor,
            @Field("idcontacto") String idcontacto,
            @Field("country") String country,
            @Field("respuesta") String respuesta,
            @Field("DialDevice") String dialDevice,
            @Field("DeviceToken") String firebaseToken,
            @Field("latitud") String latitude,
            @Field("longitud") String longitude);

    /**
     * @return el modelo {@link CountryResult} que contiene la lista de paises
     */
    @GET("obtener_paises/")
    Call<CountryResult> getCountries();

    /**
     * @return el modelo {@link CountryResult} que contiene la lista de paises
     */
    @GET("obtener_justificacion_inactividad_prov/")
    Call<InactivtyJustification> getInactivtyJustifications(@Query("country") String country);


    /**
     *
     * @param username nombre de usuario del proveedor
     * @param description descripcion por parte del proveedor a registrarse
     * @param country pais donde se solicita el registro
     * @param email correo electronico del proveedor
     * @param phone telefono del ptoveedor
     * @param service servicio encargado del proveedor
     * @return {@link Detail} con el mensaje devuelto
     */
    @POST("solicitud_registro_proveedor/")
    @FormUrlEncoded
    Call<Detail> sendRequestRegister(
            @Field("nombre_proveedor") String username,
            @Field("descripcion") String description,
            @Field("country") String country,
            @Field("correo") String email,
            @Field("telefono") String phone,
            @Field("servicio") String service,
            @Field("ciudad") String city
    );



    @POST("evento_panico_proveedor/")
    @FormUrlEncoded
    Call<Detail> sendPanicAlert(
            @Field("idproveedor") String providerId,
            @Field("idcontacto") String contactId,
            @Field("country") String country,
            @Field("latitud") String latitude,
            @Field("longitud") String longitude);

    @POST("inactivar_proveedor/")
    @FormUrlEncoded
    Call<Detail> sendInactive(
            @Field("token") String token,
            @Field("idjustificacion") String justificationId,
            @Field("country") String country);

    @POST("activar_proveedor/")
    @FormUrlEncoded
    Call<Detail> sendActive(
            @Field("token") String token,
            @Field("country") String country);
}
