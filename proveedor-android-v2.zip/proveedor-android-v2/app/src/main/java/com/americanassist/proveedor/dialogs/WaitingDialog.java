package com.americanassist.proveedor.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Bundle;
import android.support.design.widget.BottomSheetBehavior;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.americanassist.proveedor.R;

/**
 * Vista de Dialogo de Bloqueo, es un dialogo FullScreen que permite
 * Bloquear al usuario de cualquier accion, es utilizado en procesos de
 * asistencias en estados como por ejemplo:
 * -Espera de aceptacion de costos
 * -Espera de aceptacion de Manuobras
 * -Espera de Confirmacion de Arribo
 */
public class WaitingDialog extends Dialog {

    private String description;
    private boolean noImage;
    private View.OnClickListener mOnSendPanicClickListener;
    private View.OnClickListener mOnRefreshClickListener;
    public ImageView imageView;
    public TextView mDescriptionTextView;

    private LinearLayout bottomSheet;
    private BottomSheetBehavior mBottomSheetBehavior;


    /**
     * Constructor .
     * @param context de la actividad que accede
     * @param description1 mensaje a imprimir en el dialogo
     * @param noImage para mostrar o no la imagen que indica que es un error lo que se aloja
     * @param onSendPanic recibimos lo que se ejecuto en el metodo onClick  en DrawerActivity
     */
    public WaitingDialog(Context context, String description1, boolean noImage,View.OnClickListener onSendPanic,
                         View.OnClickListener mOnRefreshClickListener) {
        super(context,android.R.style.Theme_Black_NoTitleBar);
        this.description = description1;
        this.noImage = noImage;
        mOnSendPanicClickListener = onSendPanic;
        this.mOnRefreshClickListener = mOnRefreshClickListener;
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event){
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (mBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {

                Rect outRect = new Rect();
                bottomSheet.getGlobalVisibleRect(outRect);

                if(!outRect.contains((int)event.getRawX(), (int)event.getRawY()))
                    mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
            }
        }

        return super.dispatchTouchEvent(event);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setBackgroundDrawable(
                new android.graphics.drawable.ColorDrawable(Color.WHITE));

        getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT);

        setContentView(R.layout.dialog_waiting);

        mDescriptionTextView = findViewById(R.id.DE_textview_description);
        mDescriptionTextView.setText(description);

        ViewGroup mViewGroup = findViewById(R.id.relativeLayout);
        mViewGroup.setOnClickListener(mOnRefreshClickListener);


        createEmergencyButton();

    }

    /**
     * Creamos el contenedor y funcionalidades del
     * boton de emergencia.
     */
    private void createEmergencyButton() {

        ViewGroup viewGroup = this.findViewById(android.R.id.content);
        getLayoutInflater().inflate(R.layout.emergency_layout, viewGroup);
        bottomSheet = findViewById(R.id.bottomSheet);
        ImageView mEmergencyButton = bottomSheet.findViewById(R.id.emergency_button);
        Button mPanicAlertButton = bottomSheet.findViewById(R.id.buttonPanicAlert);
        mBottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
        mBottomSheetBehavior.setSkipCollapsed(true);

        // mEmergencyButton permite mostrar o no el boton encargado de emitir la alerta
        mEmergencyButton.setOnClickListener(v -> mBottomSheetBehavior.setState(mBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED
                ?BottomSheetBehavior.STATE_COLLAPSED:BottomSheetBehavior.STATE_EXPANDED));

        // Al presionar este boton es en donde se emitira la alerta
        mPanicAlertButton.setOnClickListener(mOnSendPanicClickListener);
    }

    public void setDescription(String description){
        this.description = description;
        if (mDescriptionTextView == null){
            return;
        }
        mDescriptionTextView.setText(description);
    }

}