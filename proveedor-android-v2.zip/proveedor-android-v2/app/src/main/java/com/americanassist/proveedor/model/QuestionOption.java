package com.americanassist.proveedor.model;

public class QuestionOption {

    public String id;
    public String questionName;
    public String optionValue;

    public boolean checked;
}
