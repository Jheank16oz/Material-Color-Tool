package com.americanassist.proveedor.services;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import io.socket.emitter.Emitter;

/**
 * EventListener de Notificaciones socket
 */
public class SocketEvents implements Emitter.Listener {

    private NotificationListener notificationsListener;

    public interface NotificationListener{

        /**
         *  Este tipo de notificacion le especificara a la aplicacion que debe
         *  ejecutarse el estado del proveedor ya que se acaba de realizar una
         *  asignacion desde el sistema a ese proveedor en especifico.
         */
        String NOTIFICATION_TYPE_ASSIG_PROV_SOAANG = "asig_prov_soaang";

        /**
         *  Este tipo de notificacion se interpreta como un bloqueo del servicio,
         *  ya que se debe esperar a que se acepte algun excedente por parte
         *  del afiliado o de la cabina.
         */
        String NOTIFICATION_TYPE_PREPARE_ACEPT = "habilitar_espera_aceptacion"; // Nuevo

        /**
         * Este tipo de notificacion se debe interpretar por medio de la aplicacion
         * como la habilitacion de la finalizacion del servicio, es decir
         * mostrarle el boton de finalizar servicio.
         */
        String NOTIFICATION_TYPE_PREPARE_TERMINATE = "habilitar_termino_servicio"; // Nuevo

        /**
         * Este tipo de notificacion significa que el proveedor debe quedarse
         * en el mapa enviando coordenadas constantemente con la particularidad
         * de que se debe calcular el tiempo y la distancia con respecto al punto
         * de destino del servicio, hasta que le salga el boton de finalizar servicio.
         */
        String NOTIFICATION_TYPE_PREPARE_LAST_SOLUTION = "habilitar_antes_termino_servicio"; // Nuevo

        /**
         * Este tipo de notificacion significa que el excedente por la cual el
         * proveedor estaba bloqueado se debe quitar y automaticamente debe o
         * ejecutar el webservice de estado del proveedor o directamente cargar
         * los datos de la asistencia si se tienen en preferencia.
         */
        String NOTIFICATION_ACCEPT_COSTS_TOWING = "excedente_aceptado_etapa1";

        /**
         * Este tipo de notificacion le indica al proveedor que la asistencia ha
         * sido cancelada por el afiliado o por cabina y que el proveedor vuelve
         * a quedar libre, es decir vuelve al mapa sin asistencias asignadas.
         */
        String NOTIFICATION_TYPE_CANCEL = "cancelar_afiliado";

        /**
         * Este tipo de notificacion significa que el excedente por el cual estaba
         * el proveedor bloqueado se debe quitar y se debe automaticamente mostrar
         * el boton de finalizar el servicio.
         */
        String NOTIFICATION_ACCEPT_COSTS = "excedente_aceptado_etapa2";

        /**
         * Este tipo de notificacion significa que el excedente por el cual estaba
         * el proveedor bloqueado se debe quitar y automaticamente dejarlo en el
         * mapa enviando coordenadas con la particularidad de que el tiempo y
         * distancia que se deben mostrarse deben ser calculados  con respecto al
         * lugar de destino.
         */
        String NOTIFICATION_ACCEPT_MANEUVER = "excedente_aceptado_maniobras";

        /**
         * Este tipo de notificacion le indica a la aplicacion de proveedor que debe
         * mostrar el boton de diagnostico.
         */
        String NOTIFICATION_TYPE_PREPARE_DIAGNOSTIC = "habilitar_diagnostico";

        /**
         * Esta notificacion le indica a la aplicacion que debe mostrar el boton
         * costos del servicio.
         */
        String NOTIFICATION_TYPE_PREPARE_COST = "habilitar_items_costos"; // Nuevo

        /**
         *  Esta notificacion le indica a la aplicacion que debe mostrar el boton
         *  para preguntar si hay maniobras en el servicio.
         */
        String NOTIFICATION_TYPE_PREPARE_MANEUVER = "habilitar_maniobras";

        /**
         * Esta notificacion se interpreta como una nueva asistencia generada y la cual
         * ese proveedor esta en capacidad de poder suplir. esta notificacion dentro del
         * parametro inforequest se envia toda la informacion necesaria de la asistencia
         * para poder funcionar.
         */
        String NOTIFICATION_TYPE_REQUEST = "solicitud";

        /**
         * Esta notificacion indica que otro usuario ingreso con las mismas credenciales
         * de la sesion que se tenia activa; y como las sesiones deben ser unicas entonces
         * la sesion actual se cierra para darle acceso completo al otro usuario.
         */
        String NOTIFICATION_TYPE_EXPIRED_SESSION = "sesion_caducada_proveedor";

        /**
         * Esta notificacion indica que es necesario que se refresque la vista
         * ya que el estado del proveedor cambio.
         * Actualmente solo se utiliza para cuando desde el servidor se presione
         * el boton antes de finalizar el servicio por medio de la app.
         */
        String NOTIFICATION_TYPE_UPDATE = "update";

        /**
         * Notificacion para indicar que una asistencia ha sido cancelada
         * y es necesario actualizar la vista.
         */
        String NOTIFICATION_REQUEST_CANCEL = "cancelar";



        /**
         * Este evento es lanzado cuando llega un
         * nuevo estado del proveedor.
         * @param state estado del proveedor
         * @param message mensaje devuelto para esta notificacion
         */
        void onNotification(String state, String message);

        /**
         * Este evento se ejecuta cuando nos llega una nueva
         * solicitud de asistencia
         */
        void onNewRequest();

        /**
         * Este evento se ejecuta cuando nos llega un cancelado
         * de asistencia
         */
        void onCancelAssistance();

    }

    SocketEvents(NotificationListener notificationsListener){

        this.notificationsListener = notificationsListener;
    }

    @Override
    public void call(Object... args) {
        try {
            JSONObject mJsonObject = new JSONObject(args[0].toString());
            Log.e("result",mJsonObject.toString());
            String state = mJsonObject.getString("tipo_notificacion");
            String message = mJsonObject.optString("mensaje");

            switch (state){
                case NotificationListener.NOTIFICATION_TYPE_REQUEST:
                    // Solicitamos una actualizacion de la vista de solicitudes
                    // pendientes
                    notificationsListener.onNewRequest();
                    break;
                case NotificationListener.NOTIFICATION_REQUEST_CANCEL:
                    // Solicitamos una actualizacion de la vista de solicitudes
                    // pendientes
                    notificationsListener.onCancelAssistance();
                    break;
                default:
                    notificationsListener.onNotification(state,message);
                    break;
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
