package com.americanassist.proveedor.solution;

import static com.google.common.base.Preconditions.checkNotNull;

/**
 *
 * <p>Presentador de las caracteriticas del termino de asistencia.</p>
 */

public class SolutionPresenter implements SolutionContract.Presenter{

    private final SolutionContract.View mSolutionView;

    public SolutionPresenter(SolutionContract.View view) {
        mSolutionView = checkNotNull(view);
        mSolutionView.setPresenter(this);
    }
    @Override
    public void start() {

    }

    @Override
    public void updateAssistanceState(String state) {
       mSolutionView.displayState(state);
    }
}
