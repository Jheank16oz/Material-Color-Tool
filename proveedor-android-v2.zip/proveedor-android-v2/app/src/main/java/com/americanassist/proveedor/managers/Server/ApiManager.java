package com.americanassist.proveedor.managers.Server;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.americanassist.proveedor.BuildConfig;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.AditionalInfo;
import com.americanassist.proveedor.model.Assistance;
import com.americanassist.proveedor.model.Cost;
import com.americanassist.proveedor.model.JustificationRejection;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.model.Question;
import com.americanassist.proveedor.model.RequestAssistance;
import com.americanassist.proveedor.model.Service;
import com.americanassist.proveedor.utils.ApiRest;
import com.americanassist.proveedor.utils.ConfigApp;
import com.americanassist.proveedor.utils.ConfigManager;
import com.google.gson.Gson;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.apache.http.Header;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;

public class ApiManager {

    private final MediaType MEDIA_TYPE_IMAGE = MediaType.parse("image/*");
    private HttpController httpController;
    private Context context;

    public ApiManager(Context context) {
        this.context = context;
        this.httpController = new HttpController();
    }

    public void logout(String token, String country, final ApiManagerHelper.ApiLogoutCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "logout/";

        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("token", token)
                .appendQueryParameter("country", country);
        String query = builder.build().getEncodedQuery();

        new PostTask(url, httpController, query, new ApiManagerHelper.PostTaskCallback() {
            @Override
            public void onSuccess(final String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (error) {
                        callback.onLogoutError(json.getString("mensaje"));
                    } else {
                        callback.onLogoutSuccess();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onLogoutError(result);
            }
        }).execute(true);
    }

    public void getTelephone(String country, final ApiManagerHelper.ApiGetTelephoneCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "obtener_numero_call_center?" + "country=" + country + "&tipo_usuario=PROV";

        new GetTask(url, httpController, new ApiManagerHelper.GetTaskCallback() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (error) {
                        callback.onGetTelephoneError(json.getString("mensaje"));
                    } else {
                        callback.onGetTelephoneSuccess(json.getString("numero"));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onGetTelephoneError(result);
            }
        }).execute(true);
    }

    public void getAvailableAssistances(String country, String idProvider, String idContact, double latitude, double longitude, final int page, final ApiManagerHelper.ApiGetAvailableAssistancesCallback callback) {

        String url = ConfigApp.getUrlServer(context) + "asistencias_disponibles_proveedor?" + "country=" + country + "&idproveedor=" + idProvider + "&idcontacto=" + idContact + "&paginador=" + page + "&latitud=" + latitude + "&longitud=" + longitude;
        new GetTask(url, httpController, new ApiManagerHelper.GetTaskCallback() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    Log.e("result assistance",json.toString());
                    if (error) {
                        callback.onGetAvailableAssistancesError(json.getString("mensaje"));
                    } else {

                        ArrayList<RequestAssistance> assistances = new ArrayList<>();
                        if (json.has("asistencia") && !json.isNull("asistencia")) {
                            JSONArray jsonArray = json.getJSONArray("asistencia");
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject assistanceJSON = jsonArray.getJSONObject(i);
                                if (json.has("estado")) {
                                    assistanceJSON.put("estado", json.getString("estado"));
                                }
                                assistances.add(RequestAssistance.getAvailableAssistanceFromJson(assistanceJSON));
                            }
                            if (assistances.isEmpty()){
                                callback.onGetAvailableAssistancesFull();
                            }else {
                                int pagination = json.getInt("paginador");
                                callback.onGetAvailableAssistancesSuccess(assistances, pagination);
                            }
                        } else {
                            callback.onGetAvailableAssistancesError(json.getString("mensaje"));
                        }


                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onGetAvailableAssistancesError(result);
            }
        }).execute(true);
    }

    public void acceptAssistance(String country, String idAssistance, String idProvider, String idContact, double latitude, double longitude, String idService, String acceptNext, final ApiManagerHelper.ApiAcceptAssistanceCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "aceptar_asistencia/";

        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("country", country)
                .appendQueryParameter("idasistencia", idAssistance)
                .appendQueryParameter("idproveedor", idProvider)
                .appendQueryParameter("idcontacto", idContact)
                .appendQueryParameter("latitud", String.valueOf(latitude))
                .appendQueryParameter("longitud", String.valueOf(longitude))
                .appendQueryParameter("idservicio", idService)
                .appendQueryParameter("aceptar_siguiente", acceptNext);

        String query = builder.build().getEncodedQuery();

        Log.e("ur",url);
        Log.e("ur",query);

        new PostTask(url, httpController, query, new ApiManagerHelper.PostTaskCallback() {
            @Override
            public void onSuccess(final String result) {

                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (error) {
                        callback.onAcceptAssistanceError(json.getString("mensaje"));
                    } else {

                        String distance = json.getString("distancia");
                        String showCostsString = json.getString("mostrar_costos");
                        boolean showCosts = (showCostsString.equals("1"));
                        String costs = null;
                        if (showCosts){
                            costs = json.getString("costos");
                        }

                        callback.onAcceptAssistanceSuccess(showCosts, costs, json.getString("ruta"), json.getString("ruta2"), distance);

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onAcceptAssistanceError(result);
            }
        }).execute(true);
    }


    public void rejectAssistance(String idAssistance,
                                 String idProvider,
                                 String idContact,
                                 String country,
                                 String reason,
                                 final ApiManagerHelper.ApiRejectAssistanceCallback callback)
    {
        String url = ConfigApp.getUrlServer(context)  + "rechazar_asistencia/";

        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("idasistencia", idAssistance)
                .appendQueryParameter("idproveedor", idProvider)
                .appendQueryParameter("idcontacto", idContact)
                .appendQueryParameter("country", country)
                .appendQueryParameter("motivo", reason);
        String query = builder.build().getEncodedQuery();


        new PostTask(url, httpController, query, new ApiManagerHelper.PostTaskCallback()
        {
            @Override
            public void onSuccess(final String result)
            {

                try
                {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (error)
                    {
                        callback.onRejectAssistanceError(json.getString("mensaje"));
                    }
                    else
                    {
                        callback.onRejectAssistanceSuccess();
                    }

                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result)
            {
                callback.onRejectAssistanceError(result);
            }
        }).execute(true);
    }

    public void reprogramAssistance(String idAssistance, String idProvider, String idContact, String country, String reason, String minutes, final ApiManagerHelper.ApiReprogramAssistanceCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "reprogramar_tiempos/";

        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("idasistencia", idAssistance)
                .appendQueryParameter("idproveedor", idProvider)
                .appendQueryParameter("idcontacto", idContact)
                .appendQueryParameter("prioridad", "EME")
                .appendQueryParameter("minutos", minutes)
                .appendQueryParameter("country", country)
                .appendQueryParameter("motivo", reason);
        String query = builder.build().getEncodedQuery();

        new PostTask(url, httpController, query, new ApiManagerHelper.PostTaskCallback() {
            @Override
            public void onSuccess(final String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (error) {
                        callback.onReprogramAssistanceError(json.getString("mensaje"));
                    } else {
                        callback.onReprogramAssistanceSuccess();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onReprogramAssistanceError(result);
            }
        }).execute(true);
    }

    public void cancelAssistance(String idAssistance, String idProvider, String idContact, String country, String reason, final ApiManagerHelper.ApiCancelAssistanceCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "cancelacion_asistencia_prov/";

        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("idasistencia", idAssistance)
                .appendQueryParameter("idproveedor", idProvider)
                .appendQueryParameter("idcontacto", idContact)
                .appendQueryParameter("country", country)
                .appendQueryParameter("motivo", reason);
        String query = builder.build().getEncodedQuery();

        new PostTask(url, httpController, query, new ApiManagerHelper.PostTaskCallback() {
            @Override
            public void onSuccess(final String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (error) {
                        callback.onCancelAssistanceError(json.getString("mensaje"));
                    } else {
                        callback.onCancelAssistanceSuccess();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onCancelAssistanceError(result);
            }
        }).execute(true);
    }

    public void getProviderState(String idProvider, String idContact, String country, final ApiManagerHelper.ApiGetProviderStateCallback callback) {
        Provider mProvider = SharedPreferencesManager.getProvider(context);
        String url = ConfigApp.getUrlServer(context) + "estado_proveedor?" + "idproveedor=" + idProvider + "&idcontacto=" + idContact + "&country=" + country+"&token="+mProvider.token;
        Log.e("url",url);

        new GetTask(url, httpController, new ApiManagerHelper.GetTaskCallback() {
            @Override
            public void onSuccess(String result) {

                try {

                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (error) {
                        if(json.getString("estado").equals("desconectado")){
                            callback.onGetProviderStateError(json.getString("mensaje"), true);
                        }else {
                            callback.onGetProviderStateError(json.getString("mensaje"), false);
                        }

                    } else {
                        if (json.has("estado") &&
                                !json.getString("estado").equalsIgnoreCase("libre")) {

                            // Tiene una asistencia, si tiene una asistencia y no tiene datos de
                            // Assistance es posible que este en estado de aceptacion de costos por lo cual
                            // se asigna un nuevo jsoObject por defecto el cual contendra el
                            // el estado actual de la asistencia unicamente los demas valores se llenaran en
                            // el modelo.

                            JSONArray jsonArray = json.getJSONArray("datos_asistencia");
                            JSONObject assistanceJSON = null;
                            if (jsonArray.length()>0) {
                                assistanceJSON = jsonArray.getJSONObject(0);
                                assistanceJSON.put("estado", json.getString("estado"));
                            }else{
                                assistanceJSON = new JSONObject();
                                assistanceJSON.put("estado", json.getString("estado"));
                            }

                            callback.onGetProviderStateSuccess(Assistance.getCurrentAssistanceFromJson(assistanceJSON));

                        }else{
                            callback.onGetProviderStateSuccess(null);
                        }

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onGetProviderStateError(result, false);
            }
        }).execute(true);
    }

    public void confirmArribo(String idAssistance, String idProvider, String idContact, String country, final ApiManagerHelper.ApiConfirmArriboCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "arribo_proveedor/";

        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("idasistencia", idAssistance)
                .appendQueryParameter("idproveedor", idProvider)
                .appendQueryParameter("idcontacto", idContact)
                .appendQueryParameter("country", country);
        String query = builder.build().getEncodedQuery();

        new PostTask(url, httpController, query, new ApiManagerHelper.PostTaskCallback() {
            @Override
            public void onSuccess(final String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (error) {
                        callback.onConfirmArriboError(json.getString("mensaje"));
                    } else {
                        callback.onConfirmArriboSuccess();
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onConfirmArriboError(result);
            }
        }).execute(true);
    }

    public void getQuestions(String idAssistance, String country, final ApiManagerHelper.ApiGetQuestionsCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "obtener_preguntas_diagnostico?" + "idasistencia=" + idAssistance + "&country=" + country;

        new GetTask(url, httpController, new ApiManagerHelper.GetTaskCallback() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (error) {
                        callback.onGetQuestionsError(json.getString("mensaje"));
                    } else {
                        int showCosts = json.getInt("mostrar_costos");
                        int showManeuvers = json.getInt("mostrar_boton_maniobras");
                        if (showCosts == 1 || showManeuvers == 1){
                            callback.onGetQuestionsSuccess(showCosts, showManeuvers, null);
                        }
                        else{
                            callback.onGetQuestionsSuccess(showCosts, showManeuvers, Question.getQuestionsFromJson(json));
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onGetQuestionsError(result);
            }
        }).execute(true);
    }

    public void sendLocation(String idProvider, String idContact, double latitude, double longitude, String country, boolean wasFromTime, final ApiManagerHelper.ApiSendLocationCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "coordenadas_proveedor/";

        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("idproveedor", idProvider)
                .appendQueryParameter("idcontacto", idContact)
                .appendQueryParameter("latitud", String.valueOf(latitude))
                .appendQueryParameter("longitud", String.valueOf(longitude))
                .appendQueryParameter("country", country)
                .appendQueryParameter("SO", "Android")
                .appendQueryParameter("date", new Date().toString());

        if (wasFromTime) {
            builder.appendQueryParameter("tiempo_necesaria", "¡Coordenada necesaria!");
        }

        String query = builder.build().getEncodedQuery();

        new PostTask(url, httpController, query, new ApiManagerHelper.PostTaskCallback() {
            @Override
            public void onSuccess(final String result) {
                try {

                    JSONObject json = new JSONObject(result);

                    boolean error = Boolean.parseBoolean(json.getString("error"));
                    int assistanceId = json.getInt("idasistencia");

                    if (!error) {
                        callback.onSendLocationSuccess(json.getInt("confirmar_arribo")!= 0, json.getInt("diagnostico")!= 0, json.getInt("termino_servicio")!= 0,assistanceId!=0,json.getString("estado_coordenadas"));
                    } else {
                        callback.onSendLocationError(json.getString("mensaje"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onSendLocationError(result);
            }
        }).execute(true);
    }

    public void getAditionalInfoForAssistance(String idAssistance, String country, String providerId, String contactId, final ApiManagerHelper.ApiGetAditionalInfoCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "informacion_adicional_asistencia?" + "idasistencia=" + idAssistance + "&country=" + country+"" +
                "&idproveedor=" + providerId+"&idcontacto="+contactId;

        new GetTask(url, httpController, new ApiManagerHelper.GetTaskCallback() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (error) {
                        callback.onGetAditionalInfoError(json.getString("mensaje"));
                    } else {
                        callback.onGetAditionalInfoSuccess(AditionalInfo.getAditionalInfosFromJson(json.getJSONArray("asistencia")));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onGetAditionalInfoError(result);
            }
        }).execute(true);
    }

    public void sendAnswers(final String idAssistance, final String country, final String answers, final ArrayList<File> pictures, final String idProvider, final String idContact, final ApiManagerHelper.ApiSendAnswersCallback callback) {
        AsyncTask.execute(() -> {
            String url = BuildConfig.URL_SERVER + "cobertura_servicio/";
            try {
                MultipartBody.Builder builder = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("idasistencia", idAssistance)
                        .addFormDataPart("idproveedor", idProvider)
                        .addFormDataPart("idcontacto", idContact)
                        .addFormDataPart("country", country)
                        .addFormDataPart("respuestas", answers);

                for (int i=0; i<pictures.size(); i++) {
                    File picture = pictures.get(i);
                    if (picture!=null) {
                        builder.addFormDataPart("fotos[" + i + "]", picture.getName(), RequestBody.create(MEDIA_TYPE_IMAGE, picture));

                    }
                }

                RequestBody requestBody = builder.build();

                Request request = new Request.Builder()
                        .url(url)
                        .post(requestBody)
                        .build();

                OkHttpClient client = new OkHttpClient();
                okhttp3.Response response = client.newCall(request).execute();

                try {
                    final JSONObject json = new JSONObject(response.body().string());
                    boolean error = Boolean.parseBoolean(json.getString("error"));
                    final int showManeuvers = json.getInt("mostrar_boton_maniobras");
                    if (!error) {
                        new Handler(Looper.getMainLooper()).post(() -> callback.onSendAnswersSuccess(showManeuvers));
                    } else {
                        new Handler(Looper.getMainLooper()).post(() -> {
                            try {
                                callback.onSendAnswersError(json.getString("mensaje"));
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        });
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public void sendAnswersSolution(final String idAssistance, final String country, final String answers, final ArrayList<File> pictures, final String idProvider, final String idContact, final ApiManagerHelper.ApiSendAnswersSolutionCallback callback) {
        AsyncTask.execute(() -> {
            String url = ConfigApp.getUrlServer(context) + "finalizar_servicio/";
            try {
                MultipartBody.Builder builder = new MultipartBody.Builder()
                        .setType(MultipartBody.FORM)
                        .addFormDataPart("idasistencia", idAssistance)
                        .addFormDataPart("idproveedor", idProvider)
                        .addFormDataPart("idcontacto", idContact)
                        .addFormDataPart("country", country)
                        .addFormDataPart("respuestas", answers);

                for (int i=0; i<pictures.size(); i++) {
                    File picture = pictures.get(i);
                    if (picture!=null) {
                        builder.addFormDataPart("fotos[" + i + "]", picture.getName(), RequestBody.create(MEDIA_TYPE_IMAGE, picture));
                    }
                }

                RequestBody requestBody = builder.build();

                Request request = new Request.Builder()
                        .url(url)
                        .post(requestBody)
                        .build();

                OkHttpClient client = new OkHttpClient();
                okhttp3.Response response = client.newCall(request).execute();

                try {
                    final JSONObject json = new JSONObject(response.body().string());
                    boolean error = Boolean.parseBoolean(json.getString("error"));
                    if (!error) {
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    callback.onSendAnswersSuccess(json.getString("mensaje"));
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    } else {
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    callback.onSendAnswersError(json.getString("mensaje"));
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public void getListCosts(String idProvider, String country, String idService, String idAssistance, final ApiManagerHelper.ApiGetListCostsCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "lista_items_costos?" + "idproveedor=" + idProvider + "&country=" + country + "&idservicio=" + idService + "&idasistencia=" + idAssistance;

        new GetTask(url, httpController, new ApiManagerHelper.GetTaskCallback() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (error) {
                        callback.onGetListCostsError(json.getString("mensaje"));
                    } else {
                        callback.onGetListCostsSuccess(Cost.getListCostsFromJson(json.getJSONArray("info_adicional")));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onGetListCostsError(result);
            }
        }).execute(true);
    }

    public void sendCostsNormalAssistances(String idAssistance, String idProvider, String idContact, String country, String costs, final ApiManagerHelper.ApiSendCostCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "almacenar_costos/";

        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("idasistencia", idAssistance)
                .appendQueryParameter("idproveedor", idProvider)
                .appendQueryParameter("country", country)
                .appendQueryParameter("costos", costs)
                .appendQueryParameter("idcontacto", idContact);
        String query = builder.build().getEncodedQuery();

        new PostTask(url, httpController, query, new ApiManagerHelper.PostTaskCallback() {
            @Override
            public void onSuccess(final String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (!error) {
                        callback.onSendCostsSuccess(json.getInt("bloqueo_asistencia"));
                    } else {
                        callback.onSendCostsError(json.getString("mensaje"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onSendCostsError(result);
            }
        }).execute(true);
    }

    public void sendCostsAssistanceTowing(String country, String idAssistance, String idProvider, String idContact, double latitude, double longitude, String route, String route2, String costs, String distance, final ApiManagerHelper.ApiSendCostCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "validacion_costos/";

        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("country", country)
                .appendQueryParameter("idasistencia", idAssistance)
                .appendQueryParameter("idproveedor", idProvider)
                .appendQueryParameter("idcontacto", idContact)
                .appendQueryParameter("latitud", String.valueOf(latitude))
                .appendQueryParameter("longitud", String.valueOf(longitude))
                .appendQueryParameter("ruta", route)
                .appendQueryParameter("ruta2", route2)
                .appendQueryParameter("costos", costs)
                .appendQueryParameter("distancia", distance);

        String query = builder.build().getEncodedQuery();


        new PostTask(url, httpController, query, new ApiManagerHelper.PostTaskCallback() {
            @Override
            public void onSuccess(final String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (!error) {
                        callback.onSendCostsSuccess(json.getInt("bloqueo_asistencia"));
                    } else {
                        callback.onSendCostsError(json.getString("mensaje"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onSendCostsError(result);
            }
        }).execute(true);
    }


    public void confirmAndGetManeuvers(String country, String idAssistance, String idProvider, String idContact, int response, final ApiManagerHelper.ApiConfirmManeuversCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "confirmar_maniobras/";

        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("country", country)
                .appendQueryParameter("idasistencia", idAssistance)
                .appendQueryParameter("idproveedor", idProvider)
                .appendQueryParameter("idcontacto", idContact)
                .appendQueryParameter("respuesta", Integer.toString(response));

        String query = builder.build().getEncodedQuery();

        new PostTask(url, httpController, query, new ApiManagerHelper.PostTaskCallback() {
            @Override
            public void onSuccess(final String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (!error) {
                        callback.onConfirmManeuversSuccess(Cost.getListCostsFromJson(json.getJSONArray("info_adicional")));
                    } else {
                        callback.onConfirmManeuversError(json.getString("mensaje"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onConfirmManeuversError(result);
            }
        }).execute(true);
    }

    public void getListManeuvers(String country, String idProvider, String idContact, String idAssistance, final ApiManagerHelper.ApiGetListCostsCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "lista_items_maniobras?" + "country=" + country + "&idproveedor=" + idProvider + "&idcontacto=" + idContact + "&idasistencia=" + idAssistance;

        new GetTask(url, httpController, new ApiManagerHelper.GetTaskCallback() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (error) {
                        callback.onGetListCostsError(json.getString("mensaje"));
                    } else {
                        callback.onGetListCostsSuccess(Cost.getListCostsFromJson(json.getJSONArray("info_adicional")));
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onGetListCostsError(result);
            }
        }).execute(true);
    }

    public void sendManeuvers(String country, String idAssistance, String idProvider, String idContact, String costs, final ApiManagerHelper.ApiSendManeuversCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "almacenar_maniobras/";

        Uri.Builder builder = new Uri.Builder()
                .appendQueryParameter("country", country)
                .appendQueryParameter("idasistencia", idAssistance)
                .appendQueryParameter("idproveedor", idProvider)
                .appendQueryParameter("idcontacto", idContact)
                .appendQueryParameter("costos", costs);

        String query = builder.build().getEncodedQuery();

        new PostTask(url, httpController, query, new ApiManagerHelper.PostTaskCallback() {
            @Override
            public void onSuccess(final String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (!error) {
                        callback.onSendManeuversSuccess(json.getInt("bloqueo_asistencia"));
                    } else {
                        callback.onSendManeuversError(json.getString("mensaje"));
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onSendManeuversError(result);
            }
        }).execute(true);
    }



    public void getAvailableServices(String country,
                                     String idProvider,
                                     String idContact,
                                     double latitude,
                                     double longitude,
                                     int page,
                                     final ApiManagerHelper.ApiGetAvailableServicesCallback callback)
    {
        String url = ConfigApp.getUrlServer(context) + "listar_servicios_proveedor?" + "country=" + country + "&idproveedor=" + idProvider + "&idcontacto=" + idContact + "&paginador=" + page + "&latitud=" + latitude + "&longitud=" + longitude;

        new GetTask(url, httpController, new ApiManagerHelper.GetTaskCallback()
        {
            @Override
            public void onSuccess(String result)
            {
                Gson gson = new Gson();

                try
                {
                    JSONObject jsonObject = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(jsonObject.getString("error"));

                    if(error)
                    {
                        callback.onGetAvailableServicesError(jsonObject.getString("mensaje"));
                    }
                    else
                    {
                        ArrayList<Service> services = new ArrayList<>();
                        if (jsonObject.has("asistencias") && !jsonObject.isNull("asistencias"))
                        {
                            JSONArray jsonArray = jsonObject.getJSONArray("asistencias");
                            for (int i = 0 ; i < jsonArray.length(); i++)
                            {
                                JSONObject servicesObjects = jsonArray.getJSONObject(i);

                                if(jsonObject.has("estado"))
                                {
                                    servicesObjects.put("estado", jsonObject.getString("estado"));
                                }

                                Service service = gson.fromJson(servicesObjects.toString(),Service.class);
                                services.add(service);
                            }
                            callback.onGetAvailableServicesSuccess(services);

                        }
                        else
                        {
                            callback.onGetAvailableServicesSuccess(new ArrayList<Service>());
                        }
                    }
                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result)
            {
                callback.onGetAvailableServicesError(result);
            }

        }).execute(true);
    }

    public void getSolutionQuestions(String idAssistance, String country, final ApiManagerHelper.ApiGetQuestionSolutionsCallback callback) {
        String url = ConfigApp.getUrlServer(context) + "obtener_preguntas_termino_servicio/?" + "idasistencia=" + idAssistance + "&country=" + country;

        new GetTask(url, httpController, new ApiManagerHelper.GetTaskCallback() {
            @Override
            public void onSuccess(String result) {
                try {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (error) {
                        callback.onGetQuestionsError(json.getString("mensaje"));
                    } else {
                        callback.onGetQuestionsSuccess(Question.getQuestionsFromJson(json));

                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result) {
                callback.onGetQuestionsError(result);
            }
        }).execute(true);
    }



    /**Para a nueva funcionalidad del rechazo de un servicio
     * @param country
     * @param callback
     */
    public void getJustificationRejectionService(String country, final ApiManagerHelper.ApiGetJustificationRejectionServiceCallback callback)
    {
        String url = ConfigApp.getUrlServer(context) + "obtener_justificaciones_proveedor?" + "country=" + country;

        new GetTask(url, httpController, new ApiManagerHelper.GetTaskCallback()
        {
            @Override
            public void onSuccess(String result)
            {
                try
                {
                    JSONObject json = new JSONObject(result);
                    boolean error = Boolean.parseBoolean(json.getString("error"));

                    if (error)
                    {
                        callback.onGetGetJustificationRejectionServiceError(json.getString("mensaje"));
                    }
                    else
                    {
                        ArrayList<JustificationRejection> justificationRejections = new ArrayList();
                        //if (json.has("justificaciones") && !json.isNull("justificaciones"))
                        //{

                        JSONArray jsonArray = json.getJSONArray("justificaciones");
                        for (int i = 0; i < jsonArray.length(); i++)
                        {
                            JSONObject justificationRejectionsServiceJSON = jsonArray.getJSONObject(i);

                            justificationRejections.add(JustificationRejection.getJustificationFromJson(justificationRejectionsServiceJSON));

                        }
                        callback.onGetGetJustificationRejectionServiceSuccess(justificationRejections);

                    }

                }
                catch (JSONException e)
                {
                    e.printStackTrace();
                }
            }

            @Override
            public void onError(String result)
            {
                callback.onGetGetJustificationRejectionServiceError(result);
            }
        }).execute(true);
    }


    /**
     * Metodo encargado de obtener las configuracione de la app
     * @param country pais donde se obtienen las configuracions
     * @param mConfigurationCallback callback para hacer seguimiento de configuraciones
     */
    public void getConfigurations(String country, final ApiManagerHelper.GetConfigurationCallback mConfigurationCallback){
        final String url = "configuraciones_app_proveedor?dispositivo=android&version="+ BuildConfig.VERSION_NAME+"&idpais="+country;

        new ApiRest(context).get(url,new RequestParams(),new JsonHttpResponseHandler(){
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                super.onSuccess(statusCode, headers, response);

                Log.e("response conf",response.toString());
                // ejecutamos las configuraciones
                new ConfigManager(context,mConfigurationCallback).configureAppFromJsonResponse(response);
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                super.onFailure(statusCode, headers, throwable, errorResponse);
                throwable.printStackTrace();
                mConfigurationCallback.onFailureConfigurationLoaded();
            }

            @Override
            public void onFailure(int statusCode, Header[] headers, String responseString, Throwable throwable) {
                super.onFailure(statusCode, headers, responseString, throwable);
                throwable.printStackTrace();
                mConfigurationCallback.onFailureConfigurationLoaded();

            }
        });
    }
}
