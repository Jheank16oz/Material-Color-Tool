package com.americanassist.proveedor.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

public class Cost {

    public String id;
    public String description;
    public double amount;
    public boolean editable;

    public boolean checked = false;

    public static ArrayList<Cost> getListCostsFromJson(JSONArray jsonArray){
        ArrayList<Cost> costs = new ArrayList<>();
        if (jsonArray !=null ) {
            for (int i = 0; i < jsonArray.length(); i++) {
                try {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    Cost cost = new Cost();
                    cost.id = jsonObject.getString("idcosto");
                    cost.description = jsonObject.getString("descripcion");
                    cost.amount = jsonObject.getDouble("monto");
                    cost.editable = jsonObject.getBoolean("editable");
                    costs.add(cost);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }
        return costs;
    }
}
