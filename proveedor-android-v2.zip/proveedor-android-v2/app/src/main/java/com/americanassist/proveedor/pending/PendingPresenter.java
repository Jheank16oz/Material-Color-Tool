package com.americanassist.proveedor.pending;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Toast;

import com.americanassist.proveedor.DrawerActivity;
import com.americanassist.proveedor.R;
import com.americanassist.proveedor.adapters.PendingAssistanceAdapter;
import com.americanassist.proveedor.connection.modelRepository.UserRepository;
import com.americanassist.proveedor.cranecost.CraneCostFragment;
import com.americanassist.proveedor.managers.Server.ApiManager;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.Assistance;
import com.americanassist.proveedor.model.InactivtyJustification;
import com.americanassist.proveedor.model.Justification;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.model.RequestAssistance;
import com.google.android.gms.maps.model.LatLng;
import java.util.ArrayList;
import java.util.List;

import static com.americanassist.proveedor.BaseApplication.getInstance;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 *
 *
 * Presentador de las caracteristicas de las asistencias pendientes del proveedor
 */

public class PendingPresenter implements PendingContract.Presenter {

    private static final int PAGE_SIZE = 5;
    private final PendingContract.View mPendingView;
    private Context mContext;
    private int pagination;
    private boolean isLastPage = false;
    private boolean isLoading = false;
    private boolean isStarted;
    private UserRepository mUserRepository;
    private boolean userInactive = true;
    private int positionInactiveSelected = 0;


    public PendingPresenter(PendingContract.View view, Context context) {
        mPendingView = checkNotNull(view);
        mPendingView.setPresenter(this);
        mContext = context;
        mUserRepository = new UserRepository(context);
    }
    @Override
    public void start() {
        if (!isStarted) {
            isStarted = true;
            loadMoreData();
        }

    }

    @Override
    public void validateUserActivity(boolean inactivity) {
        if (!inactivity){
            sendUserActive();
            return;
        }

        mPendingView.setLoading(true);
        mUserRepository.getInactivityJustifications(new ApiManagerHelper.GetInactivityJustificationCallback() {
            @Override
            public void onSuccess(InactivtyJustification inactivtyJustification) {

                List<Justification> justifications = inactivtyJustification.justifications;
                CharSequence[] justificationsCharSequence = new CharSequence[justifications.size()];
                for (int i = 0; i < justifications.size(); i++) {
                    justificationsCharSequence[i] = justifications.get(i).toString();
                }

                mPendingView.displayInactivityOptions(justificationsCharSequence, (dialogInterface, i) -> {
                    positionInactiveSelected = i;
                }, (dialogInterface, i) -> {
                    sendUserInactive(justifications.get(positionInactiveSelected).justificationId);
                });
            }

            @Override
            public void onFailure() {
                // ignore
            }

            @Override
            public void onJustificationEmpty(String message) {
                mPendingView.displayMessage(message);
            }
        });
    }


    /**
     * Carga la lista de asistencias pendientes usando paginacion,
     */
    @Override
    public void loadMoreData() {

        if (userInactive){
            return;
        }

        Provider mProvider = SharedPreferencesManager.getProvider(mContext);
        if (mProvider == null){
            return;
        }

        LatLng mCurrentLocation = getInstance().getCurrentLocation();
        if (mCurrentLocation == null){
            mPendingView.displayMessage("No poseemos su ubicación, verifique si el gps esta activado.");
            return;
        }

        mPendingView.addFooter();

        new ApiManager(mContext).getAvailableAssistances(mProvider.country, mProvider.idProvider, mProvider.idContact, mCurrentLocation.latitude, mCurrentLocation.longitude, pagination, new ApiManagerHelper.ApiGetAvailableAssistancesCallback() {
            @Override
            public void onGetAvailableAssistancesSuccess(ArrayList<RequestAssistance> assistances, int pagination) {
                mPendingView.removeFooter();

                if (assistances != null) {
                    if(assistances.size()>0)
                        mPendingView.loadData(assistances);

                    if (assistances.size() >= PAGE_SIZE) {
                        mPendingView.addFooter();
                    } else {
                        isLastPage = true;
                        mPendingView.displayMessage(mContext.getString(R.string.no_mas_asistencias_disponibles));
                    }
                }

                isLoading = false;
                PendingPresenter.this.pagination = pagination;
                mPendingView.validateEmptyState();
            }

            @Override
            public void onGetAvailableAssistancesError(String error) {
                mPendingView.updateFooter(PendingAssistanceAdapter.FooterType.ERROR);
                isLoading = false;
                isLastPage = true;
            }

            /**
             * Notifica que se han consultado todas las asistencias disponibles
             */
            @Override
            public void onGetAvailableAssistancesFull() {
                mPendingView.removeFooter();
                isLastPage = true;
                isLoading = false;
                if (mPendingView.validateEmptyState()){
                    mPendingView.displayMessage(mContext.getString(R.string.no_mas_asistencias_disponibles));
                }

            }
        });
    }

    /**
     * Proceso de asignación de asistencia al proveedor
     * @param assistanceId id de la asistencia seleccionada
     * @param serviceId id del servicio vinculado a la asistencia
     * @param response respuesta al aceptar la asistencia
     */
    @Override
    public void acceptAssistance(String assistanceId, String serviceId, String response) {

        Provider mProvider = SharedPreferencesManager.getProvider(mContext);
        if (mProvider == null){
            return;
        }

        LatLng mCurrentLocation = getInstance().getCurrentLocation();
        if (mCurrentLocation == null){
            mPendingView.displayMessage("No poseemos su ubicación, verifique si el gps esta activado.");
            return;
        }

        mPendingView.setLoading(true);
        new ApiManager(mContext).acceptAssistance(
                mProvider.country,
                assistanceId, mProvider.idProvider,
                mProvider.idContact,
                mCurrentLocation.latitude,
                mCurrentLocation.longitude, serviceId,
                response, new ApiManagerHelper.ApiAcceptAssistanceCallback() {

                    @Override
                    public void onAcceptAssistanceSuccess(boolean showCosts, String costs, String route1, String route2, String distance) {
                        mPendingView.setLoading(false);

                        // Si hay que mostrar costos: estamos en una asistencia de grua: vamos a los costos
                        if (showCosts) {

                            Bundle i = new Bundle();
                            i.putString(CraneCostFragment.ASSISTANCE_ID, assistanceId);
                            i.putString(CraneCostFragment.ASSISTANCE_ROUTE1, route1);
                            i.putString(CraneCostFragment.ASSISTANCE_ROUTE2, route2);
                            i.putString(CraneCostFragment.COSTS, costs);
                            i.putString(CraneCostFragment.DISTANCE, distance);
                            mPendingView.displayCosts(i);
                        }
                        // Si no hay que mostrar costos: estamos en una asistencia normal, volvemos al mapa
                        else {
                            mPendingView.refreshState();
                        }
                    }

                    @Override
                    public void onAcceptAssistanceError(String error) {
                        mPendingView.setLoading(false);
                        mPendingView.displayMessage(error);
                    }
                });
    }

    @Override
    public void validateScrolled(int visibleItemCount, int firstVisibleItemPosition, int lastVisibleItemPosition) {
        if (isStarted) {
            if (!isLoading && !isLastPage) {
                if ((firstVisibleItemPosition + visibleItemCount) > pagination) {
                    if (firstVisibleItemPosition > 0) {
                        isLoading = true;
                        loadMoreData();
                    }
                }
            }
        }
    }

    @Override
    public void resetInformation() {
        if (isStarted && !isLoading) {
            mPendingView.resetList();
            pagination = 0;
            isLastPage = false;
            isLoading = true;
            loadMoreData();
        }
    }

    private void sendUserInactive(String justificationId) {
        mPendingView.setLoading(true);

            mUserRepository.sendInactive(justificationId, new ApiManagerHelper.ProviderRegisterCallback() {
                @Override
                public void onSuccess(String message) {
                    mPendingView.displayMessage(message);
                    mPendingView.setLoading(false);
                    mPendingView.displayInactiveState(true);
                    mPendingView.inactiveUpdate();
                    userInactive = true;
                }

                @Override
                public void onFailure() {
                    mPendingView.setLoading(false);
                }
            });
    }

    private void sendUserActive(){
        mPendingView.setLoading(true);

        mUserRepository.sendActive(new ApiManagerHelper.ProviderRegisterCallback() {
            @Override
            public void onSuccess(String message) {
                mPendingView.displayMessage(message);
                mPendingView.setLoading(false);
                mPendingView.displayInactiveState(false);
                mPendingView.inactiveUpdate();

                userInactive = false;
                isLoading = false;
                resetInformation();
            }

            @Override
            public void onFailure() {
                mPendingView.setLoading(false);
            }
        });
    }

    @Override
    public void updateUserState(Assistance assistance) {
        if (assistance!=null && assistance.estado.equalsIgnoreCase(DrawerActivity.USER_INACTIVE)){
                mPendingView.displayInactiveState(true);
                mPendingView.checkActive(true);
                userInactive = true;
        }else{
            mPendingView.checkActive(false);
            userInactive = false;
        }

        mPendingView.initializeActiveCheckedListener();
    }



}
