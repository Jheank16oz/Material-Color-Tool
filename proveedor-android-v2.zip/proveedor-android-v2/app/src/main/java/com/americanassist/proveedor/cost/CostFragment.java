package com.americanassist.proveedor.cost;

import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.americanassist.proveedor.DrawerActivity;
import com.americanassist.proveedor.R;
import com.americanassist.proveedor.adapters.CostsAdapter;
import com.americanassist.proveedor.dialogs.ErrorDialog;
import com.americanassist.proveedor.managers.Server.ApiManager;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.Assistance;
import com.americanassist.proveedor.model.Cost;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.utils.Functions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import static com.americanassist.proveedor.services.SocketEvents.NotificationListener.*;

/**
 * Created by ICATECH on 23/03/18.
 *
 * <p>Vistas de costos Normales muestra la lista de
 * informacion de costos posibles.</p>
 *
 */

public class CostFragment extends Fragment implements CostsAdapter.CostsAdapterCallback, CostContract.View{


    private TextView txtTotal;

    private Context mContext;
    protected LinearLayoutManager llm;
    private CostsAdapter costsAdapter;
    private ErrorDialog errorDialog;




    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.cost_fragment, container, false);
        initializeComponents(view);
        return view;
    }

    private void initializeComponents(View view) {
        mContext = getContext();
        RecyclerView recyclerCosts = view.findViewById(R.id.AC_recyclerview_listcosts);
        txtTotal = view.findViewById(R.id.AC_textview_total);
        view.findViewById(R.id.send).setOnClickListener(v -> onButSendClicked());

        llm = new LinearLayoutManager(getContext());
        recyclerCosts.setLayoutManager(llm);
        costsAdapter = new CostsAdapter(getContext(), this);
        recyclerCosts.setAdapter(costsAdapter);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerCosts.getContext(),
                new LinearLayoutManager(getActivity()).getOrientation());
        recyclerCosts.addItemDecoration(dividerItemDecoration);

        Provider mProvider = SharedPreferencesManager.getProvider(getContext());
        txtTotal.setVisibility(View.GONE);

        if (mProvider != null) {
            getCosts(mProvider);
        }

    }

    /**
     * trae la lista de costos
     * @param mProvider contiene la informacion del proveedor
     * este es obtenido de preferencias
     */
    public void getCosts(@NonNull Provider mProvider){
        if (getActivity() == null) {
            return;
        }

        if (Functions.checkInternetConnection(mContext)) {
            return;
        }

        ((DrawerActivity)getActivity()).showLoadingView();
        Assistance mAssistance = ((DrawerActivity)getActivity()).getAssistance();

        if (mAssistance == null){
            Toast.makeText(getContext(), R.string.intentalo_mas_tarde, Toast.LENGTH_SHORT).show();
            return;
        }
        new ApiManager(mContext).getListCosts(mProvider.idProvider, mProvider.country, mAssistance.serviceId, mAssistance.id, new ApiManagerHelper.ApiGetListCostsCallback() {
            @Override
            public void onGetListCostsSuccess(ArrayList<Cost> costs) {
                ((DrawerActivity)getActivity()).hideLoadingView();
                txtTotal.setVisibility(View.VISIBLE);
                costsAdapter.addCosts(costs);
                calculateTotalAmount();
            }

            @Override
            public void onGetListCostsError(String error) {
                ((DrawerActivity)getActivity()).hideLoadingView();
                new ErrorDialog(mContext, error).show();
            }
        });
    }

    /**
     * Calcula el total de costos ingresado
     */
    private void calculateTotalAmount() {
        double total = 0.0;
        for (int i = 0; i < costsAdapter.mData.size(); i++) {
            if (costsAdapter.mData.get(i).checked) {
                total += costsAdapter.mData.get(i).amount;
            }
        }
        txtTotal.setText(String.format("%.2f", total));
    }

    @Override
    public void onEditChanged() {
        calculateTotalAmount();
    }

    /**
     * Ejecuta el envio de costos
     */
    public void onButSendClicked() {
        Provider mProvider = SharedPreferencesManager.getProvider(getContext());
        if (mProvider != null) {
            sendCosts(mProvider);
        }

    }

    /**
     * Gestiona el envio de costos desde la api
     * @param provider Provider obtenido desde el login
     */
    public void sendCosts(@NonNull Provider provider){
        if (getActivity() == null) {
            return;
        }

        if (Functions.checkInternetConnection(mContext)) {
            return;
        }

        ((DrawerActivity)getActivity()).showLoadingView();
        Assistance mAssistance = ((DrawerActivity)getActivity()).getAssistance();
        if (mAssistance == null){
            Toast.makeText(getContext(), R.string.intentalo_mas_tarde, Toast.LENGTH_SHORT).show();
            return;
        }

        new ApiManager(mContext).sendCostsNormalAssistances(mAssistance.id, provider.idProvider, provider.idContact, provider.country, generateJsonFromCosts(), new ApiManagerHelper.ApiSendCostCallback() {
            @Override
            public void onSendCostsSuccess(int block) {
                ((DrawerActivity)getActivity()).hideLoadingView();
                // Enviamos al mapa para que se actualize el estado y el defina la vista a la cual
                // continuar.
                ((DrawerActivity)getActivity()).setFragment(DrawerActivity.MAP_FRAGMENT);

            }

            @Override
            public void onSendCostsError(String error) {
                ((DrawerActivity)getActivity()).hideLoadingView();
                errorDialog = new ErrorDialog(mContext, error);
                errorDialog.show();
                errorDialog.setCancelable(false);
                errorDialog.setCanceledOnTouchOutside(true);
                errorDialog.setOnCancelListener(dialog -> ((DrawerActivity)getActivity()).setFragment(DrawerActivity.MAP_FRAGMENT));
            }
        });
    }

    /**
     * Se encarga de generar un Json con costos para el envio
     * al server.
     * @return Los costos en Formato JSON
     */
    private String generateJsonFromCosts() {
        JSONArray jsonArray = new JSONArray();
        for (int i = 0; i < costsAdapter.mData.size(); i++) {
            Cost cost = costsAdapter.mData.get(i);
            if (cost.checked) {
                JSONObject jsonObject = new JSONObject();
                try {
                    jsonObject.put("idcosto", cost.id);
                    jsonObject.put("value", cost.amount);
                    jsonObject.put("descripcion", cost.description);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                jsonArray.put(jsonObject);
            }
        }
        return jsonArray.toString();
    }

    @Override
    public void setPresenter(CostContract.Presenter presenter) {
        //ignored
    }

    @Override
    public void displayState(String state) {
        if (!isAdded()){
            return;
        }
        switch (state){
            case NOTIFICATION_ACCEPT_COSTS:
                // Quitamos popup
                ((DrawerActivity)getActivity()).displayWaiting(null,false);

                // Pasamos a pantalla de termino
                //Intent i = new Intent(CostsActivity.this, FaultSolutionActivity.class);
                //startActivity(i);
                ((DrawerActivity)getActivity()).setFragment(DrawerActivity.SOLUTION_FRAGMENT);
                break;
            case NOTIFICATION_TYPE_CANCEL:
                ((DrawerActivity)getActivity()).displayWaiting(null,false);
                errorDialog = new ErrorDialog(mContext, "Su asistencia ha sido cancelada por el cliente");
                errorDialog.show();
                errorDialog.setCancelable(false);
                errorDialog.setCanceledOnTouchOutside(true);
                errorDialog.setOnCancelListener(dialog -> {
                    // Volvemos al mapa
                    // finish();
                    ((DrawerActivity)getActivity()).setFragment(DrawerActivity.MAP_FRAGMENT);
                });
                break;
            case NOTIFICATION_ACCEPT_COSTS_TOWING:
                // Quitamos popup
                ((DrawerActivity)getActivity()).displayWaiting(null,false);
                // Volvemos al mapa
                //finish();
                ((DrawerActivity)getActivity()).setFragment(DrawerActivity.MAP_FRAGMENT);
                break;
            case NOTIFICATION_ACCEPT_MANEUVER:

                // Quitamos popup
                ((DrawerActivity)getActivity()).displayWaiting(null,false);
                // Volvemos al mapa
                ((DrawerActivity)getActivity()).setFragment(DrawerActivity.MAP_FRAGMENT);
                break;

        }
    }
}
