package com.americanassist.proveedor.model;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;



public class Service implements Parcelable {

    @SerializedName("idasistencia")
    @Expose
    public String id;

    @SerializedName("fecha_solicitud")
    @Expose
    public String dateOfService;

    @SerializedName("descripcion_servicio")
    @Expose
    public String serviceDescription;

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
        dest.writeString(this.dateOfService);
        dest.writeString(this.serviceDescription);
    }

    public Service() {
    }

    protected Service(Parcel in) {
        this.id = in.readString();
        this.dateOfService = in.readString();
        this.serviceDescription = in.readString();
    }

    public static final Parcelable.Creator<Service> CREATOR = new Parcelable.Creator<Service>() {
        @Override
        public Service createFromParcel(Parcel source) {
            return new Service(source);
        }

        @Override
        public Service[] newArray(int size) {
            return new Service[size];
        }
    };
}
