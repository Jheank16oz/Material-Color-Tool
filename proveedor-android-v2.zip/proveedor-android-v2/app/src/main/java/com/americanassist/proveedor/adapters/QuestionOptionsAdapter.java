package com.americanassist.proveedor.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;
import com.americanassist.proveedor.model.QuestionOption;
import com.americanassist.proveedor.R;
import java.util.ArrayList;

/**
 * Adaptador para un item de pregunta de Tipo Opciones
 *
 */
public class QuestionOptionsAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private LayoutInflater mLayoutInflater;
    public ArrayList<QuestionOption> data = new ArrayList<>();
    private boolean onBind;


    QuestionOptionsAdapter(Context context) {
        mLayoutInflater = LayoutInflater.from(context);
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = mLayoutInflater.inflate(R.layout.card_question_option, parent, false);
        return new QuestionOptionsAdapter.OptionVH(v);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
        QuestionOption questionOption = data.get(position);
        ((OptionVH) holder).txtOption.setText(questionOption.questionName);
        ((OptionVH) holder).switchSelected.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(!onBind) {
                if (isChecked) {
                    data.get(position).checked = true;
                    for (int i=0; i<data.size(); i++){
                        if (i != position){
                            data.get(i).checked = false;
                        }
                    }
                    notifyDataSetChanged();
                }
            }

        });
        onBind = true;
        if (questionOption.checked){
            ((OptionVH) holder).switchSelected.setChecked(true);
        }
        else{
            ((OptionVH) holder).switchSelected.setChecked(false);
        }
        onBind = false;
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    @Override
    public int getItemViewType(int position) {
        return 0;
    }

    public void replaceAll(ArrayList<QuestionOption> questionOptions) {
        data.clear();
        this.data = questionOptions;
        notifyDataSetChanged();
    }

    class OptionVH extends RecyclerView.ViewHolder {
        TextView txtOption;
        Switch switchSelected;

        public OptionVH(View itemView) {
            super(itemView);
            txtOption = itemView.findViewById(R.id.CQO_textview_option);
            switchSelected = itemView.findViewById(R.id.CQO_switch_selected);
        }
    }
}

