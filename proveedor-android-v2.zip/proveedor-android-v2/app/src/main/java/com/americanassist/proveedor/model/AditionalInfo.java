package com.americanassist.proveedor.model;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;

public class AditionalInfo {

    public static final String TYPE_TEXT = "texto";
    public static final String TYPE_IMAGE = "imagen";
    public static final String TYPE_MAP = "mapa";

    public String title;
    public String response;
    public String type;
    public double latitude;
    public double longitude;

    /**
     * Devuelve la informacion adicional de una asistencia apartir de un JSONArray
     * @param jsonArray informacion adicional en Formato JSON
     * @return Lista de Informacion adicionla en POJO
     */
    public static ArrayList<AditionalInfo> getAditionalInfosFromJson(JSONArray jsonArray) {
        ArrayList<AditionalInfo> aditionalInfos = new ArrayList<>();
        for (int i=0; i<jsonArray.length(); i++){
            try {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                AditionalInfo aditionalInfo = new AditionalInfo();
                aditionalInfo.title = jsonObject.getString("titulo");
                aditionalInfo.response = jsonObject.getString("respuesta");
                aditionalInfo.type = jsonObject.getString("tipo");

                if(aditionalInfo.type.equals(TYPE_MAP)){
                    aditionalInfo.latitude = jsonObject.getDouble("latitud");
                    aditionalInfo.latitude = jsonObject.getDouble("longitud");
                }

                aditionalInfos.add(aditionalInfo);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return aditionalInfos;
    }
}
