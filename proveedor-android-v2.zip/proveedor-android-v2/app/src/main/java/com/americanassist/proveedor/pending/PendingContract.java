package com.americanassist.proveedor.pending;

import android.content.DialogInterface;
import android.os.Bundle;

import com.americanassist.proveedor.BasePresenter;
import com.americanassist.proveedor.BaseView;
import com.americanassist.proveedor.adapters.PendingAssistanceAdapter;
import com.americanassist.proveedor.model.Assistance;
import com.americanassist.proveedor.model.RequestAssistance;
import com.google.android.gms.maps.model.LatLng;

import java.util.ArrayList;

/**
 *
 * <p>Contrato del Presentador y Vista de las caracteristicas de asistencias pendientes de
 * proveedor</p>
 */

public interface PendingContract {

    interface View extends BaseView<PendingContract.Presenter> {
        void initializeActiveCheckedListener();
        void loadData(ArrayList<RequestAssistance> assistance);
        void setLoading(boolean isLoading);
        void displayMessage(String message);
        void updateFooter(PendingAssistanceAdapter.FooterType type);
        void removeFooter();
        void addFooter();
        void resetList();
        void displayCosts(Bundle data);
        void refreshState();
        boolean validateEmptyState();
        void displayInactiveState(boolean display);
        void checkActive(boolean b);
        void displayInactivityOptions(CharSequence[] justifications, DialogInterface.OnClickListener singleChoiceListener, DialogInterface.OnClickListener onPositiveClicked);
        void inactiveUpdate();
    }

    interface Presenter extends BasePresenter {
        void loadMoreData();
        void acceptAssistance(String assistanceId, String serviceId, String response);
        void validateScrolled(int visibleItemCount, int firstVisibleItemPosition, int lastVisibleItemPosition);
        void resetInformation();
        void updateUserState(Assistance assistance);
        void validateUserActivity(boolean inactivity);
    }
}
