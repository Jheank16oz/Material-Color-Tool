package com.americanassist.proveedor.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * <p>Justification</p>
 */
public class Justification {
    @SerializedName("idjustificacion")
    @Expose
    public String justificationId;
    @SerializedName("justificacion")
    @Expose
    public String justification;

    @Override
    public String toString() {
        return justification;
    }
}
