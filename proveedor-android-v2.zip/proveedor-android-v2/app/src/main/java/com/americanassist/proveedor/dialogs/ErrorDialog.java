package com.americanassist.proveedor.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import com.americanassist.proveedor.R;

/**
 * Dialogo de Errores, es utilizado solo en mensajes prioritarios como
 * por ejemplo el error de conexion.
 */
public class ErrorDialog extends Dialog {

    private String description;
    private boolean noImage;
    public ImageView imageView;
    public TextView mDescriptionTextView;
    public ErrorDialog(Context context, String description1) {
        super(context);
        this.description = description1;
        this.noImage = false;
    }

    public ErrorDialog(Context context, String description1, boolean noImage) {
        super(context);
        this.description = description1;
        this.noImage = noImage;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(
                new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        setContentView(R.layout.dialog_error);

        mDescriptionTextView = findViewById(R.id.DE_textview_description);
        mDescriptionTextView.setText(description);
        if (noImage) {
            findViewById(R.id.DE_imageview_picture).setVisibility(View.GONE);
        }


    }

    public void setDescription(String description){
        this.description = description;
        mDescriptionTextView.setText(description);
    }
}