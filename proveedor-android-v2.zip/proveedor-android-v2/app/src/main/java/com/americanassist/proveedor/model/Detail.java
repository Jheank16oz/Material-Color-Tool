package com.americanassist.proveedor.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Definicion del modelo Detail .
 *
 * <p> Esta es la clase de modelos de datos para serializar el JSON
 * transmitido por el webservice inicio_sesion_proveedor.
 * </p>
 *
 */
public class Detail {

    @SerializedName("error")
    @Expose
    public Boolean error;

    @SerializedName("mensaje")
    @Expose
    public String message;
}
