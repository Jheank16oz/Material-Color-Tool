package com.americanassist.proveedor;

import android.app.Fragment;
import android.os.Bundle;
import android.support.v7.widget.SwitchCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.utils.ConfigUtils;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

/**
 * Organiza las opciones del MenuLateral de DrawerActivity
 */
public class LateralMenuFragment extends Fragment {


    @BindView(R.id.request)
    LinearLayout mRequestItem;
    @BindView(R.id.history)
    LinearLayout mHistoryItem;
    @BindView(R.id.phone)
    LinearLayout mPhoneItem;
    @BindView(R.id.logout)
    LinearLayout mLogoutItem;
    @BindView(R.id.provider)
    TextView mProviderTextView;
    @BindView(R.id.contact)
    TextView mContactTextView;
    @BindView(R.id.version)
    TextView mVersionTextView;

    Unbinder unbinder;


    public LateralMenuFragmentCallback callback;
    public boolean canReadPendingRequests = true;
    public boolean canReadServiceHistory = true;


    @Override
    public void onDestroyView() {
        super.onDestroyView();
        unbinder.unbind();
    }


    /**
     * Callback para las opciones del menu lateral
     */
    public interface LateralMenuFragmentCallback {
        /**
         * Notifica accion de mostrar solicitudes
         * pendientes
         */
        void onPendingRequestsClicked();

        /**
         * Notifica accion de despliegue de historial de
         * servicios.
         */
        void onServiceHistoryClicked();

        /**
         * Notifica accion de llamar a call center
         */
        void onContactClicked();

        /**
         * Notifica accion de solicitude de deslogueo
         */
        void onLogoutClicked();

        void onViewCreated();
    }

    @Override
    public void onViewCreated(View v, Bundle savedInstanceState) {
        super.onViewCreated(v, savedInstanceState);
        if (callback != null) {
            callback.onViewCreated();
        }
    }

    public LateralMenuFragment() {
        super();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View mView = inflater.inflate(R.layout.fragment_lateralmenu, container, false);

        unbinder = ButterKnife.bind(this, mView);
        mVersionTextView.setText(String.format("Version: %s", BuildConfig.VERSION_NAME));
        bindInformationProvider();
        initListeners();
        return mView;
    }

    private void bindInformationProvider() {
        Provider mProvider = SharedPreferencesManager.getProvider(getActivity());
        if (mProvider!=null){
            mProviderTextView.setText(mProvider.getCapitalizeProviderName());
            mContactTextView.setText(mProvider.getCapitalizeContactName());
        }

        validateVisibleItems();
    }

    private void validateVisibleItems() {
        //validamos si se mostrara el historial de servicios
        mHistoryItem.setVisibility(ConfigUtils.displayAssistanceHistory(getActivity())? View.VISIBLE:View.GONE);
    }


    private void initListeners() {
        if(callback == null){
            return;
        }

        mRequestItem.setOnClickListener(v -> {
            if (canReadPendingRequests) {
                callback.onPendingRequestsClicked();
            }
        });

        mHistoryItem.setOnClickListener(v -> {
            if (canReadServiceHistory) {
                callback.onServiceHistoryClicked();
            }
        });
        mPhoneItem.setOnClickListener(v -> callback.onContactClicked());

        mLogoutItem.setOnClickListener(v -> {
            if (canReadPendingRequests) {
                callback.onLogoutClicked();
            }
        });
    }

    public void blockPendingRequestsAndCloseSession() {
        canReadPendingRequests = false;
        canReadServiceHistory = false;
        mRequestItem.setAlpha(0.5f);
        mLogoutItem.setAlpha(0.5f);
        mHistoryItem.setAlpha(0.5f);
    }

    public void unblockPendingRequestsAndCloseSession() {
        canReadPendingRequests = true;
        canReadServiceHistory = true;
        mRequestItem.setAlpha(1f);
        mLogoutItem.setAlpha(1f);
        mHistoryItem.setAlpha(1f);
    }
}
