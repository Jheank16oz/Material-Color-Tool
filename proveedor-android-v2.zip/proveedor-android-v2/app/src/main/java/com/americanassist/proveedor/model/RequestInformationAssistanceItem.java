package com.americanassist.proveedor.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class RequestInformationAssistanceItem {

    @SerializedName("titulo")
    @Expose
    public String tittle;

    @SerializedName("contenido")
    @Expose
    public String content;
}
