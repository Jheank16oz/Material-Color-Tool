package com.americanassist.proveedor.model;

import com.google.android.gms.maps.model.LatLng;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONObject;

import java.util.List;

public class RequestAssistance extends Assistance {

    public static final String ASSISTANCE_ACCEPT = "aceptar";
    public String endAddress;
    public List<RequestInformationAssistanceItem> information;


    /**
     * Este metodo es utilizado por {@link PendingRequestsActivity}
     * y {@link com.americanassist.proveedor.services.ActiveRequestService} para obtener una asistencia
     * que no contiene toda la informacion normal de un flujo de asistencia.
     * como por ejemplo: idexpediente
     * es utilizado para obtener una asistencia.
     *
     * @param json con asistencia
     * @return Asistencia POJO
     */
    public static RequestAssistance getAvailableAssistanceFromJson(JSONObject json) {

        RequestAssistance assistance = new RequestAssistance();
        assistance.id = json.optString("idasistencia");
        assistance.serviceId = json.optString("servicio");
        assistance.serviceName = json.optString("nombre_servicio");
        assistance.clientName = json.optString("nombre");
        assistance.serviceInfo = json.optBoolean("info_servicio");
        assistance.reference = json.optString("referencia");


        JSONObject jsonEndLocation = json.optJSONObject("end_location");
        if (jsonEndLocation!=null) {
            Double endLatitude = Double.parseDouble(jsonEndLocation.optString("lat"));
            Double endLongitude = Double.parseDouble(jsonEndLocation.optString("lng"));
            assistance.endLocation = new LatLng(endLatitude, endLongitude);
        }
        assistance.endAddress = json.optString("end_address");
        assistance.acceptAssistance = json.optString("aceptar_asistencia");

        if (json.has("estado")) {
            assistance.estado = json.optString("estado");
        }

        Gson mGson = new Gson();
        assistance.information = mGson.fromJson(json.optJSONArray("info_mostrar").toString(),
                new TypeToken<List<RequestInformationAssistanceItem>>(){}.getType());
        return assistance;

    }
}
