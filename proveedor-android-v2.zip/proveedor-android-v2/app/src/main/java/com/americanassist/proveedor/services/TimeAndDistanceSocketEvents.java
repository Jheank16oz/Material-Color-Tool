package com.americanassist.proveedor.services;

import org.json.JSONException;
import org.json.JSONObject;

import io.socket.emitter.Emitter;

/**
 * Event Listener para las actualizaciones de tiempo, direccion y distancia.
 */
public class TimeAndDistanceSocketEvents implements Emitter.Listener {

    private InfoAssistanceListener notificationsListener;

    public interface InfoAssistanceListener {

        /**
         * Este evento se ejecuta cuando nos llegan nuevos valores
         * para tiempo y distancia.
         */
        void onInfoAssistanceUpdate(String time, String distance, String direction);
    }

    TimeAndDistanceSocketEvents(InfoAssistanceListener notificationsListener){

        this.notificationsListener = notificationsListener;
    }

    @Override
    public void call(Object... args) {
        try {
            JSONObject mJsonObject = new JSONObject(args[0].toString());
            String time = mJsonObject.getString("tiempo");
            String distance = mJsonObject.optString("distancia");
            String direction = mJsonObject.optString("direction");
            notificationsListener.onInfoAssistanceUpdate(time,distance, direction);


        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}
