package com.americanassist.proveedor;

/**
 *
 * <p>
 *     Presentador Base para MVP
 * </p>
 */

public interface BasePresenter {

    void start();

}
