package com.americanassist.proveedor.config

import android.app.Activity
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.support.v7.app.AppCompatActivity
import android.text.Html
import android.widget.CompoundButton
import com.americanassist.proveedor.R
import com.americanassist.proveedor.utils.ConfigApp
import kotlinx.android.synthetic.main.activity_configuration_app.*

class ConfigurationAppActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_configuration_app)
        title = getString(R.string.configuraciones)

        displayUrlsConfig()

        val isRelease = !ConfigApp.isDefault(this)
        release.isChecked = isRelease
        release.setText(if (isRelease) R.string.produccion else R.string.pruebas)


        release.setOnCheckedChangeListener{ _: CompoundButton, b: Boolean ->
            release.setText(if (b) R.string.produccion else R.string.pruebas)
        }

        save.setOnClickListener{
            ConfigApp.setReleaseEnable(this, release.isChecked)
            Snackbar.make(findViewById(R.id.content),getString(R.string.configuracion_aplicada),Snackbar.LENGTH_SHORT).show()
            displayUrlsConfig()
            setResult(Activity.RESULT_OK)
        }
    }

    private fun displayUrlsConfig() {

        val url = ConfigApp.getUrlServer(this)
        val urlCoord = ConfigApp.getUrlSocketCoords(this)
        val urlDistance = ConfigApp.getUrlSocketDistance(this)

        content.text =  Html.fromHtml("<h6>URL</h6><h3>$url</h3><<br><h6>COORDINATES</h6><h3>$urlCoord<h3><br><h6>DISTANCE</h6><h3>$urlDistance</h3>");

    }



}
