package com.americanassist.proveedor.servicehistory.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.americanassist.proveedor.R;
import com.americanassist.proveedor.commons.Components.RecyclerLoadingFooterAdapter;
import com.americanassist.proveedor.model.Service;

import java.util.ArrayList;

/**
 * Este es un adaptador que organiza el historial de servicios en una lista hecha graficamente con recyclerview
 */

public class ServiceHistoryAdapter
        extends RecyclerLoadingFooterAdapter<RecyclerView.ViewHolder>
{
    public ArrayList<Service> mData = new ArrayList<>();
    private LayoutInflater mLayoutInflater;
    private OnItemClickListener mListener;
    private Service mService;

    /**
     * Interfaz realizada con el fin de
     * ordenar graficamente la funcionalidad
     * de oprimir un item de la lista
     */
    public interface OnItemClickListener
    {
        void onItemClick(int position, final Service assistance);
    }

    /**
     * Metodo empleado para indicar que es lo que se enviara
     * por debajo al efectual la accion de oprimir un item
     * @param listener indica un objeto de OnItemClickListener
     */
    public void setOnClickListener(OnItemClickListener listener)
    {
        mListener = listener;
    }

    /**
     * Metodo encargado de iterar tantas veces sean necesarias
     * segun la cantidad de servicios encontrado y pintar dichos
     * servicios en la lista utilizando un diseno card_service_history
     */
    @Override
    public RecyclerView.ViewHolder onActualCreateViewHolder(ViewGroup parent, int viewType)
    {
        View v = mLayoutInflater.inflate(R.layout.card_service_history, parent, false);
        return new ServiceHistoryItem(v);
    }

    @Override
    public void onActualBindViewHolder(RecyclerView.ViewHolder holder, int position)
    {
        mService = mData.get(position);
        ((ServiceHistoryAdapter.ServiceHistoryItem) holder).txtNumberService.setText(mService.id);
        ((ServiceHistoryItem) holder).txtFechaSolicitud.setText(mService.dateOfService);
        ((ServiceHistoryItem) holder).txtDescripcion.setText(mService.serviceDescription);

        /*
         * Condicional que perite pintar los numeros pares de la lista generada de un color
         * y los impares de otro color
         */
        if((position % 2) == 0)
            ((ServiceHistoryItem) holder).recyclerViewCard.setBackgroundColor(Color.parseColor("#e2f2fc"));// dividerCardServiceHistoryTwo
        else
            ((ServiceHistoryItem) holder).recyclerViewCard.setBackgroundColor(Color.parseColor("#ffeaed")); // dividerCardServiceHistoryOne
    }

    public ServiceHistoryAdapter(Context context)
    {
        super(context);
        mLayoutInflater = LayoutInflater.from(context);
    }

    /**
     * Retorna el tamano de la lista hasta el momento
     * @return Cantidad de servicios
     */
    @Override
    public int getActualItemCount()
    {
        return mData.size();
    }

    /**
     * Indica la posicion antual de cada uno de los item de la lista
     * @param position posicion del item
     * @return el item por tipo
     */
    @Override
    public int getActualItemViewType(int position)
    {
        return 0;
    }

    /**
     *
     * @param services serivicios a agregar.
     */
    public void addHistoryServices(ArrayList<Service> services)
    {
        mData.addAll(services);
        notifyDataSetChanged();
    }

    class ServiceHistoryItem extends RecyclerView.ViewHolder
    {
        TextView txtNumberService;
        TextView txtFechaSolicitud;
        TextView txtDescripcion;
        RelativeLayout recyclerViewCard;

        public ServiceHistoryItem(View itemView)
        {
            super(itemView);
            txtNumberService = itemView.findViewById(R.id.CPA_textview_servicenumber_history);
            txtFechaSolicitud = itemView.findViewById(R.id.CPA_textview_date_history);
            txtDescripcion = itemView.findViewById(R.id.CPA_textview_description_history);
            recyclerViewCard = itemView.findViewById(R.id.recycler_card_service_history);

            /*
             * Permite seleccionar cada item de la lista recyclerView
             */
            itemView.setOnClickListener(view -> {
                if(mListener != null)
                {
                    int position = getAdapterPosition();
                    if (position != RecyclerView.NO_POSITION)
                    {
                        /*
                         * Enviamos la posicion con id y otros elementos,
                         * incluyendo un objeto de la clase ItemService
                         */
                        final Service mService = mData.get(position);
                        mListener.onItemClick(position, mService);
                    }
                }
            });
        }
    }
}
