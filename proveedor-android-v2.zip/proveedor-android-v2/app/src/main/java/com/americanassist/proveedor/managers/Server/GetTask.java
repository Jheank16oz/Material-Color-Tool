package com.americanassist.proveedor.managers.Server;

import android.os.AsyncTask;

public class GetTask extends AsyncTask<Boolean, String, ServerResponse> {

    public static final int CODE_200 = 200;
    public static final int CODE_201 = 201;

    private String url;
    private String query;
    private ApiManagerHelper.GetTaskCallback callback;
    private HttpController httpController;

    public GetTask(String url, HttpController httpController,
                    ApiManagerHelper.GetTaskCallback callback) {
        this.url = url;
        this.query = query;
        this.httpController = httpController;
        this.callback = callback;
    }

    @Override
    protected ServerResponse doInBackground(Boolean... sendJson) {
        return httpController.makeHttpRequest(url,
                HttpController.METHOD_GET, query);
    }

    @Override
    protected void onPostExecute(ServerResponse result) {
        super.onPostExecute(result);

        if (result.code == CODE_200 || result.code == CODE_201) {
            callback.onSuccess(result.response);
        }
        else if (result.code >= 500){
            callback.onError("Estamos teniendo problemas, intenta mas tarde.");
        }else{
            callback.onError(result.response);
        }
    }

}