package com.americanassist.proveedor.model;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by Mona on 22/01/2018.
 */

public class JustificationRejection
{
    public String typeJustification;
    public String descriptionJustification;

    public JustificationRejection()
    {

    }

    public JustificationRejection(JustificationRejection justificationRejection)
    {
        this.typeJustification = justificationRejection.typeJustification;
        this.descriptionJustification = justificationRejection.descriptionJustification;
    }

    public static JustificationRejection getJustificationFromJson(JSONObject json)
    {
        try
        {
            JustificationRejection justificationRejection = new JustificationRejection();
            justificationRejection.typeJustification = json.getString("tipo");
            justificationRejection.descriptionJustification = json.getString("justificacion");
            return justificationRejection;
        }
        catch (JSONException e)
        {
            e.printStackTrace();
            return null;
        }
    }
}
