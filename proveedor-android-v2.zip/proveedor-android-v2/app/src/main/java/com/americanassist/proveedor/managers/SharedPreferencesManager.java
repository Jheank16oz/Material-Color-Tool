package com.americanassist.proveedor.managers;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;
import android.support.constraint.ConstraintLayout;

import com.americanassist.proveedor.model.Provider;

public class SharedPreferencesManager {

    private static final String ID_PROVIDER = "idProvider";
    private static final String TOKEN = "token";
    private static final String COUNTRY = "country";
    private static final String ID_CONTACT = "idContact";
    private static final String CONTACT_NAME = "contactName";
    private static final String PROVIDER_NAME = "providerName";
    private static final String CORE_PROV_NUMBER = "coreProvNumber";


    public static void setProvider(Provider provider, Context context) {

        AppModulePreference sp = getSharedPreferences(context);
        sp.put(ID_PROVIDER, provider.idProvider);
        sp.put(TOKEN, provider.token);
        sp.put(COUNTRY, provider.country);
        sp.put(CORE_PROV_NUMBER, provider.coreProvNumber);
        sp.put(ID_CONTACT, provider.idContact);
        sp.put(CONTACT_NAME, provider.contactName);
        sp.put(PROVIDER_NAME, provider.providerName);
    }

    public static Provider getProvider(Context context) {
        AppModulePreference sp = getSharedPreferences(context);
        if (sp.getString(ID_PROVIDER, null) != null) {
            Provider provider = new Provider();
            provider.idProvider = sp.getString(ID_PROVIDER, null);
            provider.token = sp.getString(TOKEN, null);
            provider.country = sp.getString(COUNTRY, null);
            provider.idContact = sp.getString(ID_CONTACT, null);
            provider.contactName = sp.getString(CONTACT_NAME, null);
            provider.providerName = sp.getString(PROVIDER_NAME, null);
            return provider;
        }
        else{
            return null;
        }
    }

    public static boolean isProviderEnabled(Context context){
        AppModulePreference sp = getSharedPreferences(context);
        return sp.getString(ID_PROVIDER,null) != null;
    }

    public static void removeProvider(Context context) {
        AppModulePreference sp = getSharedPreferences(context);
        sp.clear();
    }

    private static AppModulePreference getSharedPreferences(final Context context) {
        return new AppModulePreference(context);
    }
}
