package com.americanassist.proveedor.map;

import android.os.Bundle;

import com.americanassist.proveedor.model.Assistance;
import com.americanassist.proveedor.services.ActiveRequestService;
import com.google.android.gms.maps.model.LatLng;

import static com.americanassist.proveedor.services.ActiveRequestService.LOCATION_STATUS_ASSISTANCE;
import static com.google.common.base.Preconditions.checkNotNull;

/**
 * Created by ICATECH on 22/03/18.
 *
 * <p>Presentador de las caracteristicas del Mapa</p>
 */

public class MapAssistancePresenter implements MapAssistanceContract.Presenter {

    private final MapAssistanceContract.View mMapAssistanceView;

    public MapAssistancePresenter(MapAssistanceContract.View view) {
        mMapAssistanceView = checkNotNull(view);
        mMapAssistanceView.setPresenter(this);
    }


    @Override
    public void start() {
        mMapAssistanceView.displayLocationChanced();
    }

    @Override
    public void updateAssistanceState(String state, String message) {
        mMapAssistanceView.displayState(state, message);
    }

    @Override
    public void updateInfoAssistance(String time, String distance, String direction) {
        mMapAssistanceView.updateInfoAssistance(time,distance,direction);
    }

    @Override
    public void updateLocationState(Bundle bundle) {
        if (bundle == null){
            return;
        }

        if (bundle.getBoolean(ActiveRequestService.LOCATION_STATUS_UPDATE,false)){
            // se le envia a la actividad la actualizacion de ubicacion par que refresque la vista del mapa
            // sin importar que haya o no asistencia
            mMapAssistanceView.setLocationChances(
                    new LatLng(bundle.getDouble(ActiveRequestService.LOCATION_LATITUDE,0),
                            bundle.getDouble(ActiveRequestService.LOCATION_LONGITUDE,0)),
                    bundle.getFloat(ActiveRequestService.LOCATION_BEARING)
            );

            mMapAssistanceView.displayState(bundle.getString(LOCATION_STATUS_ASSISTANCE,ActiveRequestService.LOCATION_STATE_EMPTY), "");
            mMapAssistanceView.displayLocationChanced();
        }
    }

    @Override
    public void updateAssistanceState(Assistance assistance) {
        mMapAssistanceView.updateAssistanceState(assistance);
    }

    @Override
    public void toggleMenuPressed() {

        mMapAssistanceView.toggleMenuPressed();
    }

    @Override
    public void refreshStatus() {
        mMapAssistanceView.refreshStatus();
    }


}
