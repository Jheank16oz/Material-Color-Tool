package com.americanassist.proveedor.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * <p>InactivtyJustification</p>
 */
public class InactivtyJustification {

    @SerializedName("mensaje")
    @Expose
    public String message;
    @SerializedName("justificaciones")
    @Expose
    public List<Justification> justifications = null;
}
