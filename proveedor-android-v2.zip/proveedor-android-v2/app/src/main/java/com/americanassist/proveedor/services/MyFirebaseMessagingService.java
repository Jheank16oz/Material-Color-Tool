package com.americanassist.proveedor.services;

import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;

/**
 * Servicio encargado de mensajes FCM
 */
public class MyFirebaseMessagingService extends FirebaseMessagingService {


    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        Map<String, String> params = remoteMessage.getData();
        JSONObject jsonObject = new JSONObject(params);
        try {
            Log.e("Notificacion recibida ", String.valueOf(jsonObject.get("type")));
            Log.e("Notificacion recibida ", String.valueOf(remoteMessage.getNotification().getSound()));

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
}