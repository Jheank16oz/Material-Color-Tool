package com.americanassist.proveedor.model;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static com.americanassist.proveedor.utils.Utils.decodePoly;

public class Assistance implements Parcelable {

    public String id;
    public String recordId;
    public String clientName;
    public String serviceId;
    public String serviceName;
    public String reference;
    public boolean serviceInfo;
    public int seconds;
    public String estado;
    public String acceptAssistance; // Indica si es tipo aceptar (asistencias normales) o tipo siguiente (asistencias nuevas)
    public String route1;
    public String route2;
    public LatLng endLocation;
    public LatLng workshopLatLng;

    public String lastTime;
    public String lastDistance;
    public String direction;

    public Assistance(){}

    public Assistance(Assistance assistance){
        this.id = assistance.id;
        this.recordId = assistance.recordId;
        this.clientName = assistance.clientName;
        this.serviceId = assistance.serviceId;
        this.serviceName = assistance.serviceName;
        this.serviceInfo = assistance.serviceInfo;
        this.reference = assistance.reference;
        this.seconds = assistance.seconds;
        this.endLocation = assistance.endLocation;
        this.estado = assistance.estado;
        this.route1 = assistance.route1;
        this.route2 = assistance.route2;
        this.acceptAssistance = assistance.acceptAssistance;
        this.endLocation = assistance.endLocation;
        this.workshopLatLng = assistance.workshopLatLng;
        this.direction = assistance.direction;

    }

    /**
     * Devuelve una asistencia completa para los procesos normales de, Diagnostico, ocupado,
     * Solucion, etc. cuando el proveedor se encuentra asignado a una asistencia.
     * @param json con asistencia
     * @return Asistencia POJO
     */
    public static Assistance getCurrentAssistanceFromJson(JSONObject json) {

        Assistance assistance = new Assistance();
        assistance.recordId = json.optString("idexpediente");
        assistance.id = json.optString("idasistencia");
        assistance.serviceId = json.optString("servicio");
        assistance.serviceName = json.optString("nombre_servicio");
        assistance.clientName = json.optString("nombre");
        assistance.reference = json.optString("referencia");
        assistance.lastTime = json.optString("tiempo_text");
        assistance.lastDistance = json.optString("distancia_text");

        if (json.has("latitud_afiliado")) {
            assistance.endLocation = new LatLng(Double.parseDouble(json.optString("latitud_afiliado")), Double.parseDouble(json.optString("longitud_afiliado")));
        }
        if (json.has("estado")) {
            assistance.estado = json.optString("estado");
        }
        if (json.has("aceptar_asistencia")){
            assistance.acceptAssistance = json.optString("aceptar_asistencia");
        }
        if (json.has("ruta")){
            assistance.route1 = json.optString("ruta");
        }
        if (json.has("ruta2")){
            assistance.route2 = json.optString("ruta2");
        }

        assistance.workshopLatLng = new LatLng(json.optDouble("latitud_taller"),json.optDouble("longitud_taller"));
        assistance.direction = json.optString("direccion");
        return assistance;
    }


    public List<LatLng> getPolylineRoute1(){
        List<LatLng> points = new ArrayList<>();
        try {
            if (route1 != null && !route1.equals("")){
                JSONArray routeArray =new  JSONArray(route1);
                JSONObject routes = routeArray.getJSONObject(0);
                JSONObject overviewPolylines = routes.getJSONObject("overview_polyline");
                String encodedString = overviewPolylines.getString("points");
                List<LatLng> list = decodePoly(encodedString);
                points.addAll(list);
                return points;
            }
            else{
                return null;
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<LatLng> getPolylineRoute2(){
        List<LatLng> points = new ArrayList<>();
        try {

            if (route2!=null && !route2.isEmpty() && !route2.equalsIgnoreCase("\"\"")){
                JSONArray routeArray =new  JSONArray(route2);
                JSONObject routes = routeArray.getJSONObject(0);
                JSONObject overviewPolylines = routes.getJSONObject("overview_polyline");
                String encodedString = overviewPolylines.getString("points");
                List<LatLng> list = decodePoly(encodedString);
                points.addAll(list);
                return points;
            }
            else{
                return null;
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    public boolean isCraneAssistance(){
        return !Double.valueOf(workshopLatLng.latitude).isNaN() || !Double.valueOf(workshopLatLng.longitude).isNaN();
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.id);
        dest.writeString(this.recordId);
        dest.writeString(this.clientName);
        dest.writeString(this.serviceId);
        dest.writeString(this.serviceName);
        dest.writeString(this.reference);
        dest.writeByte(this.serviceInfo ? (byte) 1 : (byte) 0);
        dest.writeInt(this.seconds);
        dest.writeString(this.estado);
        dest.writeString(this.acceptAssistance);
        dest.writeString(this.route1);
        dest.writeString(this.route2);
        dest.writeParcelable(this.endLocation, flags);
        dest.writeParcelable(this.workshopLatLng, flags);
        dest.writeString(this.lastTime);
        dest.writeString(this.lastDistance);
        dest.writeString(this.direction);
    }

    protected Assistance(Parcel in) {
        this.id = in.readString();
        this.recordId = in.readString();
        this.clientName = in.readString();
        this.serviceId = in.readString();
        this.serviceName = in.readString();
        this.reference = in.readString();
        this.serviceInfo = in.readByte() != 0;
        this.seconds = in.readInt();
        this.estado = in.readString();
        this.acceptAssistance = in.readString();
        this.route1 = in.readString();
        this.route2 = in.readString();
        this.endLocation = in.readParcelable(LatLng.class.getClassLoader());
        this.workshopLatLng = in.readParcelable(LatLng.class.getClassLoader());
        this.lastTime = in.readString();
        this.lastDistance = in.readString();
        this.direction = in.readString();
    }

    public static final Parcelable.Creator<Assistance> CREATOR = new Parcelable.Creator<Assistance>() {
        @Override
        public Assistance createFromParcel(Parcel source) {
            return new Assistance(source);
        }

        @Override
        public Assistance[] newArray(int size) {
            return new Assistance[size];
        }
    };

}
