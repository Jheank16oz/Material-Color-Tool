package com.americanassist.proveedor.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;

import com.americanassist.proveedor.R;

/**
 * <p>Vista de Dialogo de dos opciones con informacion de
 * vista parametrizada</p>
 */
public class TwoOptionsDialog  extends Dialog {

    private TextView txtTittle, txtContent;
    private Button txtAccept;
    private Button txtCancel;

    private Context mContext;
    private TwoOptionsDialogListener twoOptionsDialogListener;
    private String tittle;
    private String description;
    private String textCancel;
    private String textAccept;

    /**
     * Callback para las acciones sobre el dialogo
     */
    public interface TwoOptionsDialogListener {
        /**
         * Notifica una accion de cancelado sobre el dialogo
         */
        void onCancelClicked();
        /**
         * Notifica una accion de aceptacion sobre el dialogo
         */
        void onAcceptClicked();
    }

    public TwoOptionsDialog(Context context,String tittle, String description, String textCancel, String textAccept, TwoOptionsDialogListener yesNoDialogListener) {
        super(context);
        mContext = context;
        this.tittle = tittle;
        this.description = description;
        this.textCancel = textCancel;
        this.textAccept = textAccept;
        this.twoOptionsDialogListener = yesNoDialogListener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(
                new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        setContentView(R.layout.dialog_two_options);

        txtTittle = findViewById(R.id.DYN_textview_description);
        txtAccept = findViewById(R.id.accept);
        txtCancel = findViewById(R.id.DYN_textview_cancel);
        txtContent = findViewById(R.id.content);

        init();
        initListeners();
    }

    private void init() {
        txtTittle.setText(tittle);
        txtContent.setText(description);
        txtCancel.setText(textCancel);
        txtAccept.setText(textAccept);
    }

    private void initListeners() {
        txtAccept.setOnClickListener(view -> {
            twoOptionsDialogListener.onAcceptClicked();
            dismiss();
        });

        txtCancel.setOnClickListener(view -> {
            twoOptionsDialogListener.onCancelClicked();
            dismiss();
        });
    }

}
