package com.americanassist.proveedor.dialogs;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Window;
import android.widget.ProgressBar;
import com.americanassist.proveedor.R;

/**
 * <p>Vista de Dialogo con apariencia FullScreen
 * Se utiliza para mostrar progresos que requieren bloquear
 * las acciones del usuario.</p>
 */
public class LoadingDialog extends Dialog {

    private Context context;
    private ProgressBar progressBar;

    public LoadingDialog(Context context) {
        super(context);
        this.context = context;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setBackgroundDrawable(
                new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        setContentView(R.layout.dialog_loading);

        setCancelable(false);
    }
}
