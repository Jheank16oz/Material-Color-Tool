package com.americanassist.proveedor;

/**
 *
 * <p>ista base para las vistas de MVP</p>V
 */

public interface BaseView<T> {

    void setPresenter(T presenter);

}