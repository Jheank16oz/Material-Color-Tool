package com.americanassist.proveedor.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.DrawableRes;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;

import com.americanassist.proveedor.R;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * <p>Utilidades generales de la app</p>
 */
public class Utils {

    public static boolean checkConn(Context ctx) {
        Boolean ret;
        ret = true;
        ConnectivityManager conMgr = (ConnectivityManager) ctx
                .getSystemService(Context.CONNECTIVITY_SERVICE);

        if (conMgr != null) {
            NetworkInfo networkInfo = conMgr.getActiveNetworkInfo();
            if (networkInfo != null) {
                if (!networkInfo.isConnectedOrConnecting())
                    ret = false;
                if (!networkInfo.isAvailable())
                    ret = false;
            }

            if (networkInfo == null)
                ret = false;

        } else {
            ret = false;
        }

        return ret;
    }

    public final static boolean isValidEmail(CharSequence target) {
        if (TextUtils.isEmpty(target)) {
            return false;
        } else {
            return android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
        }


    }

    public static List<LatLng> decodePoly(String encoded) {

        List<LatLng> poly = new ArrayList<LatLng>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;

        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng((((double) lat / 1E5)),
                    (((double) lng / 1E5)));
            poly.add(p);
        }

        return poly;
    }

    public  static File getCompressImage(String selectedFilePath, File file){

        int m_inSampleSize = 4;
        try {
            OutputStream outStream;
            BitmapFactory.Options bmOptions = new BitmapFactory.Options();
            bmOptions.inPurgeable = true;
            bmOptions.inSampleSize = m_inSampleSize;
            Bitmap bitmap = BitmapFactory.decodeFile(selectedFilePath, bmOptions);

            outStream = new FileOutputStream(file);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 50, outStream);
            outStream.flush();
            outStream.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return file;
    }



    public static BitmapDescriptor bitmapDescriptorFromVectorBlue(Context context, @DrawableRes int vectorDrawableResourceId) {
        Drawable background = ContextCompat.getDrawable(context, R.drawable.ic_place_blue_48dp);
        background.setBounds(0, 0, background.getIntrinsicWidth()*2, background.getIntrinsicHeight()*2);
        int w = (background.getIntrinsicWidth()*2)/4;
        int t = (background.getIntrinsicHeight()*2)/4;

        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorDrawableResourceId);
        vectorDrawable.setBounds(w, t - (t/3) , w*3 , t*3 - (t/3));
        Bitmap bitmap = Bitmap.createBitmap(background.getIntrinsicWidth()*2, background.getIntrinsicHeight()*2, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        background.draw(canvas);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    public static BitmapDescriptor bitmapDescriptorFromVectorGray(Context context, @DrawableRes int vectorDrawableResourceId) {
        Drawable background = ContextCompat.getDrawable(context, R.drawable.ic_place_gray_48dp);
        background.setBounds(0, 0, background.getIntrinsicWidth()*2, background.getIntrinsicHeight()*2);
        int w = (background.getIntrinsicWidth()*2)/4;
        int t = (background.getIntrinsicHeight()*2)/4;

        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorDrawableResourceId);
        vectorDrawable.setBounds(w, t - (t/3) , w*3 , t*3 - (t/3));
        Bitmap bitmap = Bitmap.createBitmap(background.getIntrinsicWidth()*2, background.getIntrinsicHeight()*2, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        background.draw(canvas);
        vectorDrawable.draw(canvas);
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }
}
