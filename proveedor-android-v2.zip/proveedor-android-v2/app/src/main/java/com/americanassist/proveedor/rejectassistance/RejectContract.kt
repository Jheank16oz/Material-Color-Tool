package com.americanassist.proveedor.rejectassistance

import com.americanassist.proveedor.BasePresenter
import com.americanassist.proveedor.BaseView
import com.americanassist.proveedor.model.JustificationRejection
import java.util.ArrayList

/**
 *
 * Contrato para la vista y el presentador de Rechazo de asistencia
 */
interface RejectContract{

    interface View : BaseView<Presenter> {
        fun displayOptions(justificationRejections: ArrayList<JustificationRejection>?)
        fun setLoading(display:Boolean)
        fun displayMessage(message:String?)
        fun displayRefresh(display:Boolean)
        fun sendResult()

    }

    interface Presenter : BasePresenter {
        fun getOptions()
        fun cancelAssistance(assistanceId: String?, type:String, causeResponse:String)
    }
}