package com.americanassist.proveedor.cranecost;

import com.americanassist.proveedor.BasePresenter;
import com.americanassist.proveedor.BaseView;

/**
 *
 * <p>Contrato para la vista y el Presentador de Costos Grua</p>
 */

public interface CraneCostContract {
    interface View extends BaseView<CraneCostContract.Presenter> {

        void displayState(String state);
        void setCosts(String distance,String costs, String assistanceId, String route1, String route2);
        void displayCosts();

    }

    interface Presenter extends BasePresenter {
        void updateAssistanceState(String state);
        void initCosts(String distance, String costs, String assistanceId, String route1, String route2);
    }

}
