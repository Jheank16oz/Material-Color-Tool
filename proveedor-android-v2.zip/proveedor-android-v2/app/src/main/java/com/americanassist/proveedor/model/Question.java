package com.americanassist.proveedor.model;

import com.google.android.gms.location.places.Place;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;

public class Question {

    public static final String TYPE_TEXT = "Text";
    public static final String TYPE_DATETIME = "Datetime";
    public static final String TYPE_DIRECTION = "Direction";
    public static final String TYPE_LIST = "List";
    public static final String TYPE_IMAGE = "Image";

    public int id;
    public String isRequired;
    public String question;
    public String type;
    public String placeholder;
    public ArrayList<QuestionOption> questionOptions;

    public File filePicture;
    public Calendar calendar;
    public String text;


    // Place con la informacion de la ubicacion seleccionada
    public Place mPlace;


    public static ArrayList<Question> getQuestionsFromJson(JSONObject json) {
        ArrayList<Question> questions = new ArrayList<>();

        try {
            JSONArray jsonArrayQuestions = json.getJSONArray("preguntas");
            for (int i=0; i<jsonArrayQuestions.length(); i++){
                JSONObject jsonQuestion = jsonArrayQuestions.getJSONObject(i);
                Question question = new Question();
                question.id = jsonQuestion.getInt("id");
                question.isRequired = jsonQuestion.getString("es_requerido");
                String type = jsonQuestion.getString("tipo");
                question.placeholder = jsonQuestion.getString("placeholder");
                question.question = jsonQuestion.getString("pregunta");
                question.type = jsonQuestion.getString("tipo");

                // De momento no aniadimos las de tipo direccion

                if (type.equals(TYPE_LIST)){
                    JSONArray jsonArrayOptions = jsonQuestion.getJSONArray("opciones");
                    question.questionOptions = new ArrayList<>();

                    for (int j=0; j<jsonArrayOptions.length(); j++){
                        JSONObject jsonOption = jsonArrayOptions.getJSONObject(j);
                        QuestionOption questionOption = new QuestionOption();
                        questionOption.id = jsonOption.getString("id");
                        questionOption.questionName = jsonOption.getString("question_name");
                        questionOption.optionValue = jsonOption.getString("option_value");
                        question.questionOptions.add(questionOption);
                    }
                }
                questions.add(question);

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return questions;
    }
}
