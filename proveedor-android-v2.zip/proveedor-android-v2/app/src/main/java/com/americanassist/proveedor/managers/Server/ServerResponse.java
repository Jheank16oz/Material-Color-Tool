package com.americanassist.proveedor.managers.Server;

public class ServerResponse {
    public String response;
    public int code;
}
