package com.americanassist.proveedor.commons.Controllers;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Rect;
import android.media.MediaPlayer;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.annotation.CallSuper;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.Snackbar;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.americanassist.proveedor.R;
import com.americanassist.proveedor.connection.modelRepository.UserRepository;
import com.americanassist.proveedor.dialogs.EmergencyDialog;
import com.americanassist.proveedor.dialogs.LoadingDialog;
import com.americanassist.proveedor.dialogs.NoConnectionDialog;
import com.americanassist.proveedor.managers.Server.ApiManager;
import com.americanassist.proveedor.managers.Server.ApiManagerHelper;
import com.americanassist.proveedor.managers.SharedPreferencesManager;
import com.americanassist.proveedor.model.Provider;
import com.americanassist.proveedor.utils.Utils;
import com.google.android.gms.maps.model.LatLng;

import uk.co.chrisjenx.calligraphy.CalligraphyContextWrapper;

import static com.americanassist.proveedor.BaseApplication.getInstance;

/**
 * <p>Actividad Base para la gestion de opciones generales y funciones
 * abstractas</p>
 */
public abstract class BaseActivity extends PermissionsActivity {

    private LoadingDialog loadingDialog;
    private Context mContext;
    private UserRepository mUserRepository;
    private ApiManager mApiManager;

    private LinearLayout bottomSheet;
    private BottomSheetBehavior mBottomSheetBehavior;
    private MediaPlayer mMediaPlayer;

    /** Comando a onPostCreate para definir si se muestra el boton de emergencia.*/
    public boolean displayEmergencyButton = true;

    // Objetivo para almacenar el estado desconexion del usuario
    private boolean isWaitingForConnection;

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);

        if (displayEmergencyButton) {
            createEmergencyButton();
        }


    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent event){
        /*
         * Se valida el tipo de accion sobre la pantalla para ocultar la vista
         * de emergencia si es necesario
         */
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            stopNotification();
            if ( mBottomSheetBehavior!=null && mBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {

                Rect outRect = new Rect();
                bottomSheet.getGlobalVisibleRect(outRect);

                if(!outRect.contains((int)event.getRawX(), (int)event.getRawY()))
                    mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
            }
        }

        return super.dispatchTouchEvent(event);
    }

    /**
     * Crea el contenedor y funcionalidades del
     * boton de emergencia.
     */
    private void createEmergencyButton() {

        ViewGroup viewGroup = this.findViewById(android.R.id.content);
        getLayoutInflater().inflate(R.layout.emergency_layout, viewGroup);
        bottomSheet = findViewById(R.id.bottomSheet);
        ImageView mEmergencyButton = bottomSheet.findViewById(R.id.emergency_button);
        Button mPanicAlertButton = bottomSheet.findViewById(R.id.buttonPanicAlert);
        mBottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
        mBottomSheetBehavior.setSkipCollapsed(true);

        // mEmergencyButton permite mostrar o no el boton encargado de emitir la alerta
        mEmergencyButton.setOnClickListener(v -> mBottomSheetBehavior.setState(mBottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED
                ?BottomSheetBehavior.STATE_COLLAPSED:BottomSheetBehavior.STATE_EXPANDED));

        // Al presionar este boton es en donde se emitira la alerta
        mPanicAlertButton.setOnClickListener(v -> sendAlert());
    }

    /**
     * Aqui nos encargamos de enviar al webservice evento_panico_proveedor
     * la alerta del tecnico (usuario)
     */
    public void sendAlert(){
        final Provider mProvider = SharedPreferencesManager.getProvider(getBaseContext());
        LatLng mCurrentLocation = getInstance().getCurrentLocation();

        if(mCurrentLocation == null){
            Toast.makeText(getBaseContext(), R.string.mensaje_esperando_ubicacion_actual, Toast.LENGTH_SHORT).show();
            return;
        }
        if (mProvider != null) {
            mUserRepository.panicAlert( mProvider.idProvider,
                    mProvider.idContact,
                    mProvider.country,
                    mCurrentLocation.latitude,
                    mCurrentLocation.longitude,
                    detail -> Toast.makeText(getBaseContext(), detail.message, Toast.LENGTH_SHORT).show());
        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Inicializamos
        mUserRepository = new UserRepository(this);
        mApiManager = new ApiManager(this);

        loadingDialog = new LoadingDialog(this);
        mContext = this;
    }

    /**
     * Se encarga de desplegar el dialogo de emergencia
     */
    public void displayEmergencyDialog(){
        new EmergencyDialog(this).show();
    }

    @Override
    public void onResume() {
        super.onResume();
        registerReceiver(broadcastReceiverConnectivity, new IntentFilter(
                ConnectivityManager.CONNECTIVITY_ACTION));

        NotificationManager notificationManager = (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.cancelAll();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
    }


    private BroadcastReceiver broadcastReceiverConnectivity = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction() != null && intent.getAction().equals(
                    ConnectivityManager.CONNECTIVITY_ACTION)) {
                if (Utils.checkConn(context)) {
                    if (isWaitingForConnection) {
                        isWaitingForConnection = false;
                        onConnectionReset();
                    }
                } else {
                    isWaitingForConnection = true;
                    onConnectionFailure();
                }
            }
        }
    };

    @CallSuper
    public void onConnectionFailure() {
        //ignored
    }


    /**
     * Se encarga de ocultar una vista de carga  si existe
     */
    public void hideLoadingView() {
        if(!this.isFinishing()) {
            if (loadingDialog != null && loadingDialog.isShowing() && mContext != null) {
                try {
                    loadingDialog.dismiss();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Se encarga de desplegar una vista de espera
     */
    public void showLoadingView() {
        if(!this.isFinishing()) {
            if (loadingDialog != null && !loadingDialog.isShowing() && mContext != null) {
                try {
                    loadingDialog.show();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Se sobrecarga  para inicializar Calligraphy
     */
    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(CalligraphyContextWrapper.wrap(newBase));
    }

    @Override
    protected void onDestroy() {
        if (broadcastReceiverConnectivity != null) {
            try {
                unregisterReceiver(broadcastReceiverConnectivity);
            } catch (IllegalArgumentException e) {
                // ignored
            }
        }
        super.onDestroy();
    }



    /**
     * Se procesan las configuraciones que se tengan actuales para la app
     * como la api key, el tiempo y la distancia a utilizar para los intervalos
     * de consulta en google maps
     * @param provider proveevor actual
     */
    public void configurationApp(Provider provider, final ApiManagerHelper.GetConfigurationCallback mConfigurationCallback){
        if (provider == null){
            return;
        }
        mApiManager.getConfigurations(provider.country,mConfigurationCallback);
    }


    /**
     * Se encarga de mostrar un mensaje mediante SnackBar
     * @param message mensaje que se quiere mostrar
     */
    public void showSnackbar(String message){
        Snackbar.make(findViewById(android.R.id.content), message, Snackbar.LENGTH_LONG).show();
    }

    /**
     * Funcion encargada de reproducir el sonido
     * de Notificacion
     */
    public void notification(){
        if (mMediaPlayer!=null) {
            mMediaPlayer.stop();
        }
            mMediaPlayer = MediaPlayer.create(getBaseContext(), R.raw.notificaciones);
            mMediaPlayer.start();

    }

    /**
     * Se encarga de detener el sonido de notificacion si
     * esta en proceso de reproduccion
     */
    public void stopNotification(){
        if (mMediaPlayer != null) {
            mMediaPlayer.stop();
        }
    }

    /**
     * Se encarga de escuchar la reconexión de internet del usuario
     */
    @CallSuper
    public void onConnectionReset() {
    }


}
