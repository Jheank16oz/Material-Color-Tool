package com.americanassist.proveedor.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

/**
 * Utilidades de configuraciones, guarda en preferencias y
 * administracion de solicitudes de informacion.
 */
public class ConfigUtils {
    /**
     * Api key para el calculo de dostancia con la api de google
     */
    private static final String API_KEY_DISTANCE_MATRIX = "distance_matrix_api_key";

    /**
     * Distancia utilizada como intervalo para enviar coordenadas
     */
    private static final String DISTANCE_GOOGLE = "distance_google";

    /**
     * Tiempo utilizado como intervalo para enviar coordenadas
     */
    private static final String TIME_GOOGLE = "time_google";


    /**
     * Configuracion para habilitar el historial de servicios
     */
    private static final String DISPLAY_ASSISTANCE_HISTORY = "display_assistance_history";

    private static SharedPreferences getSharedPreferences(final Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static String getActiveDistanceMatrixApiKey(final Context context) {
        SharedPreferences sp = getSharedPreferences(context);
        return sp.getString(API_KEY_DISTANCE_MATRIX, null);
    }

    public static void setActiveDistanceMatrixApiKey(final Context context, final String distanceMatrixApiKey) {
        SharedPreferences sp = getSharedPreferences(context);
        sp.edit().putString(API_KEY_DISTANCE_MATRIX,distanceMatrixApiKey).apply();
    }




    /**
     * Para guardar en preferencias la distancia y el tiempo
     * utilizados para google maps
     *
     * @param context contexto de la clase o vista de la que
     * @param distance de intervalo para google map
     */
    public static void setTimeAndDistanceLocation(final Context context, final int distance, final int time) {
        SharedPreferences sp = getSharedPreferences(context);
        sp.edit()
                .putInt(DISTANCE_GOOGLE, distance)
                .putInt(TIME_GOOGLE, time)
                .apply();
    }

    public static int getTimeConfiguration(final Context context) {
        SharedPreferences sp = getSharedPreferences(context);
        return sp.getInt(TIME_GOOGLE, 0);
    }

    public static int getDistanceConfiguration(final Context context) {
        SharedPreferences sp = getSharedPreferences(context);
        return sp.getInt(DISTANCE_GOOGLE, 0);
    }

    public static void setDisplayAssistanceHistory(final Context context, final int display){
        SharedPreferences sp = getSharedPreferences(context);
        sp.edit().putBoolean(DISPLAY_ASSISTANCE_HISTORY,display==1).apply();
    }

    public static boolean displayAssistanceHistory(final Context context) {
        SharedPreferences sp = getSharedPreferences(context);
        return sp.getBoolean(DISPLAY_ASSISTANCE_HISTORY, true);
    }



}
