package com.jheank16oz.materialcolortool


interface BasePresenter {

    fun start()

}