package com.jheank16oz.materialcolortool

import android.support.v7.app.AppCompatActivity

abstract class BaseActivity : AppCompatActivity() {


}
