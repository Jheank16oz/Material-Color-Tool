package com.jheank16oz.materialcolortool


interface BaseView<T> {

    var presenter: T

}